---
marp: true
theme: default
paginate: true
header: "Dərin Öyrənmə (Deep Learning) - 0-dan Zirvəyə Təqdimat"
footer: "Müəllif: Təlimçi / Mühazirəçi | Deep Learning Əsasları"
style: |
  section {
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    font-size: 21px;
    line-height: 1.5;
    padding: 35px 50px;
    background-color: #0b1120;
    color: #e2e8f0;
  }
  h1 {
    color: #38bdf8;
    font-size: 38px;
    margin-bottom: 12px;
    border-bottom: 2px solid #1e293b;
    padding-bottom: 8px;
  }
  h2 {
    color: #818cf8;
    font-size: 28px;
    margin-bottom: 10px;
  }
  h3 {
    color: #f472b6;
    font-size: 22px;
    margin-bottom: 6px;
  }
  strong {
    color: #38bdf8;
  }
  em {
    color: #fbbf24;
    font-style: normal;
  }
  code {
    background: #1e293b;
    color: #f43f5e;
    padding: 2px 6px;
    border-radius: 4px;
    font-size: 0.9em;
  }
  pre {
    background: #0f172a;
    border: 1px solid #334155;
    border-radius: 8px;
    padding: 12px;
    font-size: 15px;
    color: #38bdf8;
    line-height: 1.3;
  }
  .box-idea {
    background: rgba(56, 189, 248, 0.1);
    border-left: 5px solid #38bdf8;
    padding: 10px 16px;
    border-radius: 4px;
    margin: 10px 0;
  }
  .box-analogy {
    background: rgba(52, 211, 153, 0.1);
    border-left: 5px solid #34d399;
    padding: 10px 16px;
    border-radius: 4px;
    margin: 10px 0;
  }
  .box-math {
    background: rgba(244, 114, 182, 0.1);
    border-left: 5px solid #f472b6;
    padding: 10px 16px;
    border-radius: 4px;
    margin: 10px 0;
  }
  .speaker-notes {
    background: rgba(251, 191, 36, 0.08);
    border: 1px dashed #fbbf24;
    padding: 8px 12px;
    font-size: 14px;
    color: #fde68a;
    border-radius: 6px;
    margin-top: 10px;
  }
  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 8px;
    font-size: 16px;
  }
  th {
    background-color: #1e293b;
    color: #38bdf8;
    border: 1px solid #334155;
    padding: 8px;
    text-align: left;
  }
  td {
    border: 1px solid #334155;
    padding: 7px 10px;
    background-color: #0f172a;
  }
  .grid-2 {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
  }
---

<!-- Slayd 1 -->
# 🧠 Dərin Öyrənmə (Deep Learning)
### İntellekt Maşınlarının Riyazi və Nəzəri Əsasları

<div class="box-idea">
🎯 <strong>Məqsəd:</strong> Mürəkkəb riyazi düsturlar arasında boğulmadan, Dərin Öyrənmənin iş prinsipini intuitiv məntiq, həyati analogiyalar və aydın vizual diaqramlarla tam anlamaq.
</div>

<div class="speaker-notes">
🎤 <strong>Spiker Qeydi:</strong> "Süni intellektin ən güclü qolu olan Dərin Öyrənməni 'qara qutu' (black box) olmaqdan çıxaracağıq. Hər bir addımda mürəkkəb terminləri sadə nümunələrlə izah edəcəyik."
</div>

---

<!-- Slayd 2 -->
# 🌐 Böyük Mənzərə: AI vs ML vs DL

<div class="grid-2">
<div>

```
+--------------------------------------------+
|  Süni İntellekt (AI - 1950s)               |
|  Insan zəkasını simulyasiya edən sistem    |
|  +--------------------------------------+  |
|  | Maşın Öyrənməsi (ML - 1980s)         |  |
|  | Məlumatdan nümunə çıxaran alqoritmlər|  |
|  | +----------------------------------+ |  |
|  | | Dərin Öyrənmə (DL - 2010s)       | |  |
|  | | Çoxlaylı süni neyron şəbəkələri  | |  |
|  | +----------------------------------+ |  |
|  +--------------------------------------+  |
+--------------------------------------------+
```
</div>
<div>

* 🔹 **Süni İntellekt (AI):** Ən böyük çətir anlayış. İnsana bənzər qərarlar qəbul edən hər şey (şahmat proqramları, ekspert sistemlər).
* 🔹 **Maşın Öyrənməsi (ML):** Qaydaları əllə yazmaq əvəzinə, alqoritmin verilənlərə baxaraq qaydaları özünün tapması (Linear Regression, Random Forest).
* 🔹 **Dərin Öyrənmə (DL):** İnsan beyninin quruluşundan ilhamlanan, qat-qat neyronlardan ibarət model ailəsi.
</div>
</div>

<div class="box-analogy">
🍎 <strong>Analogiya:</strong> AI nəqliyyat vasitəsidirsə, ML avtomobillərdir, DL isə reaktiv raket mühərriki olan müasir superkardır.
</div>

---

<!-- Slayd 3 -->
# ⚙️ Klassik Proqramlaşdırma vs Dərin Öyrənmə

Ənənəvi yanaşma ilə Öyrənmə yanaşmasının köklü fərqi:

```
Ənənəvi Proqramlaşdırma:
[Məlumat (Data)]     + [Qaydalar (Rules/Code)]  =======>  [Nəticə (Answers)]

Dərin Öyrənmə (Machine Learning):
[Məlumat (Data)]     + [Nəticələr (Answers)]    =======>  [Qaydalar (Rules/Weights)]
```

<div class="grid-2">
<div>

### ❌ Ənənəvi ML Çətinliyi:
* **Əllə Xüsusiyyət Seçimi (Feature Engineering):**
  Pişiyi tanımaq üçün mühəndis əllə qulağın bucağını, bığların uzunluğunu ölçən alqoritmlər yazmalı idi.
</div>
<div>

### ✅ Dərin Öyrənmənin Qələbəsi:
* **Avtomatik Xüsusiyyət Çıxarılması:**
  Şəkli şəbəkəyə veririk; ilk qatlar kənarları (edges), orta qatlar formaları (shapes), son qatlar bütöv sifəti özü kəşf edir!
</div>
</div>

<div class="box-idea">
💡 <strong>DL-in gücü:</strong> Məlumatın miqdarı artdıqca klassik ML doyma nöqtəsinə çatır, DL isə getdikcə daha dəqiq olur!
</div>

---

<!-- Slayd 4 -->
# 🧬 Təbiətdən Süniyə: Bioloji Neyron

İnsan beynində ~86 milyard neyron var. Onların iş prinsipi çox zərifdir:

```
  Dendritlər            Soma (Hüceyrə gövdəsi)          Akson           Sinaps
 (Giriş siqnalları)       (Siqnalı toplayır)      (Siqnalı ötürür)   (Çıxış keçidi)
        \                      +------+
  -----> \-------------------->|      |
  -----> --------------------->| Soma |====================>-----------> [Növbəti
  -----> /-------------------->|      |                                   Neyrona]
        /                      +------+
```

* 1️⃣ **Dendritlər:** Qonşu neyronlardan kimyəvi/elektrik siqnalları qəbul edir.
* 2️⃣ **Soma (Nüvə/Gövdə):** Gələn siqnalları toplayır və emal edir.
* 3️⃣ **Akson:** Əgər ümumi elektrik gərginliyi həddi (threshold) keçərsə, siqnal akson boyunca şütüyür.
* 4️⃣ **Sinaps:** Növbəti neyronla əlaqə nöqtəsi (bəzi əlaqələr güclü, bəziləri zəifdir).

---

<!-- Slayd 5 -->
# ⚡ Riyazi Ekvivalent: Süni Neyron (Perceptron)

Frank Rosenblatt (1958) tərəfindən irəli sürülmüş riyazi model:

```
 Girişlər (Inputs)     Çəkilər (Weights)       Toplama (Sum)        Aktivasiya (f)     Çıxış (y)

     x₁ -------------( w₁ )------------\
                                        \     +-------------+     +------------+
     x₂ -------------( w₂ )------------=====> |  z = Σ wᵢxᵢ | ==> |   a = f(z) | ====> y
                                        /     |     + b     |     +------------+
     x₃ -------------( w₃ )------------/      +-------------+
                                      /
     Bias (b) -----------------------/
```

<div class="box-math">
📐 <strong>Əsas Düstur:</strong> 
<code>z = (x₁·w₁ + x₂·w₂ + ... + xₙ·wₙ) + b</code>  
<code>y = Activation(z)</code>
</div>

* **x (Giriş):** Müşahidə olunan dəyərlər (məsələn: havanın temperaturu, küləyin sürəti).
* **w (Çəki / Weight):** Hər bir girişin qərara nə dərəcədə təsir etdiyini göstərən əhəmiyyət dərəcəsi.
* **b (Bias / Meyillilik):** Şəbəkənin heç bir giriş olmadan belə qərara nə dərəcədə meyilli olması (astana həddi).

---

<!-- Slayd 6 -->
# 🎯 Çəki (Weight) və Bias (b) Nədir?

![Piknik Qərar Modeli](images/slide06_weights_bias_picnic.svg)

Təsəvvür edin: **"Sabah piknikə gedim, ya yox?"** qərarı verirsiniz:

```
 Girişlər (x):
 x₁ = Hava günəşlidir? (1 = Hə, 0 = Yox)   --> Çəki w₁ = 5  (Sizin üçün hava ÇOX önəmlidir)
 x₂ = Dostum gəlir?    (1 = Hə, 0 = Yox)   --> Çəki w₂ = 2  (Gəlsə yaxşı olar, amma vacib deyil)
 x₃ = Tıxac var?       (1 = Hə, 0 = Yox)   --> Çəki w₃ = -4 (Tıxac varsa heç getmək istəmirsiniz)

 Bias (b) = -3 (Siz təbiətcə bir az tənbəl insansınız, evdə qalmağa meyllisiniz)
```

<div class="box-analogy">
🧮 <strong>Hesablama:</strong><br>
Hava günəşlidir (x₁=1), Dostunuz gəlmir (x₂=0), Tıxac yoxdur (x₃=0):<br>
<code>z = (1·5) + (0·2) + (0·(-4)) + (-3) = 5 - 3 = +2</code><br>
Nəticə müsbətdir (z > 0) ➡️ <strong>Piknikə gedirik! (y = 1)</strong>
</div>

* 📌 **Çəkilər (w):** Beynimizdəki meyarların çəkisi. Öyrənmə dediyimiz proses - məhz bu çəkiləri düzgün tənzimləməkdir!
* 📌 **Bias (b):** İlkin meyilliliyimiz. Bəzi insanlar pozitivdir (yüksək bias), bəziləri skeptikdir (mənfi bias).

---

<!-- Slayd 7 -->
# 🔀 Niyə Aktivasiya Funksiyası Lazımdır?

Əgər aktivasiya funksiyası olmasaydı nə baş verərdi?

```
Qat 1: z₁ = W₁·X + b₁
Qat 2: z₂ = W₂·z₁ + b₂ = W₂·(W₁·X + b₁) + b₂ = (W₂·W₁)·X + (W₂·b₁ + b₂)
                         \_______/             \____________/
                         Yeni Çəki (W')        Yeni Bias (b')
```

<div class="box-idea">
⚠️ <strong>Xətti Funksiyaların Tələsi:</strong> Xətti funksiyaların cəmi və hasili yenə də <strong>XƏTTİDİR</strong>!<br>
Əgər araya qeyri-xətti aktivasiya qoymasaq, 1000 qatlı ən dərin şəbəkə belə adi 1 qatlı xətti reqressiyaya bərabər olar!
</div>

### Real Həyat Xətti Deyil!
* İnsan üzü, səslər, avtomobilin trayektoriyası düz xətt deyil.
* **Aktivasiya funksiyası** neyron şəbəkəsinə bükülmə, əyilmə və mürəkkəb qeyri-xətti sərhədlər çəkmək qabiliyyəti verir.

---

<!-- Slayd 8 -->
# 📈 Əsas Aktivasiya Funksiyaları (1/2)

<div class="grid-2">
<div>

### 1. Sigmoid: $\sigma(z) = \frac{1}{1 + e^{-z}}$
```
      1 |           ...---
        |        .-'
    0.5 |      .'
        |   .-'
      0 +---'------------
          -4  -2   0   2   4
```
* Çıxışı **(0 ilə 1)** arasına sıxır.
* Ehtimal kimi şərh etmək asandır.
* ❌ *Qüsur:* **Vanishing Gradient** (böyük və kiçik qiymətlərdə törəmə sıfır olur, şəbəkə öyrənməyi dayandırır).
</div>
<div>

### 2. Tanh (Hiperbolik Tangens)
```
      1 |           ...---
        |        .-'
      0 +-------+-------
        |    .-'
     -1 | ---'
          -4  -2   0   2   4
```
* Çıxışı **(-1 ilə +1)** arasına sıxır.
* **Sıfır mərkəzlidir (Zero-centered)**, yəni orta qiymət 0 ətrafındadır (Sigmoid-dən daha yaxşıdır).
* ❌ *Qüsur:* Yenə də güclü Vanishing Gradient problemi qalır.
</div>
</div>

---

<!-- Slayd 9 -->
# 🚀 Əsas Aktivasiya Funksiyaları (2/2)

<div class="grid-2">
<div>

### 3. ReLU (Rectified Linear Unit)
```
  Düstur: f(z) = max(0, z)

    y |        /
      |       /
      |      /
      |_____/_____ x
           0
```
* Əgər mənfidirsə 0, müsbətdirsə olduğu kimi buraxır!
* ⚡ **Çox sürətlidir** (sadəcə `if z > 0`).
* 🌟 Dərin şəbəkələrin əsas qəhrəmanıdır (Vanishing gradient yoxdur).
* ⚠️ *Dying ReLU:* Bəzi neyronlar daimi 0 olub "ölə" bilər.
</div>
<div>

### 4. Leaky ReLU & Softmax
```
  Leaky ReLU: f(z) = max(0.01z, z)
  (Mənfi hissədə kiçik sızma buraxır)

  Softmax:
            e^(zᵢ)
  P(y = i) = -------
            Σ e^(zⱼ)
```
* **Softmax nə edir?** Çıxış qatındakı bütün ədədləri cəmi **1.0 (100%)** olan ehtimallara çevirir.
* Məsələn: [2.0, 1.0, 0.1] ➡️ [%70 Pişik, %25 İt, %5 Quş].
</div>
</div>

---

<!-- Slayd 10 -->
# 🏗️ Çoxlaylı Neyron Şəbəkələri (MLP)

Tək neyron hətta sadə **XOR** məntiqini həll edə bilmirdi (Minsky & Papert böhranı, 1969).
Həll: **Qatları birləşdirmək!**

```
Giriş Qatı (Input)      Gizli Qat (Hidden Layer)       Çıxış Qatı (Output)
   (Piksellər)           (Xüsusiyyətlər/Detallar)        (Qərar/Proqnoz)

      (x₁) -------------\    /--- (h₁) ---\
                         X                 ===> (y₁) [Pişik]
      (x₂) -------------/ \  /--- (h₂) ---/
                           X
      (x₃) ---------------/  \--- (h₃) =======> (y₂) [İt]
```

* 🟢 **Input Layer:** Məlumatların daxil olduğu qapı (məs: şəklin 784 pikseli).
* 🟣 **Hidden Layers:** Məlumatın abstraktlaşdırıldığı daxili qatlar (kənarlar ➡️ gözlər ➡️ sifət).
* 🔴 **Output Layer:** Son cavab (məs: 0 və ya 1, yaxud 10 fərqli rəqəm sinfi).

---

<!-- Slayd 11 -->
# 🔄 İrəli Yayılma (Forward Propagation)

Məlumat şəbəkə boyunca necə axır?

```
[X (Giriş)] 
     ⬇️   w₁ · X + b₁
[Z₁ (Xətti Cəm)]
     ⬇️   a₁ = ReLU(Z₁)
[A₁ (1-ci Qat Aktivasiyası)]
     ⬇️   w₂ · A₁ + b₂
[Z₂ (2-ci Xətti Cəm)]
     ⬇️   ŷ = Softmax(Z₂)
[Proqnoz (Prediction ŷ)]
```

<div class="box-idea">
💡 <strong>İrəli Yayılma nədir?</strong> Şəbəkəyə şəkli veririk, hər qat öz çəkiləri ilə vurub aktivasiyadan keçirir və sonda bir təxmin (ŷ) irəli sürür: <em>"Bu şəkil 85% ehtimalla pişikdir."</em>
</div>

* Hələlik model heç nə bilmir, çünki çəkilər (weights) təsadüfi (random) rəqəmlərlə başlayıb.

---

<!-- Slayd 12 -->
# 🎯 Xəta Nədir? Loss və Cost Funksiyası

Model təxmin etdi: $\hat{y}$ (Prediction), amma həqiqət başqadır: $y$ (Ground Truth).
Model nə qədər yanıldığını necə ölçür?

<div class="grid-2">
<div>

### 1. MSE (Mean Squared Error)
Reqressiya (ədəd təxmini) üçün:
$$\text{MSE} = \frac{1}{n}\sum (y - \hat{y})^2$$

* Məsələn: Evin qiyməti 100,000$ idi, model 80,000$ dedi.
* Fərq: 20,000$ ➡️ Kvadratı böyük cəza verir!
</div>
<div>

### 2. Cross-Entropy Loss
Təsnifat (Classification) üçün:
$$\text{Loss} = - \sum y \cdot \log(\hat{y})$$

* Model nə qədər əminliklə səhv edərsə, cəza (Loss) bir o qədər eksponensial artır!
* Əgər gerçək = 1, model 0.01 deyirsə ➡️ Cəza çox böyükdür!
</div>
</div>

<div class="box-analogy">
🎯 <strong>Analogiya:</strong> Oxatma yarışında hədəfin mərkəzi ilə oxun düşdüyü yer arasındakı məsafə xətadır. Məqsədimiz bu məsafəni 0-a endirməkdir!
</div>

---

<!-- Slayd 13 -->
# 🏔️ Qradiyent Enişi (Gradient Descent)

Bizim məqsədimiz: **Loss (Xəta) funksiyasını minimuma endirmək.**

```
           Loss (Xəta)
              |
              |       \  (Başlanğıc nöqtəsi - Yüksək Xəta)
              |        \
              |         \  <--- Qradiyent istiqaməti (Aşağıya doğru)
              |          \
              |           '._  (Minimum Xəta Nöqtəsi)
              +------------------------- Çəkilər (Weights, w)
                               w*
```

<div class="box-analogy">
🌫️ <strong>Dumanlı Dağ Metaforası:</strong><br>
Təsəvvür edin ki, qatı duman içində dağın zirvəsindəsiniz və dərəyə (ən aşağı nöqtəyə) enmək istəyirsiniz. Ətrafı görmürsünüz. Nə edərsiniz?
Ayağınızla yerə basıb <strong>torpağın ən çox hansı tərəfə mailli olduğunu</strong> yoxlayarsınız və o tərəfə bir addım atarsınız!
</div>

* 📌 **Qradiyent:** Həmin mailliyin (törəmənin) riyazi adıdır.
* 📌 **Mənfi qradiyent:** Xətanın ən tez azaldığı istiqamətdir.

---

<!-- Slayd 14 -->
# 👟 Təlim Sürəti (Learning Rate - $\alpha$) və Hiperparametrlər

Dağdan düşərkən atdığımız addımın böyüklüyü və həll əyrisi boyunca nöqtələrin seçilməsi:

```
Çox Kiçik (Too Small)             İdeal (Just Right)            Çox Böyük (Too High)
   .                                 .                               .       ^
    \                                 \                             / \     /
     \                                 \                           /   \   /
      \                                 '._                       /     \_/
  (Çox yavaş! 10 ilə çatır)        (Sürətlə minimuma çatır)       (Aşır və partlayır!)
```

<div class="box-idea">
🎛️ <strong>Hiperparametr Nədir?</strong><br>
Dərin öyrənmədə modelin topologiyası və xüsusiyyət mühəndisliyi qədər yekun nəticəyə təsir edən <strong>idarəetmə düymələridir (knobs)</strong>. Həll əyrisi boyunca fərqli nöqtələri nümunələyirik (sampling); Learning Rate addımların bir-birindən nə qədər uzaq olacağını təyin edir!
</div>

<div class="box-math">
📐 <strong>Çəkinin Yenilənmə Düsturu:</strong>
$$W_{\text{yeni}} = W_{\text{köhnə}} - \alpha \cdot \frac{\partial \text{Loss}}{\partial W}$$
</div>

* 🚀 **$\alpha$ çox böyük olsa (Overshoot):** Model optimal minimumun üstündən o tərəf-bu tərəfə tullanır, hədəfi tamamilə qaçırır və xəta partlayır (Divergence).
* 🐢 **$\alpha$ çox kiçik olsa (Yavaş Təlim):** Hər addımda ifrat dərəcədə kiçik məsafə qət olunur; optimumu tapmaq üçün hədsiz çox epox və addım tələb olunur, təlim günlərlə uzanır.

---

<!-- Slayd 15 -->
# ⚙️ Optimizatorlar: Gradient Descent Növləri

Bütün məlumatı birdən hesablayaq, yoxsa hissə-hissə?

| Növ | Necə işləyir? | Üstünlüyü | Çatışmazlığı |
| :--- | :--- | :--- | :--- |
| **Batch GD** | Bütün verilənlər bazasını oxuyub 1 addım atır | Çox sabit və dəqiq | Böyük datada həddən artıq yavaşdır |
| **Stochastic GD (SGD)** | Hər 1 tək nümunə üçün çəkiləri dərhal dəyişir | Çox sürətlidir | Çox xaotik və dalğalı hərəkət edir |
| **Mini-Batch GD** | Məlumatı kiçik dəstələrə (məs: 32, 64) bölür | Həm sürətli, həm sabit | Qızıl orta həddir! |

<div class="box-idea">
👑 <strong>Müasir Kral - Adam (Adaptive Moment Estimation):</strong><br>
Həm addımın sürətini (Momentum), həm də hər parametr üçün fərdi adaptiv təlim sürətini özü avtomatik tənzimləyir. Təcrübədə 90% hallarda <code>Adam</code> seçilir!
</div>

---

<!-- Slayd 16 -->
# ⏪ Geri Yayılma (Backpropagation): Sehr Necə Baş Verir?

Bütün dərin öyrənmənin ən mühüm alqoritmi: **Geri Yayılma (Rumelhart, Hinton, Williams - 1986)**

```
             İrəli Yayılma (Forward Pass) ➡️ Məlumat axır, Xəta hesablanır
   [Giriş X] --------> [Gizli Qat] --------> [Çıxış ŷ] --------> [Loss (Xəta)]
                                                                     |
   [Giriş X] <-------- [Gizli Qat] <-------- [Çıxış ŷ] <-------------+
             Geri Yayılma (Backward Pass) ⬅️ Törəmələr paylanır, Çəkilər yenilənir!
```

<div class="box-analogy">
🏢 <strong>Şirkət Analogiyası:</strong><br>
Bir şirkətdə layihə uğursuz oldu (Böyük Loss). Direktor (Çıxış) günahı menecerlərinə paylayır. Menecerlər günahı öz komanda üzvlərinə ötürür. Hər kəs etdiyi səhvin payı qədər cəzalanır və işini düzəldir!
</div>

---

<!-- Slayd 17 -->
# 🔗 Riyazi Sirr: Zəncir Qaydası (Chain Rule)

Gizli qatdakı bir $w_1$ çəkisi ən sondakı Xətaya necə təsir edir?

$$x \xrightarrow{\quad} z \xrightarrow{\quad} a \xrightarrow{\quad} \text{Loss}$$

Xətanın $w$-yə görə dəyişməsi zəncirvari vurma ilə tapılır:
$$\frac{\partial \text{Loss}}{\partial w} = \frac{\partial \text{Loss}}{\partial a} \cdot \frac{\partial a}{\partial z} \cdot \frac{\partial z}{\partial w}$$

```
[Xətanın Çıxışa Təsiri]  ×  [Aktivasiyanın Təsiri]  ×  [Girişin Çəkiyə Təsiri]
```

<div class="box-idea">
✨ <strong>Niyə bu dahiyanədir?</strong> Biz hər bir qatın törəməsini lokal olaraq hesablayıb bir-birinə vuraraq, ən dərin qatdakı ən kiçik çəkinin belə ümumi səhvə nə qədər cavabdeh olduğunu dəqiqliklə tapırıq!
</div>

---

<!-- Slayd 18 -->
# 🧮 Backpropagation Addım-Addım: Sadə Nümunə ilə İzah

![Backpropagation Rəqəmsal Nümunə](images/slide_backprop_numeric.svg)

Gəlin real rəqəmlərlə modelin səhvindən necə dərs çıxardığına baxaq:
**Giriş:** $x = 2$, **İlkin çəki:** $w = 3$, **Bias:** $b = 1$, **Həqiqi Hədəf:** $y = 10$.

<div class="grid-2">
<div>

### 1️⃣ İrəli Hesablama (Forward):
* $z = x \cdot w + b = 2 \cdot 3 + 1 = 7$
* Proqnoz: $\hat{y} = \text{ReLU}(7) = 7$
* Xəta: $\text{Loss} = (7 - 10)^2 = \mathbf{9}$
</div>
<div>

### 2️⃣ Geri Hesablama (Backprop):
* $\frac{\partial \text{Loss}}{\partial \hat{y}} = 2(7 - 10) = -6$ (Çıxış azdır)
* $\frac{\partial z}{\partial w} = x = 2$ (Girişin çəkiyə təsiri)
* $\frac{\partial \text{Loss}}{\partial w} = (-6) \cdot 1 \cdot 2 = \mathbf{-12}$ (Qradiyent)
</div>
</div>

<div class="box-math">
🛠️ <strong>Çəkinin Yenilənməsi (Learning Rate $\alpha = 0.1$):</strong><br>
<code>w_{\text{yeni}} = w - \alpha \cdot (\frac{\partial \text{Loss}}{\partial w}) = 3 - 0.1 \cdot (-12) = 3 + 1.2 = \mathbf{4.2}</code><br>
Növbəti dəfə model $\hat{y} = 2 \cdot 4.2 + 1 = 9.4$ çıxarır və Xəta $9$-dan $\mathbf{0.36}$-ya enir (96% azalma)!
</div>

---

<!-- Slayd 19 -->
# 🔄 Öyrənmənin Tam Dövrü (Training Loop)

![Təlim Dövrü](images/slide18_training_loop.svg)

Bir model praktiki olaraq necə öyrənir?

```
                    +-----------------------------+
                    | 1. Batch Məlumatı Götür     |
                    +-----------------------------+
                                   ⬇️
                    +-----------------------------+
                    | 2. Forward: Proqnozu Tap    |
                    +-----------------------------+
                                   ⬇️
                    +-----------------------------+
                    | 3. Loss Hesabla (Səhv nədir)|
                    +-----------------------------+
                                   ⬇️
                    +-----------------------------+
                    | 4. Backward: Gradient Tap   |
                    +-----------------------------+
                                   ⬇️
                    +-----------------------------+
                    | 5. Çəkiləri Yenilə (W = W-ηG)|
                    +-----------------------------+
                                   ⬇️
                    Dövrü Təkrar Et (Növbəti Epoch)!
```

* 🔹 **Epoch:** Bütün təlim məlumatlarının modeldən bir tam dəfə keçməsi.
* 🔹 **Batch Size:** Bir addımda paralel baxılan nümunələrin sayı (məs: 32 şəkil).

---

<!-- Slayd 20 -->
# 🎛️ Hiperparametrlərin Tənzimlənməsi: Batch Size və Lokal Minimum

![Batch Size və Lokal Minimum](images/slide20_batch_size_local_minima.svg)

İntuisiyaya zidd məntiq: Niyə kiçik batch ölçüsü çox vaxt daha üstündür?

<div class="box-analogy">
🧠 <strong>İntuisiyaya Zidd Məntiq (Nə qədər çox data, bir o qədər yaxşıdırmı?):</strong><br>
İlk baxışda elə gəlir ki, hər addımda nə qədər böyük batch götürsək, model bir o qədər yaxşı öyrənər. <strong>Lakin bu belə deyil!</strong> Kiçik batch ölçüsünün ən böyük gücü — gradient enişindəki <strong>təhlükəli Lokal Minimumlardan (Local Minima) çıxa bilməsidir</strong>!
</div>

<div class="grid-2">
<div>

### ✅ Kiçik Batch Size (Məsələn, 32 və ya 64):
* Hər kiçik dəstədə təbii stoxastik "səs-küy" (vibrasiya) yaranır.
* Bu titrəmə modeli dayaz yerli dərələrdən tullandıraraq **əsl qlobal minimuma** yönəldir.
* Daha yaxşı ümumiləşdirmə (generalization) qabiliyyəti qazandırır.
</div>
<div>

### ❌ Çox Böyük Batch Size:
* Modeli həddən artıq "ağırlaşdırır" və səhv lokal minimumda ilişdirib saxlayır (stuck).
* Hər epoxda məlumatlar qarışdırıldığı (shuffle) üçün müxtəlif işəsalmalarda **tam fərqli və qeyri-sabit nəticələr** verir.
* Saatlarla məşqdən sonra belə yanlış həllə yaxınlaşa bilər.
</div>
</div>

<div class="box-idea">
📌 <strong>Qızıl Qayda (Yadda saxlayın!):</strong><br>
• <strong>Kiçik Batch:</strong> Lokal minimumlarda ilişib qalmır. <strong>Böyük Batch:</strong> Təsadüfi yanlış həllə ilişib qala bilər.<br>
• <strong>Böyük Learning Rate:</strong> Düzgün həlli tamamilə aşır. <strong>Kiçik Learning Rate:</strong> Təlim vaxtını hədsiz uzadır.
</div>

---

<!-- Slayd 21 -->
# 👁️ Kompüter Görməsi: Niyə Adi MLP Yetmir?

Təsəvvür edin ki, $1000 \times 1000$ ölçülü rəngli (RGB) bir şəkil var:
* $1000 \times 1000 \times 3 = \mathbf{3,000,000\text{ piksel!}}$
* Əgər ilk gizli qatda cəmi 1,000 neyron olsa: $3,000,000 \times 1,000 = \mathbf{3\text{ Milyard Parametr!}}$

<div class="box-analogy">
🛑 <strong>"DUR" (STOP) Nişanı Analoqiyası və Məkan Dəyişməzliyi (Feature-Location Invariance):</strong><br>
Yolda "DUR" nişanı axtarırsınızsa, onun şəklin dəqiq harasında (solunda, sağında, ya da yuxarısında) olacağını əvvəlcədən bilə bilməzsiniz.
* ❌ <strong>Adi MLP Çətinliyi:</strong> Pikselləri düz 1D xətt kimi görür; nişan 2 piksel yana sürüşsə, tamam başqa neyronlar aktivləşir və model çaşır.
* ✅ <strong>CNN-in Gücü:</strong> Şəkli skan edir və axtarılan obraz <strong>şəklin harasında olursa olsun</strong> onu dəqiqliklə tapır!
</div>

* 🖼️ **Təkcə Şəkillər Deyil (1D & 3D CNN):** Mətn və Hissiyyat Analizində (NLP) vacib bir sözün cümlənin əvvəlində və ya sonunda olmasından asılı olmayaraq 1D CNN onu tapır. 3D CNN isə tibbi MRT skanlarında tətbiq olunur.
* 🚗 **Real Həyat Nümunəsi (Tesla Avtopilotu):** Kameralar yoldakı bütün nişanları CNN ilə skan edir. Sürücünün əyləcə basma təcrübəsi mərkəzi serverdə avtopilot CNN şəbəkəsinin təliminə çevrilir.

---

<!-- Slayd 22 -->
# 🔍 CNN-in Əsası: Bioloji İlham və Konvolyusiya

Gözümüzün vizual korteksi və "DUR" nişanının iyerarxik tanınması (Hubel & Wiesel Kəşfi):

```
  Orijinal Şəkil (5x5)          Filtr / Kernel (3x3)         Xüsusiyyət Xəritəsi
  +---+---+---+---+---+                                         (Feature Map)
  | 1 | 0 | 1 | 0 | 0 |              +---+---+---+                  +---+---+---+
  | 0 | 1 | 1 | 1 | 0 |      *       | 1 | 0 | 1 |       ====>      | 4 | 3 | 3 |
  | 1 | 1 | 0 | 1 | 1 |              | 0 | 1 | 0 |                  | . | . | . |
  | 0 | 0 | 1 | 1 | 0 |              | 1 | 0 | 1 |                  | . | . | . |
  | 0 | 1 | 0 | 0 | 1 |              +---+---+---+                  +---+---+---+
  +---+---+---+---+---+
```

<div class="box-idea">
👁️ <strong>Lokal Qəbuledici Sahələr (Local Receptive Fields):</strong><br>
Retinamız bütün mənzərəyə birdən baxmır. Hər bir neyron qrupu görmə sahəsinin kiçik bir hissəsinə cavab verir. Bu kiçik sahələr bir-birinin üstünə örtüşərək (overlapping) bütün görüntünü skan edir — buna riyaziyyatda <strong>Konvolyusiya (Evrişim)</strong> deyilir!
</div>

* 1️⃣ **Aşağı Səviyyə (Kontrast və Kənarlar):** Beynimiz yüksək kontrasta həssasdır (ağ fonda qara yazı). İlk qat filtrləri nişanın kənarlarını, şaquli (|) və üfüqi (—) xətləri tutur.
* 2️⃣ **Orta Səviyyə (Formalar və Hərflər):** Xətlər birləşərək formaları aşkar edir: *"Səkkizbucaqlı (oktaqon) forma və 'STOP' hərfləri"*.
* 3️⃣ **Rəng Kanalları:** Retinadakı RGB hüceyrələri kimi 3 rəng kanalı emal olunur $\to$ *"Qırmızı oktaqon"*.
* 4️⃣ **Yüksək Səviyyə (Qərar):** Beynimiz birləşdirir: *"Qırmızı oktaqon + STOP sözü = Dərhal əyləcə bas!"*

---

<!-- Slayd 23 -->
# 📐 Stride və Padding Nədir?

Filtrin addımlama sürəti və kənar məlumatların qorunması:

<div class="grid-2">
<div>

### 👟 1. Stride (Addım Ölçüsü)
Filtrin hər addımda neçə piksel sağa və aşağı tullanmasıdır:
* **Stride = 1:** Kitabı sözbəsöz oxumaq kimidir (bütün detallar qalır, çıxış böyük olur).
* **Stride = 2:** İki-iki tullanaraq vərəqləmək kimidir (ölçü 2 dəfə kiçilir, hesablama sürətlənir).
</div>
<div>

### 🛡️ 2. Padding (Kənarların Müdafiəsi)
Filtr mərkəzdən dəfələrlə keçir, amma künclərə az toxunur. Nişan küncdədirsə, itə bilər!
* **Valid Padding:** Əlavə bufer artırılmır (şəkil kiçilir).
* **Same Padding:** Kənarlara qoruyucu 0-lar (Zero Padding) düzülür; ölçü qorunur və kənar detallar unudulmur!
</div>
</div>

```
Zero-Padding Nümunəsi:
  0   0   0   0   0
  0  [1   2   3]  0  <--- Kənarlara 0 artıraraq orijinal
  0  [4   5   6]  0       məlumatın künclərini itirmirik!
  0  [7   8   9]  0
  0   0   0   0   0
```

---

<!-- Slayd 24 -->
# 📉 Ölçünü Kiçiltmək: Max Pooling

Məlumatın ekstraktını çıxarmaq və hesablama yükünü azaltmaq:

```
   Giriş (4x4 Matrix)                 2x2 Max Pooling (Stride=2)
  +----+----+----+----+
  | 12 | 20 | 30 |  0 |                  +----+----+
  |  8 | 15 |  2 | 14 |    =========>    | 20 | 30 |
  +----+----+----+----+                  +----+----+
  | 34 | 70 | 37 |  4 |                  | 70 | 37 |
  | 11 | 22 |  9 | 15 |                  +----+----+
  +----+----+----+----+
```

<div class="box-analogy">
🎯 <strong>Əsas Məntiq (Niyə lazımdır?):</strong><br>
Obyektin vacib xüsusiyyətini tapdıqdan sonra onun dəqiq hansı millimetrdə olması vacib deyil! Əsas odur ki, <strong>bu 2x2 bölgədə "DUR" nişanının kənarı VAR!</strong>
</div>

* ⚡ **Hesablama Yükünü 75% Azaldır:** CNN-lər çox ağır hesablama tələb edir. Hər 2x2 blokdan yalnız ən böyük rəqəmi götürməklə parametrlər 4 dəfə azalır.
* 🛡️ **Məkan Dayanıqlılığı (Spatial Invariance):** Obyekt bir az əyilsə və ya silkələnsə belə, ən güclü siqnal qorunur. Lazımsız fon səs-küyü atılır, əsas cizgilər saxlanılır.

---

<!-- Slayd 25 -->
# 🖼️ Tam CNN Arxitekturası: Şəkildən Qərara

```
[Giriş: 224x224 Şəkil]
         ⬇️
[Conv + ReLU]  -----> Aşağı səviyyəli xüsusiyyətlər (Xətlər, kənarlar)
         ⬇️
[Max Pooling]  -----> Ölçü kiçilir, vacib ekstrakt qalır
         ⬇️
[Conv + ReLU]  -----> Orta səviyyəli xüsusiyyətlər (Gözlər, formalar)
         ⬇️
[Max Pooling]  -----> Hesablama yükü azalır
         ⬇️
[Flatten]      -----> 2D xəritələr 1D düz vektora çevrilir
         ⬇️
[Dense / MLP]  -----> Bildiyimiz adi Perseptron qərar çıxarır!
         ⬇️
[Softmax]      -----> 98% "DUR" Nişanı 🛑 | 2% Digər
```

<div class="box-idea">
💡 <strong>CNN-in Sehri Harada Baş Verir?</strong><br>
Bütün möcüzə aşağı konvolyusiya və pooling qatlarında baş verir — 2D şəkil süzülür, kənarlar və formalar çıxarılır. <strong>Flatten</strong> qatında bu xüsusiyyətlər 1D düz vektora çevrilir və ən sonda bildiyimiz adi bir <strong>Perseptron (Dense Layer)</strong> qərar verir!
</div>

### 🏆 Dünyaca Məşhur Hazır CNN Arxitekturaları:
* 📜 **LeNet-5 (1998, Yann LeCun):** Əlyazma rəqəmləri (MNIST) üçün pioner şəbəkə.
* 🚀 **AlexNet (2012):** ImageNet-də GPU ilə qalib gələrək Dərin Öyrənmə inqilabını başladan şəbəkə.
* 🧠 **GoogLeNet / Inception:** Konvolyusiyaları paralel qruplaşdıran modul optimizasiyası.
* 👑 **ResNet (Residual Networks):** 100+ qatlıq dərinlikdə "atlama əlaqələri" (*Skip Connections*) ilə müasir avtopilot standartı!

---

<!-- Slayd 26 -->
# ⏳ Zaman və Mətn: Niyə RNN Lazımdır?

![RNN Yaddaş Axını](images/slide24_rnn_unfolded.svg)

CNN və MLP-nin böyük bir zəifliyi var: **Onların yaddaşı yoxdur!**  
Hər bir girişi digərindən asılı olmayan müstəqil hadisə kimi görürlər.

<div class="box-idea">
💡 <strong>Ardıcıllıq Nədir?</strong> Zaman və ya sıra ilə düzülən məlumatlar: veb-server loqları, IoT sensorları, birja qiymətləri, avtopilotun keçmiş döngə trayektoriyası və süni intellektlə musiqi bəstələnməsi (not ardıcıllığı!). Cümlələrdə sözlərin sırası mənaya birbaşa hökm edir.
</div>

### 🌐 4 Əsas RNN Topologiyası:
1. 🔄 **Dizidən Diziyə (Seq2Seq):** Zaman sırası ➡️ Zaman sırası (Səhm qiymətləri və ya hava proqnozu).
2. 📝 **Dizidən Vektora (Seq2Vec):** Mətn ardıcıllığı ➡️ Tək qərar (Film rəyinin hissiyyat analizi - IMDb: Müsbət/Mənfi).
3. 🖼️ **Vektordan Diziyə (Vec2Seq):** Tək şəkil ➡️ Sözlər ardıcıllığı (Şəkil üçün avtomatik altyazı - Image Captioning).
4. 🌐 **Encoder - Decoder:** Fransızca cümlə ➡️ Məna vektoru ➡️ İngiliscə cümlə (Google Translate).

---

<!-- Slayd 27 -->
# 🔁 RNN Anatomiyası: Zaman Boyunca Açılma (Unfolding)

![RNN Hüceyrə Anatomiyası](images/slide25_rnn_cell.svg)

```
                       hₜ (Gizli Vəziyyət - Yaddaş)
                                ^
                                |
                        +---------------+
     hₜ₋₁ ------------> |   tanh        | ------------> hₜ (Növbəti addıma)
   (Keçmiş Yaddaş)      +---------------+
                                ^
                                |
                                xₜ (İndiki Giriş / Söz)
```

<div class="box-analogy">
🔄 <strong>Ən Böyük Fərq: Dövrə (Loop):</strong><br>
Tək bir təkrarlanan neyron hər addımda iki giriş alır: <strong>bu an daxil olan yeni məlumat (xₜ)</strong> və <strong>əvvəlki addımın özünə geri qayıdan çıxışı (hₜ₋₁)</strong>. Toplayır, <code>tanh</code> aktivasiyası ilə (-1, +1) aralığında yumşaq şəkildə qoruyur və növbəti addıma ötürür.
</div>

* 🧠 **Hafizə Hüceyrəsi (Memory Cell):** Eyni neyron zaman boyunca açıldıqda (t = 0, t = 1, t = 2), hər addımda keçmiş davranış gələcək addımlara miras qalır. Qat daxilində çoxlu neyron birləşərək üfüqi miqyaslanır.
* ⚠️ **Təbii Qüsur: Seyrəlmə Effekti:** Zaman irəlilədikcə köhnə addımların təsiri seyrəlir (durulur), ən son addımlar isə daha çox hökm edir. Cümlələrdə isə ən başdakı söz axırdakından daha vacib ola bilər!

---

<!-- Slayd 28 -->
# ⚠️ RNN Təliminin Sirri: Zamanda Geri Yayılma (BPTT)

![Vanishing Gradient Problemi](images/slide26_vanishing_gradient.svg)

<div class="box-idea">
⏳ <strong>Backpropagation Through Time (BPTT):</strong><br>
Təlim zamanı arxaya yayılma təkcə laylar üzrə deyil, <strong>bütün zaman addımları boyunca keçmişə doğru</strong> getməlidir! Hər zaman addımı neyron şəbəkəsində əlavə bir virtual qat kimidir (100 sözlük cümlə = 100 qatlıq dərinlik!).
</div>

* ❌ **Vanishing Gradient Tələsi:** Zəncir qaydası ilə törəmələr 100 addım arxaya vurulduqca qradiyent 0-a bərabər olur. Nəticədə model cümlənin əvvəlindəki açar sözləri tamamilə unudur!
* ⏱️ **Həll: Truncated BPTT:** Hesablama yükünü cilovlamaq üçün geri yayılmanı məhdud sayda zaman addımı ilə (məsələn, son 30-50 addım) saxlayırıq. Lakin uzaq yaddaş problemi hələ də qalır!
* ⚙️ **Hiperparametr Həssaslığı:** RNN-lər hiperparametrlərə çox həssasdır; səhv qurularsa saatlarla təlim olunub heç vaxt konvergensiya etməyə bilər.

---

<!-- Slayd 29 -->
# 🛡️ Xilaskar: LSTM (Long Short-Term Memory)

Hochreiter & Schmidhuber (1997) tərəfindən yaradılmış dahiyanə arxitektura.

```
                 Cell State (Magistral Xətt - Dəyişmədən axır)
         Cₜ₋₁ -----------------------------------------> Cₜ
                   \         \              /
                 [Forget]   [Input]     [Output]
                  Qapısı     Qapısı      Qapısı
                   /         /              /
         hₜ₋₁ ----+---------+--------------+-----------> hₜ
                   |
                  xₜ
```

<div class="box-analogy">
🛣️ <strong>Məlumat Magistralı (Cell State - Cₜ):</strong><br>
LSTM-in ən böyük kəşfi: həm qısamüddətli (hₜ), həm uzunmüddətli (Cₜ) yaddaşı paralel saxlayır. Magistral xətt cümlənin başından sonuna qədər heç bir zəiflədici matris vurması olmadan axır — qradiyentlər 100+ addım boyunca heç vaxt itmir!
</div>

* 🚪 **1. Forget Gate (Unutma Qapısı):** Köhnə cümlə bitibsə və ya mövzu dəyişibsə, lazımsız keçmişi silir.
* 🚪 **2. Input Gate (Giriş Qapısı):** Yeni gələn sözün hansı vacib xüsusiyyətini uzunmüddətli yaddaşa əlavə edək?
* 🚪 **3. Output Gate (Çıxış Qapısı):** Magistraldakı zəngin yaddaşdan yalnız bu an üçün ən vacib nəticəni növbəti addıma süzür.

---

<!-- Slayd 30 -->
# 🤝 LSTM-in Sadələşdirilmiş Qardaşı: GRU

**GRU (Gated Recurrent Unit - Cho et al., 2014):**

<div class="box-analogy">
🎒 <strong>Çanta Analogiyası:</strong><br>
LSTM 3 fərqli bölməsi və çoxlu kəmərləri olan böyük səyahət çamadanıdırsa, GRU hər şeyin bir yerdə səliqəli yerləşdiyi yüngül kürək çantasıdır. Demək olar ki, eyni dəqiqliyi verir, lakin parametrləri az olduğuna görə qat-qat sürətli təlim olunur!
</div>

<div class="grid-2">
<div>

### ⚡ 2 Sadələşdirilmiş Qapı:
* **Reset Gate:** Keçmiş yaddaşın nə qədərini sıfırlayaq?
* **Update Gate:** LSTM-in Forget və Input qapılarının vahid hibrididir.
</div>
<div>

### ⚖️ Nə Zaman Hansını Seçməli?
* Çox böyük data və məhdud hesablama gücü varsa ➡️ **GRU** (sürətli kompromis).
* Çox uzun və mürəkkəb ardıcıllıqlar varsa ➡️ **LSTM** (maksimum yaddaş).
</div>
</div>

---

<!-- Slayd 31 -->
# 🌟 Yeni Era: Attention Mexanizmi (Diqqət)

![Attention Mexanizmi](images/slide29_attention_mechanism.svg)

<div class="box-idea">
🍾 <strong>Şüşə Boğazı (Information Bottleneck) Problemi:</strong><br>
Təsəvvür edin: 100 sözdən ibarət bütöv bir mətni oxuyursunuz. Ənənəvi LSTM bu 100 sözün bütün mənasını tək bir kiçik vektora sıxmağa məcbur idi! Bu, mətn uzandıqca incə məna çalarlarının itməsinə gətirib çıxarırdı.
</div>

* 💡 **Attention İdeyası (Bahdanau et al., 2014):** Bütün mətni tək qutuya sıxışdırmaq məcburiyyətində deyilik! Hər yeni söz tərcümə olunarkən orijinal cümlənin **ən uyğun sözlərinə birbaşa "diqqət" yetirir** (Dinamik çəkilər).
* 🎯 **Kontekst Əlaqəsi:** *"Bank"* sözü mətndə çay kənarıdır, yoxsa maliyyə qurumu? Attention sözü əhatə edən bütün qonşu sözlərlə əlaqələndirərək dəqiq mənanı tapır.

---

<!-- Slayd 32 -->
# 👑 Transformer Arxitekturası: "Attention Is All You Need"

Vaswani et al. (Google, 2017) süni intellektdə inqilab etdi: **Bütün təkrarlanan qatları (RNN) atın, yalnız Attention saxlayın!**

![Transformer Arxitekturası](images/slide30_transformer_architecture.svg)

<div class="box-idea">
🚀 <strong>Niyə Dünyanı Dəyişən İnqilab Oldu? (Paralel Emal):</strong><br>
RNN və LSTM addım-addım (ardıcıl) işləyirdi: 100-cü sözü oxumaq üçün 1-dən 99-a qədər gözləməli idi (GPU-lar boş qalırdı). Transformer isə bütün cümləni <strong>eyni anda (paralel) GPU-ya ötürür</strong>! Təlim minlərlə dəfə sürətləndi və internet boyda nəhəng datanı öyrənmək mümkün oldu.
</div>

* 🤖 **Bütün müasir LLM-lər** (ChatGPT, Claude, Gemini, Llama) məhz bu Transformer və Self-Attention arxitekturasının üzərində qurulub!

---

<!-- Slayd 33 -->
# ⚠️ Modelin Əsas Xəstəliyi: Overfitting və 3 Məlumat Dəsti

![Underfitting vs Optimal vs Overfitting](images/slide31_overfitting_underfitting.svg)

<div class="box-analogy">
📈 <strong>Yaşıl Əyri vs Qara Xətt (Aşırı Uyum Nədir?):</strong><br>
Təsəvvür edin: Mavi nöqtələri qırmızı nöqtələrdən ayırırıq. Beynimiz asanlıqla aradakı ümumi hamar xətti (qara) görür. Lakin dərin şəbəkə çoxlu çəki və neyrona malik olduğuna görə məlumatdakı bütün təsadüfi küyə girib-çıxan <strong>qıvrım yaşıl əyrini</strong> öyrənə bilər! Təlimdə 100% yığsa da, bu sadəcə küyün əzbərlənməsidir.
</div>

<div class="grid-2">
<div>

### 🛑 Overfitting Əlaməti:
* Təlim dəstində (Training Set) dəqiqlik artır (**99%**)
* Amma Yoxlama/Test dəstində dəqiqlik aşağı qalır (**60%**)
* Model dərsi anlamayıb, cavabları və təsadüfi küyü əzbərləyib!
</div>
<div>

### 📊 3 Məlumat Dəsti Bölünməsi:
* 1️⃣ **Training Set:** Modelin çəkilərini öyrənmək üçün daxil olan əsas məlumat.
* 2️⃣ **Validation (Evaluation) Set:** Hər epoxda modelin real vəziyyətini izləyən nəzarət dəsti.
* 3️⃣ **Test Set:** Təlim tam bitdikdən sonra yekun modeli sınaqdan keçirən müstəqil dəst.
</div>
</div>

---

<!-- Slayd 34 -->
# 🛡️ Requlyarizasiya (Regularization): Overfitting-ə Qarşı 3 Qızıl Silah

![Requlyarizasiya Texnikaları](images/slide34_regularization_techniques.svg)

Modeli küyü əzbərləməkdən və dalğalanmaqdan qorumaq üçün üsullar:

<div class="grid-2">
<div>

### 1️⃣ Modeli Sadələşdirmək:
Ən təbii tənzimləmə: daha az qat və daha az neyron istifadə etmək. Əgər test dəstində eyni dəqiqliyi verirsə, nəyə lazımdır artıq neyronlar saxlayıb küyü əzbərləmək?
</div>
<div>

### 2️⃣ Dropout (Tərk Etmə - Məs: 50%):
Hər təlim addımında təsadüfi seçilən neyronlar (50%-ə qədər) müvəqqəti söndürülür. Bu, öyrənməni bütün komandaya yayır; heç bir neyron təkbaşına küyü əzbərləyə bilmir (CNN-lərdə standartdır).
</div>
</div>

<div class="box-analogy">
🛑 <strong>3️⃣ Erkən Dayandırma (Early Stopping) — 5-ci Epox Nümunəsi:</strong><br>
Təlim zamanı Training accuracy artmağa davam edir (95% ➡️ 97% ➡️ 99%), lakin Validation accuracy 5-ci epoxdan sonra sabitlənir (~98%) və yellənməyə başlayır. Deməli, 5-ci epoxdan o tərəfə model ancaq küyü əzbərləyir və zərər vurur! Early Stopping alqoritmi bunu avtomatik aşkar edib təlimi məhz 5-ci epoxda saxlayır.
</div>

---

<!-- Slayd 35 -->
# 🎯 Yekun Xülasə: Dərin Öyrənmə 5 Cümlədə

1. 🔹 **Neyron:** Sadə riyazi vurma-toplama (`W·X + b`) və qərar verici aktivasiya qapısıdır.
2. 🔹 **Qatlar:** Tək neyronun bacarmadığını qat-qat birləşən minlərlə neyron möcüzəvi şəkildə həll edir.
3. 🔹 **Öyrənmə:** Modelin irəli təxmin edib, səhvini (Loss) ölçməsi və arxaya qayıdaraq (Backpropagation) çəkilərini düzəltməsidir.
4. 🔹 **CNN və RNN:** Şəkillər üçün məkana baxan filtrli CNN, mətn və ardıcıllıq üçün yaddaşı olan RNN/LSTM istifadə olunur.
5. 🔹 **Transformer:** Bütün bunların zirvəsi olaraq hər şeyə eyni anda diqqət yetirən (Self-Attention) müasir intellekt mühərrikidir.

---
