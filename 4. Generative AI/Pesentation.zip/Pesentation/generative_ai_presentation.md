---
marp: true
theme: default
paginate: true
header: "Generative AI: Transformatorlar və LLM | Dərs 1: The Transformer Architecture"
footer: "Müəllif: Təlimçi / Mühazirəçi | Generative AI & LLM Əsasları"
style: |
  section {
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    font-size: 20px;
    line-height: 1.5;
    padding: 35px 50px;
    background-color: #0b1120;
    color: #e2e8f0;
  }
  .top-header-title {
    font-size: 13px;
    font-weight: 600;
    color: #94a3b8;
    background: rgba(30, 41, 59, 0.7);
    border: 1px solid #334155;
    padding: 4px 12px;
    border-radius: 6px;
    margin-bottom: 12px;
    display: inline-block;
  }
  .top-header-title strong {
    color: #38bdf8;
  }
  .top-header-title .sep {
    color: #64748b;
    margin: 0 6px;
  }
  .top-header-title .lesson {
    color: #fbbf24;
  }
  h1 {
    color: #38bdf8;
    font-size: 34px;
    margin-bottom: 10px;
    border-bottom: 2px solid #1e293b;
    padding-bottom: 8px;
  }
  h2 {
    color: #818cf8;
    font-size: 24px;
    margin-bottom: 10px;
  }
  h3 {
    color: #f472b6;
    font-size: 20px;
    margin-bottom: 6px;
  }
  strong {
    color: #38bdf8;
  }
  em {
    color: #fbbf24;
    font-style: normal;
  }
  code {
    background: #1e293b;
    color: #38bdf8;
    padding: 3px 8px;
    border-radius: 4px;
    font-size: 0.95em;
    font-family: 'Consolas', 'Courier New', monospace;
  }
  pre {
    background: #0f172a;
    border: 1px solid #334155;
    border-radius: 8px;
    padding: 10px;
    font-size: 13px;
    color: #38bdf8;
    line-height: 1.25;
  }
  .box-idea {
    background: rgba(56, 189, 248, 0.1);
    border-left: 5px solid #38bdf8;
    padding: 10px 16px;
    border-radius: 4px;
    margin: 10px 0;
  }
  .box-analogy {
    background: rgba(52, 211, 153, 0.1);
    border-left: 5px solid #34d399;
    padding: 10px 16px;
    border-radius: 4px;
    margin: 10px 0;
  }
  .box-warning {
    background: rgba(239, 68, 68, 0.1);
    border-left: 5px solid #ef4444;
    padding: 10px 16px;
    border-radius: 4px;
    margin: 10px 0;
  }
  .box-math {
    background: rgba(244, 114, 182, 0.1);
    border-left: 5px solid #f472b6;
    padding: 10px 16px;
    border-radius: 4px;
    margin: 10px 0;
  }
  .speaker-notes {
    background: rgba(251, 191, 36, 0.08);
    border: 1px dashed #fbbf24;
    padding: 8px 12px;
    font-size: 13px;
    color: #fde68a;
    border-radius: 6px;
    margin-top: 8px;
  }
  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 8px;
    font-size: 15px;
  }
  th {
    background-color: #1e293b;
    color: #38bdf8;
    border: 1px solid #334155;
    padding: 8px;
    text-align: left;
  }
  td {
    border: 1px solid #334155;
    padding: 6px 10px;
    background-color: #0f172a;
  }
  .grid-2 {
    display: grid;
    grid-template-columns: 1fr 1.35fr;
    gap: 25px;
    align-items: center;
  }
  .diagram-img {
    background: #0b1120;
    border: 1px solid #1e293b;
    border-radius: 10px;
    padding: 10px;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .diagram-img img {
    max-height: 520px;
    width: 100%;
    object-fit: contain;
  }
---

<!-- Slayd 0: Dərs 1 Titul Slaydı -->

# 🚀 The Transformer Architecture: Təbii Dil Emalında İnqilab
### RNN-lərdən ChatGPT və GPT-4-ə Doğru

<div class="box-idea">
💡 <strong>Dərsin Məqsədi:</strong> Transformator (Transformer) arxitekturasının nə üçün Süni İntellektdə ən böyük sıçrayış olduğunu addım-addım kəşf etmək: RNN məhdudiyyətlərindən Encoder-Decoder və Self-Attention paralel emal gücünə keçid.
</div>

* 🔹 **GPT (Generative Pre-trained Transformer) və ChatGPT-dəki "T":** *Transformer* deməkdir.
  * • *Generativ Əvvəlcədən Təlim Keçmiş Transformator:* nəhəng mətn korpusunda öncədən öyrədilmiş və yeni mətn hasil edən arxitektura.
* 🔹 **Tarixi kontekst və BERT (Bidirectional Encoder Representations from Transformers):**
  * • *Transformatorlardan İkiistiqamətli Encoder Təqdimatları:* mətni həm soldan sağa, həm də sağdan sola eyni vaxtda oxuyub dərindən anlayan model.
* 🔹 **İnqilabın Başlanğıcı:** 2017-ci il – Google-un *"Attention Is All You Need"* elmi məqaləsi.
* 🔹 **Niyə vacibdir?** Məlumat həcmini və parametrləri trilyonlara çatdırmağa imkan verən paralel emal açarı.

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Transformator arxitekturası müasir böyük dil modellərinin (LLM) təməlini təşkil edir. Bu modulda RNN-lərin ardıcıl emal məhdudiyyətləri, informasiya tıxacı və 2017-ci ildə "Attention Is All You Need" elmi məqaləsi ilə təqdim edilən Self-Attention paralel emal mexanizmi ardıcıllıqla izah edilir.
</div>

---

<!-- Slayd 1: The Evolution of Transformers - RNN & LSTM -->

# 🔄 Transformatorların Təkamülü: RNN və LSTM
### Ardıcıl Verilənlərin Modelləşdirilməsi və Əks-Əlaqə Dövrəsi (Feedback Loop)

<div class="grid-2">
<div>

* 🔹 **RNN (Recurrent Neural Networks) & LSTM:**
  * NLP və ardıcıl məlumatlar üçün əsas standart idi.
* 🔹 **Əks-əlaqə dövrəsi (Feedback loop):**
  * Hər addımda yaranan gizli vəziyyət (*Hidden State*) növbəti addımın girişinə ötürülür.
* 🔹 **Tətbiq sahələri:**
  * 📈 **Time Series:** Birja qiymətləri, hava proqnozu.
  * 💬 **Dil Modelləri:** Sözlər ardıcıllığı (tokenlər).
  * 🎬 **Sentiment Analizi:** Film rəylərinin müsbət/mənfi təhlili.

</div>
<div>

<div class="diagram-img"><img src="images/slide01_rnn_loop.svg" alt="RNN Loop Diagram"></div>

<div class="box-analogy">
🧩 <strong>Analogiya:</strong> Kitab oxuyan insan kimi: hər yeni sözü oxuduqca beynindəki mövcud yaddaşı yeniləyir və növbəti sözə keçir.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Klassik yanaşmada ardıcıl məlumatları emal etmək üçün RNN və LSTM istifadə olunurdu. Əsas ideya: cari sözü emal edərkən əvvəlki addımdan gələn gizli vəziyyəti də nəzərə almaq idi.
</div>

---

<!-- Slayd 2: Encoder / Decoder & İnformasiya Tıxacı -->

# 🚧 Encoder / Decoder Arxitekturası və İnformasiya Tıxacı
### Maşın Tərcüməsi (Machine Translation) və Tək Vektor Məhdudiyyəti

<div class="grid-2">
<div>

* 🔹 **Seq2Seq (Sequence-to-Sequence / Ardıcıllıqdan-Ardıcıllığa):**
  * Bir mətni və ya simvol ardıcıllığını digər ardıcıllığa çevirən model arxitekturası (məsələn: Maşın tərcüməsi, mətni xülasələşdirmə).
* 🔹 **Encoder / Decoder Arxitekturası:**
  * **Encoder RNN:** Giriş cümləsini oxuyub gizli vəziyyət vektorlarına çevirir.
  * **Decoder RNN:** Hədəf dildə (məs. Klingon) sözləri addım-addım çıxarır.
* ⚠️ **Əsas Problem: İnformasiya Tıxacı (Information Bottleneck):**
  * Bütün cümlənin mənası cəmi **TƏK BİR VEKTORA** (*Last Hidden State*) sığışdırılmalıdır!
* 📉 **Məlumatın İtməsi:** Cümlə uzandıqca əvvəldəki sözlər tədricən "unudulur" və ya zəifləyir.
* ⏱️ **Paralelləşdirmə qeyri-mümkündür:** Sözlər tək-tək, ardıcıl daxil edilməlidir.

</div>
<div>

<div class="diagram-img"><img src="images/slide02_seq2seq_bottleneck.svg" alt="Seq2Seq Bottleneck Diagram"></div>

<div class="box-warning">
⚠️ <strong>Bottleneck effekti:</strong> 50 sözlük mürəkkəb bir cümlənin bütün leksik yükünü tək bir vektor daxilində qorumaq mümkün olmur.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Encoder hər sözü ardıcıl oxuyub sonda tək bir gizli vektor yaradır. Decoder isə ancaq bu tək vektora baxaraq tərcümə etməlidir. Bu dar boğaz nəhəng informasiya itkisinə səbəb olur.
</div>

---

<!-- Slayd 3: Attention Is All You Need (2017) -->

# ✨ "Attention is All You Need" – Diqqət Mexanizminin Doğuluşu
### Hər Addım Üçün Fərdi Vəziyyət və Çəkili Diqqət (Attention Weights)

<div class="grid-2">
<div>

* 💡 **İnqilabi Yanaşma (2017):**
  * Tək bir son vəziyyət əvəzinə, hər bir söz üçün fərdi gizli vəziyyət saxlanılır: `State 1`, `State 2`, `State 3`.
* 🎯 **Diqqət Çəkiləri (Attention Weights):**
  * Decoder növbəti sözü generasiya edərkən Encoder-in **bütün gizli vəziyyətlərinə** müxtəlif ağırlıqlarla müraciət edə bilir.
* 🌐 **Söz Sırası və Kontekst:**
  * Dillər arasındakı söz sırası fərqləri asanlıqla həll olunur; sözlər arası məna əlaqəsi dərk edilir.
* ⏳ **Hələ də aradan qalxmayan problem:**
  * Təməl yenə RNN olduğu üçün ardıcıllıq qalır — paralelləşmir!

</div>
<div>

<div class="diagram-img"><img src="images/slide03_attention_is_all_you_need.svg" alt="Attention Mechanism Diagram"></div>

<div class="box-idea">
🔑 <strong>Açar kəşf:</strong> Model hər sözü tərcümə edərkən giriş cümləsində məhz hansı sözlərə "diqqət yetirməli" olduğunu riyazi çəkilərlə hesablayır.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Artıq tək bir son vektor yoxdur. 'Please', 'Translate' və 'Me' sözlərinin hər birinin öz State-i saxlanılır və Decoder onlara diqqət çəkiləri paylayır. Lakin təməldə RNN qaldığı üçün hələ də ardıcıldır.
</div>

---

<!-- Slayd 4: Transformers & Self-Attention -->

# ⚡ Transformatorlar: RNN-lərə Əlvida, Paralel Emala Salam!
### Feed-Forward Şəbəkələri (FFNN), "Self-Attention" və Böyük Modellər

<div class="grid-2">
<div>

* 🚀 **RNN-lərdən Tam İmtina:**
  * Dövrü əlaqələr atılır! Yerini **Feed-Forward Neyron Şəbəkələri (FFNN)** alır.
* 🧠 **Özünə-Diqqət (Self-Attention):**
  * Girişdəki bütün tokenlər eyni anda bir-biri ilə müqayisə edilir və kontekst çəkiləri hesablanır.
* ⚡ **Tam Paralelləşmə (Massive Parallelism):**
  * "Please", "Translate" və "Me" sözləri **eyni anda** GPU/TPU-da emal olunur.
* 📚 **Nəticə:**
  * Trilyonlarla parametr, bütün Wikipedia, Reddit və kitablar üzərində təlim! GPT-4 və ChatGPT-ni doğuran əsas güc.

</div>
<div>

<div class="diagram-img"><img src="images/slide04_transformer_self_attention.svg" alt="Transformer Architecture Diagram"></div>

<div class="box-idea">
💥 <strong>Əsas İnqilab:</strong> Self-Attention təlimi <em>paralelləşdirdi</em>. Məhz buna görə nəhəng modelləri öyrətmək mümkün oldu!
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Transformatorun əsl sehri: RNN-ləri çıxarıb standart Feed-Forward şəbəkələrlə əvəz etmək və sözlər arası konteksti Self-Attention ilə paralel hesablamaqdır.
</div>

---

<!-- Slayd 5: Xülasə və Müqayisə Cədvəli -->

# 📊 Təkamül Mərhələlərinin Müqayisəsi

| Meyar | 1. Klassik RNN / LSTM | 2. Seq2Seq + Attention | 3. Transformer (Müasir LLM) |
| :--- | :--- | :--- | :--- |
| **Arxitektura** | Dövrü (Recurrent) dövrələr | RNN Encoder-Decoder + Attention | **Feed-Forward + Self-Attention** |
| **Kontekst Ötürülməsi** | Tək son gizli vəziyyət (Bottleneck) | Token başına gizli vəziyyətlər | **Çoxbaşlı Özünə-Diqqət (Multi-Head)** |
| **Emal Xarakteri** | ❌ Tamamilə ardıcıl (Sequential) | ❌ Hələ də ardıcıl (RNN əsaslı) | ✅ **Tam Paralel (Parallelizable)** |
| **Uzun Mətnlərdə Yaddaş** | Zəif (Unutma problemi var) | Orta-Yaxşı (Attention kömək edir) | **Əla (Bütün tokenlər birbaşa bağlıdır)** |
| **Genişlənmə (Scaling)** | Məhdud (Böyük data ilə öyrədilmir) | Çətin və yavaş | **Limitsiz (Trilyon parametr, PetaBayt data)** |
| **Nümunə Modellər** | Sadə LSTM, Elman RNN | Luong/Bahdanau Seq2Seq | **GPT-4, Claude, BERT, LLaMA, Gemini** |

<div class="box-analogy">
🏁 <strong>Xülasə Nəticə:</strong> Əgər RNN-lər tək xətli dəmiryolu idisə, Transformatorlar minlərlə zolaqlı super-magistraldır.
</div>

---

<!-- Slayd 6: Dərs 2 Titulu -->
<!-- header: "Generative AI: Transformatorlar və LLM | Dərs 2: Self-Attention, Masked Self-Attention, and Multi-Headed Self-Attention in depth" -->

# 🧠 Dərs 2: Self-Attention və Multi-Headed Attention Dərindən
### Transformatorların Daxili Riyazi Mexanizmi: Q, K, V, Z və Diqqət Başlıqları

<div class="box-idea">
🎯 <strong>Dərsin Məqsədi:</strong> Transformatorların daxili riyazi aparatını tam mənimsəmək: Token embeddingləri, Polisemiya, Öyrənilən Matrislər (Wq, Wk, Wv), Scaled Dot-Product, Causal Masking, Dəyərlərin çəkili cəmi (Z) və Multi-Head paralelləşməsi.
</div>

* 🔹 **Hissə 1:** Embeddinglər, Polisemiya, Q, K, V Proyeksiyaları, Scaled Dot-Product və Maskalanma.
* 🔹 **Hissə 2:** Dəyərlərin Vurulması və Cəmlənməsi (Z Vektoru), FFNN Keçidi və Multi-Headed Attention.

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> İndi isə Transformatorların ən dahi kəşfi olan Self-Attention-ın daxili riyaziyyatına enirik. Əvvəlcə tək başlıqlı diqqəti, ardınca çoxbaşlı multi-head strukturunu görəcəyik.
</div>

---

<!-- Slayd 7 (Şəkil 1): Self-Attention (in more depth) - Embeddings & Polysemy -->

# 📖 Self-Attention: Embeddinglər və Çəkili Ortalama
### Eyni Söz, Fərqli Kontekstual Məna: "Novel" (Kitab) vs "Novel" (Orijinal)

<div class="grid-2">
<div>

* 🔹 **Tokenlər Vektorlara Çevrilir (Embeddings):**
  * Hər token çoxölçülü məkanda bir nöqtədir (vektor). Məna yaxınlığı vektorların arasındakı məsafə ilə ölçülür.
* 🔹 **Çəkili Ortalama (*Weighted Average*):**
  * Self-Attention bütün tokenlərin embeddinglərinin çəkili ortalamasını çıxarır. Əsas məharət **diqqət çəkilərini** hesablamaqdadır.
* 🔹 **Polisemiya (Eyni söz, fərqli mənalar):**
  * 📗 *"I read a good **novel**."* ➔ *"read"* sözü ilə güclü əlaqə qurur ➔ Məna: **Book (Kitab)**.
  * 💡 *"Attention is a **novel** idea."* ➔ *"idea"* sözü ilə güclü əlaqə qurur ➔ Məna: **Original / New (Orijinal İdeya)**.

</div>
<div>

<div class="diagram-img"><img src="images/slide06_self_attention_polysemy.svg" alt="Self-Attention Polysemy Diagram"></div>

<div class="box-idea">
🎯 <strong>Kontekstual Nəticə:</strong> Self-Attention nəticəsində yaranan yeni embedding sözün lüğəvi deyil, məhz həmin cümlədəki <em>həqiqi kontekstual mənasını</em> əks etdirir.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> İngilis dilində 'novel' həm roman (kitab), həm də yeni/orijinal deməkdir. Self-Attention ətrafdakı sözlərin təsiri ilə hər cümlədə fərqli kontekstual vektor formalaşdırır.
</div>

---

<!-- Slayd 8 (Şəkil 2): 3 Learned Matrices (Wq, Wk, Wv) & Vectors -->

# 🧮 Self-Attention Mexanizmi: 3 Öyrənilən Matris
### Query (Wq), Key (Wk) və Value (Wv) Vektorlarının Yaradılması

<div class="grid-2">
<div>

* 🔹 **3 Əsas Çəki Matrisi:**
  * Model təlim olunduqca (Backpropagation vasitəsilə) 3 matris öyrənir:
    * 🟢 **Query (Wq):** "Mən nə axtarıram?" (Sorğu)
    * 🟡 **Key (Wk):** "Məndə hansı məlumat var?" (Açar)
    * 🔴 **Value (Wv):** "Mənim daşıdığım həqiqi məna nədir?" (Dəyər)
* 🔹 **Hər Token Üçün Vektor Proyeksiyası:**
  * Hər bir tokenin ilkin embedding vektoru (`x`) bu 3 matrisə vurulur:
    `q = x · Wq,  k = x · Wk,  v = x · Wv`
* ⚡ Bu əməliyyat bütün tokenlər üçün **paralel** icra edilir!

</div>
<div>

<div class="diagram-img"><img src="images/slide07_qkv_matrices.svg" alt="QKV Matrices Diagram"></div>

<div class="box-analogy">
🔍 <strong>Analogiya (YouTube Axtarışı):</strong> <em>Query</em> axtarış çubuğuna yazdığınız sorğudur, <em>Key</em> videolara qoyulmuş etiketlər/başlıqlardır, <em>Value</em> isə uyğun gələn videonun faktiki məzmunudur.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Hər bir söz üçün 3 fərqli vektor hesablayırıq: q, k və v. Model məhz bu 3 matris vasitəsilə hansı sözün hansı sözlə necə əlaqə quracağını öyrənir.
</div>

---

<!-- Slayd 9 (Şəkil 3): Scaled Dot-Product Attention & Softmax -->

# 🎯 Hesablama: Scaled Dot-Product Attention & Softmax
### Query və Key Skalyar Vurması (Dot Product) və Diqqət Ehtimalları

<div class="grid-2">
<div>

* 🔹 **Skalyar Vurma (Dot Product):**
  * İki vektorun uyğunluğunu (oxşarlığını) ölçmək üçün ən sürətli riyazi üsul skalyar vurmadır (`q · k`).
* 🔹 **Addım-addım İcra (Nümunə: "a" tokeni üçün):**
  1. "a"-nın `q` vektoru ilə "a"-nın öz `k` vektoru vurulur ➔ Score 1
  2. "a"-nın `q` vektoru ilə "good"-un `k` vektoru vurulur ➔ Score 2
  3. "a"-nın `q` vektoru ilə "novel"-in `k` vektoru vurulur ➔ Score 3
* 🔹 **Softmax Normalizasiyası:**
  * Bu xallar Softmax funksiyasından keçirilərək cəmi 100% olan ehtimala çevrilir (məs: **20%**, **50%**, **30%**).
* 🔹 **Niyə "Scaled"?** Ölçü (`dₖ`) böyüdükcə qradiyentin partlamaması üçün `√dₖ`-ya bölünür.

</div>
<div>

<div class="diagram-img"><img src="images/slide08_scaled_dot_product.svg" alt="Scaled Dot Product Diagram"></div>

<div class="box-math">
📐 <strong>Əsas Düstur:</strong><br>
<code>Attention(Q, K, V) = Softmax( (Q · Kᵀ) / √dₖ ) · V</code>
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> 'a' sözünün Query vektorunu bütün sözlərin Key vektorlarına skalyar vururuq. Softmax-dan keçirdikdə diqqət çəkiləri (20%, 50%, 30%) yaranır.
</div>

---

<!-- Slayd 10 (Şəkil 4): Masked Self-Attention -->

# 🎭 Masked Self-Attention: Gələcəyə Baxmağın Qadağası
### Autoregressive Generasiya, Kausal Maska (Causal Mask) və GPT vs BERT

<div class="grid-2">
<div>

* 🔒 **Niyə Maska Lazımdır?**
  * İnsan oxuduqda və ya danışdıqda gələcək sözləri öncədən bilmir.
  * Transformatorlar bütün cümləni paralel emal etdiyi üçün, model növbəti sözü proqnozlaşdırarkən gələcəyə "baxmamalıdır" (*peeking*).
* 🛡️ **Maska Necə İşləyir?**
  * Hər addımda yalnız cari və keçmiş tokenlərə icazə verilir (1 / Yaşıl), gələcək tokenlər isə sıfırlanır (0 / Qara və ya -∞).
  * *"a"* ➔ Yalnız *"a"*-nı görə bilər `[🟩 ⬛ ⬛]`
  * *"good"* ➔ *"a"* və *"good"*-u görər, *"novel"*-i görməz `[🟩 🟩 ⬛]`
  * *"novel"* ➔ Bütün əvvəlkiləri görə bilər `[🟩 🟩 🟩]`
* 🤖 **GPT vs BERT Fərqi:**
  * **GPT:** Mətni soldan sağa generasiya etdiyi üçün mütləq *Masked Attention* istifadə edir.
  * **BERT:** İkiistiqamətlidir; cümlədə təsadüfi sözləri gizlədib hər iki tərəfdən öyrənir (*Masked LM*).

</div>
<div>

<div class="diagram-img"><img src="images/slide09_masked_self_attention.svg" alt="Masked Self-Attention Diagram"></div>

<div class="box-warning">
⚠️ <strong>Qayda:</strong> "good" sözü hesablanarkən "novel" sözündən təsirlənə bilməz, lakin "novel" sözü "good" sözündən tam təsirlənir!
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> GPT gələcək sözləri öncədən görərsə, imtahanda cavablara baxan şagird kimi öyrənməz. Məhz buna görə matrisin yuxarı üçbucağı maskalanır.
</div>

---

<!-- Slayd 11: Self-Attention Addım-Addım İcra Sxemi -->

# ⚙️ Self-Attention: 1-ci Hissənin Xülasəsi

| Addım | Əməliyyat | Nəticə | İzah |
| :---: | :--- | :--- | :--- |
| **1** | **Embedding + Positional Encoding** | Vektor `x` | Hər token çoxölçülü məkanda ədədi vektora çevrilir |
| **2** | **Q, K, V Proyeksiyaları** | `q, k, v` | `x · Wq`, `x · Wk`, `x · Wv` vurulur |
| **3** | **Skalyar Vurma (Dot Product)** | `Score = q · k` | Bütün cütlüklər arasında ilkin oxşarlıq xalı tapılır |
| **4** | **Miqyaslama (Scaling)** | `Score / √dₖ` | Sabit variasiya və sabit qradiyent təmin edilir |
| **5** | **Maskalanma (Maska varsa)** | Masked Scores | Gələcək tokenlərə -∞ verilir (əlaqə kəsilir) |
| **6** | **Softmax Normalizasiyası** | Attention Weights | Xallar cəmi 1.0 (100%) olan ehtimallara çevrilir |

<div class="box-idea">
👉 <strong>Növbəti Addım (Hissə 2):</strong> Bu diqqət çəkilərini Value (`v`) vektorlarına necə vururuq, yekun `z` vektorunu necə toplayırıq və Multi-Head Attention nədir?
</div>

---

<!-- Slayd 12 (Yeni Şəkil 1): Dəyərlərin Vurulması və Cəmlənməsi: Z Vektoru -->

# ➕ Dəyərlərin Vurulması və Cəmlənməsi: Z Vektoru
### Softmax Çəkiləri × Value Vektorları Hasilinin Cəmi və Kontekstual Embedding

<div class="grid-2">
<div>

* 🔹 **Value Vektorlarının Çəkiləndirilməsi:**
  * Hesabladığımız diqqət çəkiləri (20%, 50%, 30%) hər tokenin **Value (`v`)** vektoruna vurulur:
    `z₁ = 20% · v_a,  z₂ = 50% · v_good,  z₃ = 30% · v_novel`
* 🔹 **Yekun Cəm (*Summing Up*):**
  * Alınan bütün hasil vektorları komponent-komponent toplanır:
    `z = z₁ + z₂ + z₃`
* 🎯 **Z Vektoru Nədir?**
  * Bu, cari tokenin ("a" sözünün) ətrafındakı bütün digər sözlərin mənasını çəkili şəkildə özündə birləşdirən **YENİ YENİLƏNMİŞ EMBEDDING-İDİR**!

</div>
<div>

<div class="diagram-img"><img src="images/slide10_values_weighted_sum.svg" alt="Values Weighted Sum Diagram"></div>

<div class="box-idea">
💡 <strong>Sehr Nədədir?</strong> Bu heç bir möcüzə deyil: Backpropagation zamanı düzgün nəticə verən çəkilər gücləndirilir və beləliklə z vektoru sözün kontekstdəki dəqiq yerini tapır.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Nəhayət bütün hissələr birləşir: tapdığımız Softmax faizlərini Value vektorlarına vururuq. 'a' sözü üçün 20% özündən, 50% 'good' sözündən, 30% 'novel' sözündən pay götürürük və toplayırıq. Alınan yekun z vektoru artıq həmin sözün tam kontekstuallaşmış yeni embeddingidir!
</div>

---

<!-- Slayd 13 (Yeni Şəkil 2): Bütün Tokenlər Üçün Paralel Hesablama və FFNN -->

# ⚡ Bütün Tokenlər Üçün Paralel Hesablama və FFNN Keçidi
### Hər Token Üçün Z Vektorları və Feed-Forward Neyron Şəbəkələri

<div class="grid-2">
<div>

* 🔹 **Bütün Cümlə Eyni Anda Hesablanır:**
  * Bu əməliyyat yalnız "a" üçün deyil, cümlədəki hər bir söz ("a", "good", "novel") üçün **tam paralel** icra olunur.
* 🔹 **Yenilənmiş Embeddinglər (*Updated Embeddings*):**
  * Hər token üçün fərdi `z` vektoru əldə edirik (`z_a`, `z_good`, `z_novel`).
* 🔹 **Növbəti Addım: Feed-Forward Təbəqəsi (FFNN):**
  * Hər bir `z` vektoru Self-Attention qatının üstündə yerləşən **Feed-Forward Neyron Şəbəkəsinə (FFNN)** daxil olur.
  * FFNN hər token üçün eyni arxitekturalı, lakin müstəqil işləyən dərindən öyrənmə qatıdır.

</div>
<div>

<div class="diagram-img"><img src="images/slide11_parallel_updated_embeddings_ffnn.svg" alt="Parallel Embeddings and FFNN Diagram"></div>

<div class="box-analogy">
🚀 <strong>Tam Paralellik:</strong> Heç bir dövrə və recurrence yoxdur! Bütün z vektorları eyni anda hesablanır və dərhal FFNN blokuna ötürülür.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Bütün sözlər üçün z vektorlarını paralel əldə etdikdən sonra onları Self-Attention-ın dərhal üstündə oturan Feed-Forward qatına ötürürük. Beləliklə bütöv bir Transformator blokunun təməl məntiqi tamamlanır.
</div>

---

<!-- Slayd 14 (Yeni Şəkil 3): Multi-Headed Self-Attention -->

# 🎭 Multi-Headed Self-Attention: Vektorların Matrisə Çevrilməsi
### Q, K, V Vektorlarının Başlıqlara (Heads) Bölünməsi və Çoxölçülü Təhlil

<div class="grid-2">
<div>

* 🔹 **Nə Baş Verir? (Reshaping):**
  * Əvvəlki addımlarda böyük, minlərlə elementi olan tək bir `q, k, v` vektorumuz var idi.
  * Multi-Head Attention-da bu uzun vektorlar birbaşa **matrisə çevrilir (reshape olunur)**.
* 🔹 **Sətirlərin Sayı = Başlıqların Sayı (Number of Heads):**
  * Matrisin hər bir sətri müstəqil bir "Diqqət Başlığı" (*Attention Head*) təşkil edir.
  * Məsələn: 768 ölçülü vektor 12 başlığa bölünərək hər biri 64 ölçülü 12 sətir olur (`12 × 64`).
* 🔹 **Üstünlüyü Nədir?**
  * Hər bir sətir tam paralel hesablanır (çox sürətli optimizasiya).
  * Hər başlıq cümlədəki fərqli əlaqələri öyrənir (biri qrammatikanı, biri mətni, biri sinonimləri).

</div>
<div>

<div class="diagram-img"><img src="images/slide12_multi_headed_attention.svg" alt="Multi Headed Attention Diagram"></div>

<div class="box-idea">
🎯 <strong>Məntiq:</strong> Tək bir nəhəng diqqət başlığı yerinə çoxlu sayda paralel kiçik başlıqlar yaratmaq həm hesablamanı sürətləndirir, həm də modelə mətni çoxistiqamətli dərk etməyə imkan verir.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Multi-Head Attention əslində böyük q, k, v vektorlarını sətirlərə bölüb matris halına gətirməkdir. Sətirlərin sayı başlıqların (heads) sayıdır. Bu, hesablamanı paralelləşdirir və hər başlığın cümləyə fərqli bucaqdan baxmasına imkan yaradır.
</div>

---

<!-- Slayd 15: Dərs 2 Yekun Xülasə -->

# 🏛️ Self-Attention və Multi-Head Blokunun Bütöv Sxemi

### Token Embeddingdən FFNN Çıxışına Qədər İntellektual Nüvə

<div class="grid-2">
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #334155;">

### 📋 Bütün Blokların Sintezi:
* **1. Giriş:** Token Embedding + Positional Encoding (`x`)
* **2. Matrislər:** `Wq, Wk, Wv` vurulur ➔ `q, k, v` əldə edilir
* **3. Reshaping:** Vektorlar sətirlərə bölünərək **Multi-Head** matrisinə çevrilir
* **4. Oxşarlıq:** Scaled Dot-Product (`q · k / √dₖ`)
* **5. Maska:** Gələcək sözləri gizlədən Causal Masking
* **6. Normalizasiya:** Softmax diqqət faizləri (20%, 50%, 30%)
* **7. Cəmləmə:** `z = ∑ (çəki × v)` yekun kontekstual vektor
* **8. Çıxış:** Hər bir `z` vektoru birbaşa **FFNN**-ə daxil olur!

</div>
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #334155;">

### 🚀 Niyə Müasir AI-ın Əsasıdır?
Ənənəvi modellərdən fərqli olaraq, Transformator daxilindəki hər bir addım matris vurmasıdır. GPU-lar matris əməliyyatlarını saniyədə trilyonlarla dəfə paralel icra edə bilir.

<div class="box-analogy" style="margin-top:14px;">
🏁 <strong>Nəticə:</strong> Self-Attention və Multi-Head mexanizmi cümlədəki hər bir sözün ətraf kontekstlə dinamik zənginləşməsini və bunun GPU-larda kütləvi paralel icrasını təmin edən mühərrikdir.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Dərs 2-ni xülasə etsək: Embedding-dən başladıq, Q, K, V yaratdıq, onları matrisə bölüb Multi-Head etdik, oxşarlığı tapıb maskaladıq, Value vektorları ilə vurub z çıxardıq və nəhayət FFNN-ə ötürdük. Bütün bu mexanizm Transformatorun ürəyidir!
</div>

---

<!-- Slayd 16: Dərs 3 Titulu -->
<!-- header: "Generative AI: Transformatorlar və LLM | Dərs 3: Applications of Transformers (GPT)" -->

# 🌐 Dərs 3: Transformatorların Tətbiq Sahələri
### Mətn Generasiyasından Kodlaşdırmaya, Q&A və Müştəri Xidmətlərinə Qədər

<div class="box-idea">
🎯 <strong>Dərsin Məqsədi:</strong> Transformator arxitekturasının təməl nəzəriyyəsindən real dünya tətbiqlərinə keçid: Çatbotlar, Sual-Cavab sistemləri, Təsnifat, Named Entity Recognition (NER), Xülasələmə, Tərcümə, Kod generasiyası və Etik məsuliyyətlər.
</div>

* 🔹 **Sual:** Transformatorun daxili iş prinsipini öyrəndik, bəs bu arxitektura praktikada hansı sahələri dəyişir?
* 🔹 **Əsas Mesaj:** Transformator təkbaşına hər şey deyil; o, üzərində nəhəng tətbiqlər qurduğumuz güclü bir təməldir (*foundation*).

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Artıq Transformatorun daxili riyaziyyatını bilirik. İndi isə ən maraqlı hissəyə gəlirik: bu texnologiya hansı real sahələrdə istifadə olunur? ChatGPT necə yaranır, mətn təsnifatı və kod necə generasiya edilir?
</div>

---

<!-- Slayd 17: Çatbotlar və Dialoq: Base GPT vs ChatGPT -->

# 💬 Çatbotlar və Dialoq: Base GPT vs ChatGPT
### Transformator Təkbaşına Kifayət Deyil: Dialoq və Təhlükəsizlik Qatları

<div class="grid-2">
<div>

* 🔹 **Base Transformer Nədir?**
  * Əsas Transformator (məsələn xam GPT) yalnız **mətni tamamlamağı** və növbəti sözü ehtimalla tapmağı bacarır.
  * O, özlüyündə dialoq aparmağı, nəzakətli olmağı və ya doğru cavab verməyi bilmir.
* 🛡️ **ChatGPT Necə Formalaşır?**
  * **1. Instruction Tuning:** Əmrlərə və suallara cavab vermək üçün xüsusi dialoq verilənləri ilə öyrədilir.
  * **2. Toksiklikdən Təmizlənmə:** Zərərli və təhlükəli cavabları süzən təhlükəsizlik filtrləri (*Guardrails*).
  * **3. RLHF (Reinforcement Learning from Human Feedback / İnsan Əks-əlaqəsi ilə Gücləndirilmiş Öyrənmə):** İnsan rəyləri və üstünlükləri əsasında gücləndirilmiş öyrənmə ilə insan istəklərinə uyğunlaşdırılır (*Alignment*).

</div>
<div>

<div class="diagram-img"><img src="images/slide17_base_vs_chatgpt.svg" alt="Base GPT vs ChatGPT Diagram"></div>

<div class="box-idea">
🔑 <strong>Açar Nəticə:</strong> Transformator bünövrədir; ChatGPT isə onun üzərində qurulmuş dialoq və təhlükəsizlik qatlarının yekunudur.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Çoxları elə bilir ki, GPT elə ChatGPT-dir. Əslində GPT sadəcə növbəti sözü proqnozlaşdıran mühərrikdir. Onu istifadəçiyə faydalı və təhlükəsiz köməkçiyə çevirmək üçün Instruction Tuning və RLHF kimi əlavə təlim qatları tətbiq olunur.
</div>

---

<!-- Slayd 18: Təhlil və Çıxarış: Q&A, Təsnifat və NER -->

# 🔍 Təhlil və Çıxarış: Q&A, Təsnifat və NER (Named Entity Recognition)
### Mətn Generasiyasından Fərqli Tapşırıqlar

<div class="grid-2">
<div>

* ❓ **1. Sual-Cavab (Question Answering):**
  * Modelə sual mətni və "cavab ver" göstərişi verilir. Model geniş bilik bazasından istifadə edərək birbaşa dəqiq cavabı hasil edir.
* 📊 **2. Mətn Təsnifatı (Text Classification):**
  * Transformator təkcə mətn yazmır! Onun çıxışına sadə bir təsnifat qatı qoymaqla mətni siniflərə bölmək olar.
  * **Sentiment Analizi:** Tvitt və ya film rəyini oxuyub mənanı tam dərk edir ➔ `Müsbət`, `Mənfi`, `Neytral`.
* 🏷️ **3. Varlıqların Tanınması (NER – Named Entity Recognition / Adlandırılmış Varlıqların Tanınması):**
  * Mətndəki xüsusi adları (şəxslər, brendlər, şirkətlər, məkanlar) aşkar edir və etiketləyir.
  * **Transformatorun üstünlüyü:** İnsanlar eyni brendi müxtəlif jarqonlarla yazsa belə, model kontekstual embedding vasitəsilə həqiqi mahiyyəti dərk edir.

</div>
<div>

<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">
  <div style="color:#38bdf8; font-weight:700; margin-bottom:8px;">📥 Giriş Mətni:</div>
  <p style="color:#f1f5f9; font-style:italic; margin-bottom:12px;">"Dünən Bakıda Apple mağazasından yeni telefon aldım, əladır!"</p>
  <div style="display:flex; flex-direction:column; gap:8px;">
    <div style="background:#1e293b; padding:8px 12px; border-radius:6px; border-left:3px solid #38bdf8;"><strong>Q&A:</strong> "Hardan aldı?" ➔ "Apple mağazası"</div>
    <div style="background:#1e293b; padding:8px 12px; border-radius:6px; border-left:3px solid #10b981;"><strong>Sentiment:</strong> Müsbət (98%)</div>
    <div style="background:#1e293b; padding:8px 12px; border-radius:6px; border-left:3px solid #f59e0b;"><strong>NER:</strong> Bakı (Məkan), Apple (Brend), telefon (Məhsul)</div>
  </div>
</div>

<div class="box-analogy">
💡 <strong>Geniş Tətbiq:</strong> Mətnin semantik vektorunu (embedding) anladıqdan sonra onunla istənilən analitik tapşırığı həll etmək mümkündür.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Transformatorlar təkcə mətn generasiya etmir. Məsələn, Sentiment analizində model film rəyini oxuyub onun pozitiv yoxsa neqativ olduğunu dəqiq təyin edir. NER-də isə mətn içərisindəki şirkət, insan və məkan adlarını tapıb kateqoriyalara ayırır.
</div>

---

<!-- Slayd 19: Məzmun Yaradılması: Xülasə, Tərcümə və Kod -->

# ✍️ Məzmun Yaradılması: Xülasə, Tərcümə və Kod
### Yeni Məzmunun İstehsalı və Proqramlaşdırma Dilləri

<div class="grid-2">
<div>

* 📝 **1. Mətn Xülasələnməsi (Summarization):**
  * Girişə 20 səhifəlik uzun elmi məqalə və ya xəbər verilir; model əsas ideyaları itirmədən qısa, lakonik xülasə hazırlayır.
* 🌍 **2. Maşın Tərcüməsi (Machine Translation):**
  * Ənənəvi sözbəsöz lüğət tərcüməsi əvəzinə, cümlənin bütün mənasını və frazeoloji birləşmələrini hədəf dilə dəqiq uyğunlaşdırır.
* 💻 **3. Kod Generasiyası (Code Generation):**
  * Dil təkcə insanların danışdığı dil deyil: **Python, Java, C++, SQL, HTML** də bir dildir!
  * Modelə *"Python-da Transformator üçün kod yaz"* dedikdə sintaksisi və alqoritmi qurub çalışan proqram təqdim edir.

</div>
<div>

<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">
  <div style="color:#38bdf8; font-weight:700; font-size:1.05rem; margin-bottom:8px;">✨ Kod İntellekti və Avtomatlaşdırma</div>
  <ul style="margin-left:16px; color:#cbd5e1; font-size:0.95rem;">
    <li>🔹 <strong>Sintaktik Anlama:</strong> Proqramlaşdırma dillərinin qrammatikasını dəqiqliklə izləyir.</li>
    <li>🔹 <strong>Kod Generasiyası:</strong> Təbii dildə verilən tapşırığı birbaşa koda çevirir.</li>
    <li>🔹 <strong>Refaktorinq:</strong> Mövcud kod bazasındakı xətaları tapıb aradan qaldırır.</li>
  </ul>
</div>

<div class="box-idea">
🎯 <strong>Proqramlaşdırmada İnqilab:</strong> GitHub Copilot kimi köməkçilər məhz kod verilənləri üzərində öyrədilmiş Transformator modelləridir.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> İnsan dilləri kimi proqramlaşdırma dilləri də müəyyən sintaktik qaydalara və tokenlərə malikdir. Məhz buna görə Transformatorlar Python və Java kodlarını asanlıqla generasiya edir, xətaları tapır və uzun sənədləri saniyələr içində xülasələyir.
</div>

---

<!-- Slayd 20: Fərdiləşdirmə və Müştəri Xidmətləri -->

# 🎯 Fərdiləşdirmə (Fine-Tuning) və Müştəri Xidmətləri
### Şəxsi Üslub və Korporativ Virtual Operatorlar

<div class="grid-2">
<div>

* ✉️ **Şəxsi Üslubda Cavablar (Personalized Email Bot):**
  * Əgər böyük dil modelini keçmişdə yazdığınız minlərlə email və cavab üzərində tənzimləsəniz (*fine-tune* etsəniz), o, tam **sizin kimi düşünən və sizin sözlərinizlə yazan** bir köməkçiyə çevrilər.
* 🎧 **Ağıllı Müştəri Xidmətləri (Customer Support Agent):**
  * Şirkətin keçmiş zəng və çat qeydləri ilə təlim olunan AI agent real operator kimi danışa, müştərinin problemini dinləyib dərhal həll yolları təklif edə bilir.
* ⚡ **Biznes Faydası:**
  * 7/24 fasiləsiz xidmət, minlərlə müştəriyə eyni saniyədə fərdi cavab və zəng mərkəzi xərclərinin kəskin azalması.

</div>
<div>

<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">
  <div style="background:#1e293b; padding:10px 14px; border-radius:8px; margin-bottom:10px; border-left:3px solid #38bdf8;">
    <div style="color:#38bdf8; font-weight:700;">✉️ Şəxsi Yazışma Üslubu</div>
    <div style="color:#cbd5e1; font-size:0.9rem; margin-top:2px;">Keçmiş e-maillərlə tənzimlənmiş fərdi katib</div>
  </div>
  <div style="background:#1e293b; padding:10px 14px; border-radius:8px; border-left:3px solid #10b981;">
    <div style="color:#34d399; font-weight:700;">🎧 7/24 Müştəri Xidməti</div>
    <div style="color:#cbd5e1; font-size:0.9rem; margin-top:2px;">Korporativ bilik bazası ilə dərhal cavab</div>
  </div>
</div>

<div class="box-analogy">
🧩 <strong>Fine-Tuning Analogiyası:</strong> Universitet bitirmiş savadlı gəncə (Base Model) şirkətinizin daxili qaydalarını və müştəri xidməti təlimatını öyrətmək kimidir.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Böyük modeli şirkətinizin öz daxili məlumatları ilə tamamlayıb (Fine-Tuning) virtual operator yarada bilərsiniz. Lakin burada çox incə bir tələ var: botun müştəriyə nə vəd verməsinə mütləq nəzarət etmək lazımdır.
</div>

---

<!-- Slayd 21: Tələlər, Risklər və Müştəri Təcrübəsi -->

# ⚠️ Tələlər, Etika və Real Dünya Xəbərdarlığı
### "Qızıl Hərisliyi", Aldadıcı Vədlər və Müştəri Məyusluğu

<div class="grid-2">
<div>

* ❌ **Botun İcazəsiz Vədləri (*Unfulfilled Commitments*):**
  * Bot müştəriyə asanlıqla deyə bilər: *"Narahat olmayın, sabah sizə pulsuz yeni məhsul göndərəcəyik!"*
  * Amma arxa fonda heç kim məhsul göndərmir! Nəticə: qəzəbli müştəri və şirkətin nüfuz itkisi.
* 🏆 **"Qızıl Hərisliyi" (AI Gold Rush) Tələsi:**
  * Hər kəs tələsik Transformator tətbiq etməyə çalışır, lakin əsas sualı unudur: **"Bu, həqiqətən müştərimiz üçün daha yaxşı təcrübə yaradırmı?"**
  * Əksər hallarda şirkətlər müştərinin heç ehtiyacı olmayan yerlərə bot qoyur və nəticədə boş yerə resurs xərclənir.
* 🛡️ **Əsas Prinsip:** AI güclü bir alətdir; lakin o aləti necə işlətdiyiniz uğurun tək açarıdır!

</div>
<div>

<div class="diagram-img"><img src="images/slide21_ai_pitfalls_ethics.svg" alt="AI Pitfalls and Ethics Diagram"></div>

<div class="box-warning">
⚠️ <strong>Qızıl Qayda:</strong> Maliyyə, göndəriş və hüquqi öhdəlik yaradan addımlarda mütləq insan nəzarəti (*Human-in-the-loop*) olmalıdır!
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Çox şirkət AI dalğasına qoşulub düşünmədən botlar tətbiq edir. Amma əgər bot müştəriyə yalan vəd versə və arxasında icra mexanizmi olmasa, bu böyük fəlakətlə nəticələnər. Odur ki, AI tətbiq edərkən son müştəri təcrübəsini hər şeydən üstün tutmaq lazımdır.
</div>

---

<!-- Slayd 22: Dərs 3 Xülasəsi -->

# 🗺️ Dərs 3 Xülasəsi: Transformatorların Tətbiq Xəritəsi

| Tətbiq Sahəsi | Tipik Giriş (Input) | Modelin İşi | Real Həyat Nümunəsi |
| :--- | :--- | :--- | :--- |
| **Çatbotlar (Chat)** | İstifadəçi replikası + Kontekst | Təhlükəsiz və faydalı dialoq aparmaq | **ChatGPT, Claude, Gemini** |
| **Sual-Cavab (Q&A)** | Sənəd + Sual | Mətndən dəqiq cavabı hasil etmək | Axtarış sistemləri, Perplexity |
| **Mətn Təsnifatı** | Müştəri rəyi, Tvitt | Sentiment təhlili (Müsbət/Mənfi) | Rəy analitikası, Spam filtri |
| **Varlıq Tanıma (NER)**| Xəbər, maliyyə hesabatı | İnsan, brend, məkanları etiketləmək | Hüquq və maliyyə auditi |
| **Xülasələmə** | Çoxsəhifəlik hesabat | Əsas fikirləri qısa tezislərə yığmaq | Xəbər bülletenləri, icmallar |
| **Tərcümə** | Mənbə dildə cümlə | Hədəf dilin qrammatikasına uyğunlaşdırmaq | DeepL, Google Translate |
| **Kodlaşdırma** | Təsvir / Şərh (Prompt) | Funksiya və skriptlər yazmaq | GitHub Copilot, Cursor |
| **Fərdiləşdirmə** | Şirkətin daxili bazası | Korporativ standartda köməkçi olmaq | 7/24 AI Müştəri Dəstəyi |
<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Bu xəritə Transformatorların yaratdığı nəhəng ekosistemi xülasə edir. Çatbotlardan tutmuş proqramlaşdırmaya və müştəri xidmətlərinə qədər bütün bu sahələr məhz Transformator arxitekturasının gücü ilə işləyir.
</div>

---

<!-- Slayd 23: Dərs 4 Titulu və Giriş: GPT Arxitekturasına Baxış -->
<!-- header: "Generative AI: Transformatorlar və LLM | Dərs 4: The GPT Transformer Architecture" -->

# 🚀 Dərs 4: GPT Necə İşləyir? (Hissə 1)
### Generative Pre-trained Transformer Arxitekturası

<div class="grid-2">
<div>

* 💡 **GPT Nədir?**
  * **G**enerative (Məzmun generasiya edən)
  * **P**re-trained (Nəhəng verilənlər bazasında öncədən təlim olunmuş)
  * **T**ransformer (Diqqət mexanizminə əsaslanan neyron şəbəkə).
* 🏢 **OpenAI və "Qapalı" Model Paradoksu:**
  * Adı "OpenAI" olsa da, şirkət ən son GPT-4 arxitekturasının dəqiq detallarını gizli saxlayır.
  * Bu, "bəşəriyyəti xilas etmək" üçün deyil, sırf **kommersiya sirrini və rəqabət üstünlüyünü** qorumaq üçündür.
* 🔍 **Möcüzə Yoxdur, Mühəndislik Var!**
  * Arxitekturada qeyri-adi bir "sehr" yoxdur: hər şey riyazi prinsiplərə və nəhəng hesablama gücünə əsaslanır.
  * Bu dərsdə əsas kimi arxitekturası tam məlum olan **GPT-2** modelini addım-addım incələyəcəyik.

</div>
<div>

<div class="box-idea">
🎯 <strong>Dərsin Əsas Sualları:</strong><br>
• Niyə GPT-də Enkoder yoxdur, yalnız Dekoder var?<br>
• "Giriş" və "Çıxış" anlayışı necə yox olur?<br>
• Model milyardlarla səhifə mətni heç bir etiketləmə olmadan necə öyrənir?<br>
• GPT-2-dən GPT-4-ə gedən 1 trilyonluq miqyas nə deməkdir?
</div>

<div class="box-analogy">
🧩 <strong>GPT-2-dən GPT-4-ə:</strong> Əsas prinsiplər tam eynidir. Fərq dekoder qatlarının sayında, diqqət başlıqlarının həcmində və təlim parametrlərinin miqyasındadır.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> İndiyə qədər transformatorları ümumi şəkildə müzakirə etdik. İndi isə ChatGPT-nin əsasını təşkil edən GPT ailəsinə keçirik. OpenAI adı 'Open' olsa da, modellərin daxili detallarını kommersiya sirri kimi gizlədir. Amma narahat olmayın, burada heç bir sirli möcüzə yoxdur. GPT-2-nin arxitekturasını anlamaqla ən müasir modellərin necə işlədiyini tam dərk edəcəyik.
</div>

---

<!-- Slayd 24: Yalnız Dekoder (Decoder-Only) Paradigması -->

# 🧩 Yalnız Dekoder (Decoder-Only) Paradigması
### Enkoderə Niyə Ehtiyac Qalmadı?

<div class="grid-2">
<div>

* ❌ **Ayrı Enkoder və Dekoder Zərurəti Aradan Qalxdı:**
  * Klassik RNN və ilkin Seq2Seq sistemlərində daxil olan mətni gizli vəziyyətə (*hidden state*) yığmaq üçün mütləq Enkoder lazım idi.
  * Lakin Transformatorlarda hər şey kütləvi şəkildə **paralelləşdirildiyi** üçün mətni iki ayrı qülləyə bölməyə ehtiyac qalmadı.
* 🏛️ **Transformator Modellərinin 3 Ailəsi:**
  * 🔵 **Encoder-Only (BERT - Google):** Mətni hər iki istiqamətdə oxuyur (*Bidirectional*). Mətn anlamaq, təsnifat və axtarış üçün idealdır.
  * 🟣 **Decoder-Only (GPT - OpenAI, LLaMA - Meta):** Yalnız keçmiş sözləri görür (*Masked Attention*). Mətn və kod generasiyası üçün mütləq standartdır.
  * 🟢 **Encoder-Decoder (T5, BART – Bidirectional and Auto-Regressive Transformers):** Klassik ikili qat; tərcümə və seq2seq tapşırıqları üçün istifadə olunur.

</div>
<div>

<div class="diagram-img">
  <img src="images/slide24_transformer_families.svg" alt="Transformer Families BERT GPT T5">
</div>

<div class="box-idea">
⚡ <strong>GPT Strategiyası:</strong> İki kiçik qüllə yerinə tək bir nəhəng Dekoder qülləsi quraq və onun parametrlərini maksimum dərəcədə böyüdək!
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> GPT-nin ən böyük fərqi onun yalnız Dekoder bloklarından ibarət olmasıdır. Əvvəllər ardıcıl işləyən RNN-lərdə Enkoder məcburi idi. Lakin Self-Attention hər şeyi paralel etdiyi üçün mühəndislər anladılar ki, tək bir nəhəng Dekoder qatı qurmaq kifayətdir. BERT yalnız Enkoderdən, GPT isə yalnız Dekoderdən ibarətdir.
</div>

---

<!-- Slayd 25: Dekoder Blokunun Daxili Anatomiyası və Miqyası -->

# 🏗️ Dekoder Blokunun Daxili Anatomiyası və Miqyası
### Yüzlərlə Qat, Nəhəng FFNN və Trilyon Parametrlər

<div class="grid-2">
<div>

* 🧱 **Hər Dekoder Blokunun İki Əsas Pilləsi:**
  * **1. Masked Self-Attention Qatı:** Hər bir token özündən əvvəlki bütün tokenlərlə əlaqəsini təhlil edir (gələcək sözləri görmür).
  * **2. Nəhəng Feed-Forward Şəbəkəsi (FFNN):** Diqqət nəticəsində toplanan zəngin məlumatı qeyri-xətti transformasiyadan keçirərək dərinləşdirir.
* 📚 **Üst-Üstə Yığılma (Stacking):**
  * Çıxan nəticə birbaşa növbəti Dekoder Blokuna ötürülür:
    * `Dekoder 1 ➔ Dekoder 2 ➔ ... ➔ Dekoder N`
  * Müasir modellərdə bu cür ardıcıl **onlarla və yüzlərlə blok** bir-birinin üzərinə yığılır!
* 💰 **Parametrlərin Partlayışı və Xərclər:**
  * GPT-2: 1.5 milyard parametr.
  * GPT-3: 175 milyard parametr.
  * GPT-4: Şayiələrə görə **1 trilyondan çox** parametr!
  * Bu nəhəng modeli öyrətmək üçün milyonlarla dollar dəyərində superkompüter klasterləri tələb olunur.

</div>
<div>

<div style="background:#0f172a; padding:18px; border-radius:12px; border:1px solid #334155;">
  <div style="background:#1e1b4b; border:2px dashed #818cf8; border-radius:10px; padding:14px; margin-bottom:10px;">
    <div style="color:#c7d2fe; font-weight:700; margin-bottom:8px;">📦 Decoder Bloku (i)</div>
    <div style="background:#6b21a8; color:#fff; padding:8px 12px; border-radius:6px; font-weight:700; margin-bottom:8px;">Feed-Forward Neural Network</div>
    <div style="text-align:center; color:#c084fc; font-weight:bold; margin:2px 0;">▲</div>
    <div style="background:#581c87; color:#fff; padding:8px 12px; border-radius:6px; font-weight:700;">Masked Self-Attention</div>
  </div>
  <div style="text-align:center; color:#38bdf8; font-weight:bold; margin:4px 0;">▲ Yüzlərlə blok ardıcıl steklənir</div>
  <div style="background:#1e1b4b; opacity:0.6; border:1px solid #475569; border-radius:6px; padding:6px; text-align:center; color:#cbd5e1;">📦 Decoder Bloku (i-1)</div>
</div>

<div class="box-warning">
⚠️ <strong>Əsl Mürəkkəblik:</strong> Bütün o milyardlarla və trilyonlarla çəki parametrləri məhz bu üst-üstə yığılmış FFNN və Attention qatlarında saxlanılır.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Hər bir dekoder bloku iki hissədən ibarətdir: Masked Self-Attention və nəhəng Feed-Forward neyron şəbəkəsi. Bütün mürəkkəblik bu blokların yüzlərlə dəfə üst-üstə qoyulmasından yaranır. Məsələn, GPT-4-də 1 trilyondan çox parametr var və bu modeli təlim etmək on milyonlarla dollara başa gəlir.
</div>

---

<!-- Slayd 26: Giriş və Çıxış Sərhədinin Aradan Qalxması -->

# 🔄 "Giriş" və "Çıxış" Sərhədinin Aradan Qalxması
### Bütün Tokenlər Eyni Zəncirdə: Növbəti Sözün Hasil Edilməsi

<div class="grid-2">
<div>

* 💡 **Klassik Giriş/Çıxış Yoxdur!**
  * Model üçün xüsusi "giriş mətni" və ya "çıxış mətni" anlayışı mövcud deyil.
  * Model qarşısında sadəcə **paralel emal olunan vahid bir token axını** görür.
* 🔁 **Avtoreqressiv Dövr (Klinqon Nümunəsi):**
  * **1-ci Addım:** Giriş zənciri verilir: `[Please] [Translate] [Me] [<t>]`
    * Bütün tokenlər eyni anda şəbəkədən keçir.
    * Şəbəkə yalnız növbəti ən ehtimallı tokeni tapır: `'ay'`.
  * **2-ci Addım:** Hasil olunan token dərhal zəncirin sonuna əlavə edilir:
    * `[Please] [Translate] [Me] [<t>] ['ay']`
    * Yenidən bütün zəncir paralel ötürülür və sonrakı söz tapılır: `ghojmoHmeH`.
* 🧠 **Diqqətin (Attention) Sehri:**
  * Modelin sözlərin sırasını qarışdırmamasının və mənanı saxlamasının yeganə səbəbi **Self-Attention** mexanizmidir.

</div>
<div>

<div class="diagram-img">
  <img src="images/slide26_next_token_prediction.svg" alt="Next Token Prediction Loop">
</div>

<div class="box-idea">
🔑 <strong>Modelin Gözündə:</strong> Giriş də, çıxış da sadəcə əvvəlki tokenlərdir. Model heç vaxt fərq qoymur; o sadəcə verilən zənciri davam etdirir!
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Çox vacib bir məqam: GPT üçün 'bu istifadəçinin sualıdır, bu isə cavabdır' deyə bir ayrım yoxdur. İstifadəçinin promptu, göstəriş tokeni və artıq hasil edilmiş sözlər tək bir zəncir təşkil edir. Model hər addımda bütün zənciri paralel oxuyur və sadəcə növbəti bir sözü proqnozlaşdırır.
</div>

---

<!-- Slayd 27: Etiketlənməmiş İnternet Verilənləri ilə Təlim -->

# 🌐 Etiketlənməmiş İnternet Verilənləri ilə Təlim
### Self-Supervised Learning: İnsan Əməyi Olmadan Nəhəng Miqyas

<div class="grid-2">
<div>

* 🎯 **Giriş/Çıxış Fərqinin Olmaması Niyə İnqilabdır?**
  * Ənənəvi maşın öyrənməsində hər bir cümləni insan əli ilə etiketləmək (*annotation*) lazım idi: *"Bu sualdır, bu cavabdır"*.
  * GPT-də isə modelə sadəcə **istənilən xam mətn yığını** verilir!
* 📖 **Öz-özünü Öyrədən Model (Wikipedia Nümunəsi):**
  * Modelə Vikipediyanın bir abzasının ilk 5 sözü verilir və növbəti sözü təxmin etməsi tələb olunur.
  * Məqalənin ardı artıq məlum olduğu üçün mətnin özü həm **təlim veriləni**, həm də **qiymətləndirmə meyarı** olur!
* 🚀 **"Dili Öyrənmək" (Learning a Language):**
  * Model konkret bir tapşırığa (məsələn, təkcə spam filtri) uyğunlaşmır; o, bütövlükdə **dilin qrammatikasını, dünyagörüşünü və məntiqini** öyrənir.
  * Bütün interneti (milyardlarla veb səhifə, kitab, məqalə) heç bir etiketləmə xərci olmadan təlimə cəlb etmək mümkün olur.

</div>
<div>

<div style="background:#0f172a; padding:18px; border-radius:12px; border:1px solid #334155;">
  <div style="background:rgba(56,189,248,0.1); border:1px solid rgba(56,189,248,0.3); border-radius:8px; padding:10px; margin-bottom:12px;">
    <span style="color:#38bdf8; font-weight:700; font-size:0.85rem;">🌐 Xam Mətn:</span>
    <p style="color:#f1f5f9; font-style:italic; margin-top:2px;">"Bakı Azərbaycanın paytaxtıdır və Xəzər dənizi sahilində yerləşir."</p>
  </div>
  <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
    <div style="background:#1e293b; border-radius:6px; padding:10px; border-left:3px solid #38bdf8;"><strong>Giriş:</strong> "Bakı Azərbaycanın ..."</div>
    <div style="background:#1e293b; border-radius:6px; padding:10px; border-left:3px solid #10b981;"><strong>Hədəf:</strong> ➔ "paytaxtıdır"</div>
  </div>
</div>

<div class="box-analogy">
💡 <strong>Sonsuz Təlim Yanacağı:</strong> İnsanların milyonlarla sual-cavab cütlüyü yazmasına ehtiyac qalmadı. Bütün bəşəriyyətin internetdə yazdığı mətnlər avtomatik təlim bazasına çevrildi.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Bu konsept GPT-nin nəhəng miqyasının əsas səbəbidir. Əgər biz insanlardan hər cümləni etiketləməyi xahiş etsəydik, bu əsrlər çəkərdi. Lakin GPT-yə xam mətn veririk, o öz-özünü yoxlayır: 'mən bu sözü düz tapdım, yoxsa səhv?'. Beləliklə, internetdəki bütün kitablar və məqalələr dərhal təlim materialına çevrildi.
</div>

---

<!-- Slayd 28: GPT-nin Tam İcra Boru Kəməri -->

# 📐 GPT-nin Tam İcra Boru Kəməri (Pipeline)
### Tokenlərdən Ehtimal Paylanmasına Qədər Addım-Addım Axın

<div class="grid-2">
<div>

* 1️⃣ **Tokenləşdirmə (Tokenization):** Mətn tokenlərə bölünür (`Please`, `Translate`, `Me`, `<t>`).
* 2️⃣ **Token Embedding:** Hər token lüğət cədvəlindən çoxölçülü məna vektoruna çevrilir.
* 3️⃣ **Positional Encoding:** Cümlədəki sözlərin sırasını göstərən mövqe məlumatı vektorlara toplanır.
* 4️⃣ **Decoder Blokları Qülləsi (Stack):**
  * Hər blokda ardıcıl: `Masked Self-Attention` ➔ `Feed-Forward NN`.
  * Yüzlərlə blokdan keçdikcə vektor hər bir sözün kontekstini tam mənimsəyir.
* 5️⃣ **Final Token Embedding:** Ən sonuncu blokdan çıxan zənginləşdirilmiş yekun vektor.
* 6️⃣ **Token Probabilities (Softmax):** Bütün lüğətdəki on minlərlə token arasında növbəti söz olma ehtimalı hesablanır.
* 7️⃣ **Növbəti Tokenin Seçilməsi:** Ən yüksək ehtimallı token seçilir (`'ay'`) və zəncir təkrarlanır!

</div>
<div>

<div class="diagram-img">
  <img src="images/slide23_gpt_architecture_pipeline.svg" alt="GPT Decoder Architecture Pipeline">
</div>

<div class="box-idea">
🎯 <strong>Mühəndislik Zərifliyi:</strong> Girişdən çıxışa qədər hər bir əməliyyat riyazi matris vurmasıdır və GPU-larda paralel icra olunur.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Gəlin bu vacib arxitekturanı başdan sona bir də xülasə edək. Sözlər tokenləşir, məna vektoruna çevrilir, mövqe məlumatı əlavə olunur, yüzlərlə Dekoder blokundan keçir və nəhayət Softmax ilə ən uyğun növbəti token seçilir. Bu proses hər bir yeni söz üçün təkrar-təkrar baş verir.
</div>

---

<!-- Slayd 29: Dərs 4 (Hissə 1) Xülasəsi -->

# 📋 Dərs 4 (Hissə 1) Xülasəsi və Əsas Nəticələr

| Komponent / Konsept | Mahiyyəti və İşi | Əhəmiyyəti |
| :--- | :--- | :--- |
| **Decoder-Only** | Yalnız dekoder bloklarından ibarət qüllə | Enkoderə ehtiyac qalmır, arxitektura sadələşir və böyüyür |
| **Masked Attention** | Gələcək tokenləri gizlədərək yalnız keçmişə baxmaq | Modelin gələcəkdən "köçürməsinin" qarşısını alır |
| **Feed-Forward NN** | Hər dekoder blokunda yerləşən nəhəng neyron qatı | Trilyonluq parametrlərin və dünya biliklərinin saxlandığı yer |
| **No Input/Output** | Bütün tokenlərin vahid paralel zəncirdə olması | Əvvəlki sözlər əsasında növbəti sözün hasilatı |
| **Self-Supervised** | Xam mətndən növbəti sözü təxmin etməklə öyrənmə | Bütün internetin etiketlənmədən təlimə cəlb olunması |
| **Positional Encoding** | Sözlərin cümlədəki yerini vektora əlavə edən mexanizm | Paralel emalda sözlərin ardıcıllığını itirməmək üçün şərtdir |

<div class="box-idea">
⏭️ <strong>Növbəti Hissədə (Hissə 2):</strong> Positional Encoding dərindən necə işləyir? Sinus və kosinus funksiyaları ilə mövqelər necə kodlaşdırılır?
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Dərs 4-ün ilk hissəsində GPT-nin ümumi arxitekturasını, dekoder qülləsini və növbəti söz proqnozu prinsipini öyrəndik. Növbəti hissədə isə Positional Encoding mövzusunu dərindən araşdıracağıq: ardıcıl olmayan paralel şəbəkə sözlərin sırasını necə yadda saxlayır?
</div>

---

<!-- Slayd 30: Dərs 4 (Hissə 2) Titulu və İcmal -->
<!-- header: "Generative AI: Transformatorlar və LLM | Dərs 4 (Hissə 2): Tokenization, Positional Encoding, Embedding" -->

# 🎛️ Dərs 4 (Hissə 2): Giriş və Çıxış Emalı
### Tokenizasiya, Mövqe Kodlaşdırması, Logitlər və Temperatur

<div class="grid-2">
<div>

* 🔍 **Arxitekturanın İki Qütbü:**
  * Ötən dərsdə nəhəng Dekoder qülləsini öyrəndik. İndi isə həmin qüllənin **ən aşağısına (Giriş emalı)** və **ən yuxarısına (Çıxış emalı)** dərindən baxırıq.
* 📥 **Giriş Emalı (Input Processing):**
  * **1. Tokenizasiya (Tokenization):** Mətni rəqəmsal vahidlərə parçalamaq.
  * **2. Token Embedding:** Hər tokeni semantik vektor fəzasına yerləşdirmək.
  * **3. Positional Encoding:** Sinus və kosinus dalğaları ilə ardıcıllıq məlumatını əlavə etmək.
* 📤 **Çıxış Emalı (Output Processing):**
  * Son çıxış vektorundan **Logitlərə** keçid, Softmax ehtimal paylanması və **Temperatur** tənzimlənməsi.

</div>
<div>

<div class="box-idea">
🎯 <strong>Əsas Hədəf:</strong> Neyron şəbəkə insan sözlərini birbaşa oxuya bilməz, sadəcə rəqəmlərlə və matrislərlə işləyir. Bu dərsdə mətnin necə riyazi koda çevrildiyini və arxitekturadan necə yeni söz kimi çıxdığını addım-addım görəcəyik.
</div>

<div class="box-analogy">
🧩 <strong>İki Tərəfli Körpü:</strong> Giriş emalı insan dilini maşın riyaziyyatına çevirir; çıxış emalı isə maşın ehtimallarını təkrar insan dilinə qaytarır.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Dərs 4-ün bu hissəsində transformatorun giriş və çıxış qapılarını dərindən araşdırırıq. Neyron şəbəkə sözləri birbaşa anlaya bilmir; onları əvvəlcə tokenlərə və vektorlara çevirməliyik. Eyni zamanda model çıxışda söz yox, ehtimallar vektoru verir. Temperatur parametri ilə bu ehtimallardan sözlərin necə seçildiyini öyrənəcəyik.
</div>

---

<!-- Slayd 31: 1. Tokenizasiya (Tokenization) -->

# ✂️ 1. Tokenizasiya (Tokenization): Sözlərdən Rəqəmlərə
### Subword BPE (Byte Pair Encoding), Qısaltmalar və Emojilərin Parçalanması

<div class="grid-2">
<div>

* 🔢 **Niyə Tokenizasiya?**
  * Neyron şəbəkələr simvolları deyil, yalnız ədədi qiymətləri emal edə bilir.
  * Ən sadə yanaşma hər sözə bir nömrə vermək olardı, lakin bu yanaşma nadir sözlərdə və böyük lüğətlərdə iflasa uğrayır.
* 🧩 **OpenAI Tokenizer Qaydaları (Subword BPE – Byte Pair Encoding / Bayt Cütlərinin Kodlaşdırılması):**
  * *Tez-tez təkrarlanan simvol/bayt cütlərini ardıcıl birləşdirərək lüğəti optimallaşdıran və nadir sözləri yarımsözlərə (subwords) bölən alqoritm.*
  * **1. Subwords (Yarımsözlər):** Mürəkkəb sözlər kök və hissələrə ayrılır:
    * `indivisible` ➔ `ind` + `iv` + `isible` (3 ayrı token!).
  * **2. Qısaltmalar:** `don't` ➔ `don` + `'t` (`'t` ayrıca "not" inkarı bildirir).
  * **3. Punktuasiya:** Hər bir vergül, nöqtə və tire ayrıca müstəqil tokendir.
  * **4. Emojilər və Unicode:** 4 baytlıq UTF-8 bayt tokenlərinə ayrılır (`🚀`).
  * **5. Rəqəm Ardıcıllıqları:** Tez-tez görünən rəqəmlər (`123`, `45`) tək blok kimi qruplaşır.

</div>
<div>

<div class="diagram-img">
  <img src="images/slide31_tokenization_visual.svg" alt="OpenAI Tokenizer Visual">
</div>

<div class="box-idea">
💡 <strong>Nəticə:</strong> İngilis dilində təxminən 100 söz 75 tokenə uyğun gəlir (1 token ≈ 0.75 söz və ya 4 simvol).
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Çoxları düşünür ki, hər söz bir tokendir. Amma əslində belə deyil! Məsələn, 'indivisible' sözü tək bir söz olsa da, model onu üç ayrı tokenə bölür: 'ind', 'iv' və 'isible'. Bu yanaşma modelə heç vaxt görmədiyi yeni sözləri belə kök və şəkilçilərinə görə asanlıqla anlamaq imkanı verir.
</div>

---

<!-- Slayd 32: 2. Token Embedding -->

# 🌌 2. Token Embedding: Semantik Məna Fəzası
### Rəqəmlərdən Vektorlara və Kosinus Oxşarlığı (Cosine Similarity)

<div class="grid-2">
<div>

* 📍 **Token İD-dən Çoxölçülü Fəzaya:**
  * Tokenizasiyadan sonra əlimizdə sadəcə tam ədədlər qalır (`534`, `12044`).
  * Bu ədədlər lüğət cədvəlindən (*Embedding Matrix*) çoxölçülü vektorlara çevrilir (GPT-3-də 12,288 ölçülü vektor!).
* 📐 **Kosinus Oxşarlığı (Cosine Similarity):**
  * İki token arasındakı semantik yaxınlıq onların vektorları arasındakı **bucağın kosinusu** ilə ölçülür:
    * Bucağın dərəcəsi `0°` olduqda ➔ `cos(0°) = 1.0` (Tam eyni məna).
    * Bucağın dərəcəsi `90°` olduqda ➔ `cos(90°) = 0.0` (Heç bir əlaqə yoxdur).
* 👑 **Vektor Cəbri:**
  * `Vektor("Kral") - Vektor("Kişi") + Vektor("Qadın") ≈ Vektor("Kraliça")`
  * Model sözlərin təkcə adını deyil, insan dünyasındakı bütün konseptual münasibətlərini bu həndəsi fəzada saxlayır.

</div>
<div>

<div style="background:#0f172a; padding:18px; border-radius:12px; border:1px solid #334155;">
  <div style="color:#38bdf8; font-weight:700; margin-bottom:10px;">🌐 Semantik Vektor Münasibətləri</div>
  <div style="display:flex; flex-direction:column; gap:8px;">
    <div style="background:#1e293b; padding:10px 12px; border-radius:6px; border-left:3px solid #f59e0b;"><strong>Kral ➔ Kişi:</strong> Monarxiya + Kişi</div>
    <div style="background:#1e293b; padding:10px 12px; border-radius:6px; border-left:3px solid #ec4899;"><strong>Kraliça ➔ Qadın:</strong> Monarxiya + Qadın</div>
    <div style="background:rgba(99,102,241,0.15); border:1px solid rgba(99,102,241,0.4); padding:8px 12px; border-radius:6px; text-align:center; color:#c7d2fe;">📐 Kosinus Oxşarlığı: Bərabər Vektor Məsafəsi</div>
  </div>
</div>

<div class="box-analogy">
🧭 <strong>Həndəsi Xəritə:</strong> Embedding mətni rəqəmsal xəritəyə çevirir: oxşar mənalı sözlər qonşu şəhərlər kimi bir-birinin yanında yerləşir.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Embedding tokenləri minlərlə ölçülü fəzada vektorlara çevirir. Bu fəzada iki vektor arasındakı bucağın kosinusu onların məna oxşarlığını bildirir. 'Pişik' və 'it' vektorları bir-birinə çox yaxın bucaqda yerləşdiyi halda, 'təyyarə' sözü onlardan tamamilə fərqli istiqamətə yönəlir.
</div>

---

<!-- Slayd 33: 3. Positional Encoding -->

# 🌊 3. Positional Encoding: Sinus və Kosinus Dalğaları
### Paralel Şəbəkədə Söz Sırasını İtirməmək Üçün Riyazi İxtira

<div class="grid-2">
<div>

* ❓ **Problem: Şəbəkə Sıranı Necə Bilir?**
  * RNN-lər mətni sözbəsöz ardıcıl oxuyurdu. Lakin Transformator bütün cümləni **eyni anda paralel** qəbul edir.
  * Mövqe kodu olmasa, model *"Əli Vəlini vurdu"* ilə *"Vəli Əlini vurdu"* cümlələrini eyni zənn edər!
* 📈 **Niyə Sadə Nömrələmə (1, 2, 3...) Yaramır?**
  * Cümlələrin uzunluğu qeyri-məhduddur (5 söz də ola bilər, 5,000 söz də).
  * Böyük ədədlər neyron çəkilərini partladar və model uzun mətnlərdə çaşar.
* 🎵 **Həll: Sinus və Kosinus Dalğaları:**
  * Sinus və kosinus dalğaları sonsuza qədər təkrarlanır və həmişə `[-1, +1]` intervalında qalır.
  * Hər bir ölçü fərqli tezlikdə titrəyir:
    * **Aşağı ölçülər:** Yüksək tezlik (qonşu sözləri fərqləndirir).
    * **Yuxarı ölçülər:** Alçaq tezlik (uzaq məsafəli mövqeləri tənzimləyir).

</div>
<div>

<div class="diagram-img">
  <img src="images/slide33_sinusoidal_positional_encoding.svg" alt="Sinusoidal Positional Encoding">
</div>

<div class="box-idea">
➕ <strong>Vektorların Toplanması:</strong> `Yekun Giriş = Token Embedding + Positional Encoding`. Həm sözün mənası, həm də sırası tək vektorda birləşir!
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Transformator ardıcıl işləmədiyi üçün ona sözlərin hansı sırada gəldiyini xüsusi bildirməliyik. Bunun üçün dahi bir riyazi fənddən - sinus və kosinus dalğalarından istifadə olunur. Bu dalğalar heç vaxt həddindən artıq böyümür, həmişə mənfi bir və müsbət bir arasında qalır və istənilən uzunluqda cümləyə uyğunlaşır.
</div>

---

<!-- Slayd 34: 4. Çıxış Emalı və Logitlər -->

# 🎯 4. Çıxış Emalı: Vektordan Logitlərə və Növbəti Sözə
### Output Vector × Embedding Matrisi = Bütün Lüğətin Ehtimal Paylanması

<div class="grid-2">
<div>

* 📤 **Dekoderin Zirvəsi:**
  * Yüzlərlə dekoder blokundan keçən mətn ən sonda tək bir **Çıxış Vektoru (Output Vector)** hasil edir.
  * Sual: Bu vektoru necə yenidən insan sözünə çevirək?
* ✖️ **Embedding Matrisi ilə Vurulma:**
  * Çıxış vektoru lüğətdəki bütün sözlərin ilkin Embedding matrisi ilə vurulur:
    * `Logits = Output Vector × Embedding Matrixᵀ`
  * Nəticədə lüğətdəki 50,000+ sözün hər biri üçün **Logit (Xam Xal)** alınır.
* 📊 **Softmax ilə Ehtimala Çevrilmə:**
  * Nümunə kontekst: `"Wow this course is..."`
  * `0.9` ➔ `amazing` (Ən yüksək)
  * `0.8` ➔ `incredible`
  * `0.6` ➔ `challenging`
  * `0.5` ➔ `hard`

</div>
<div>

<div class="diagram-img">
  <img src="images/slide34_output_processing_temperature.svg" alt="Output Processing and Temperature">
</div>

<div class="box-idea">
🔑 <strong>Logits Nədir?</strong> Lüğətdəki hər bir tokenin bu kontekstdə növbəti söz olmağa nə dərəcədə layiq olduğunu göstərən xam riyazi xaldır.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Bütün dekoder bloklarının ən sonunda bir çıxış vektoru yaranır. Biz bu vektoru yenidən lüğətin embedding matrisinə vururuq və hər bir söz üçün Logit adlanan xallar alırıq. 'Wow this course is' cümləsindən sonra 'amazing' sözü 0.9, 'incredible' 0.8 xal alır. İndi əsas məsələ: bu xallardan hansı sözü seçəcəyik?
</div>

---

<!-- Slayd 35: 5. Temperatur Parametri -->

# 🌡️ 5. Temperatur Parametri (Temperature & Sampling)
### Dəqiq Determinizm və Yaradıcı Variativlik Arasındakı Balans

<div class="grid-2">
<div>

* 🎚️ **Model Həmişə Ən Yüksək Ehtimalı Seçməlidirmi?**
  * Əgər model həmişə ən yüksək xallı sözü seçsə, eyni suala **həmişə 100% eyni, darıxdırıcı və robotik** cavab verər.
  * Bu seçimi idarə edən sehrli açar: **Temperatur (T)** parametridir.
* 🧊 **Temperatur = 0.0 (Greedy / Deterministik):**
  * Həmişə ən yüksək ehtimallı token seçilir (`amazing`).
  * Təsadüfilik sıfırdır. Kod yazmaq, faktoloji və riyazi suallar üçün ən ideal rejimdir.
* ☕ **Temperatur = 0.7 - 1.0 (Yaradıcı & Təbii):**
  * Ehtimal paylanması yumşaldılır; ikinci və ya üçüncü ən yaxşı sözlərin də seçilmə şansı yaranır (`incredible` və ya `challenging`).
  * Şeir, hekayə, beyin həmləsi və söhbət üçün mükəmməldir.
* 🔥 **Temperatur > 1.5 (Xaos Tələsi):**
  * Həddən artıq yüksək temperatur məntiqsiz söz yığını və cəfəngiyyat yaradır.

</div>
<div>

<div style="background:#0f172a; padding:18px; border-radius:12px; border:1px solid #334155;">
  <div style="color:#38bdf8; font-weight:700; margin-bottom:10px;">📊 Ehtimal və Temperatur Təsiri:</div>
  <div style="background:#1e293b; padding:10px 12px; border-radius:8px; margin-bottom:10px; border-left:3px solid #38bdf8;">
    <div style="color:#38bdf8; font-weight:700;">❄️ T = 0.0: 100% "amazing" (Deterministik)</div>
    <div style="color:#94a3b8; font-size:0.85rem;">Həmişə ən yüksək xallı tək söz seçilir.</div>
  </div>
  <div style="background:#1e293b; padding:10px 12px; border-radius:8px; border-left:3px solid #f97316;">
    <div style="color:#fb923c; font-weight:700;">🔥 T = 0.7: Balanslaşdırılmış Yaradıcılıq</div>
    <div style="color:#cbd5e1; font-size:0.85rem;">"amazing": 60%, "incredible": 25%, "challenging": 10%</div>
  </div>
</div>

<div class="box-warning">
⚠️ <strong>Qızıl Qayda:</strong> Dəqiq analiz və proqramlaşdırma üçün `T = 0.0 - 0.2`; yaradıcı yazı və dialoq üçün `T = 0.7 - 0.8` tövsiyə olunur.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Temperatur parametri modelin nə dərəcədə 'yaradıcı' və ya 'dəqiq' olacağını təyin edir. Əgər temperaturu sıfır etsəniz, model həmişə ən yüksək ehtimallı tək sözü seçəcək. Amma temperaturu 0.7 etdikdə, model bəzən ikinci ən yaxşı sözü də seçə bilər ki, bu da dilin daha zəngin və insan kimi təbii səslənməsini təmin edir.
</div>

---

<!-- Slayd 36: Dərs 4 (Hissə 2) Xülasəsi -->

# 🔄 Dərs 4 (Hissə 2) Xülasəsi: Girişdən Çıxışa Bütöv Dövriyyə

| Mərhələ | Texniki Mexanizm | Nəticə və Əhəmiyyəti |
| :--- | :--- | :--- |
| **1. Tokenizasiya** | Subword BPE Parçalanması | Mətni ədədlərə çevirir, qısaltmaları və emojiləri qoruyur |
| **2. Token Embedding** | Çoxölçülü Vektor Cədvəli | Sözlərin semantik mənasını və kosinus oxşarlığını saxlayır |
| **3. Positional Encoding** | Sinus və Kosinus Dalğaları | Paralel şəbəkədə sözlərin sırasını və məsafəsini kodlaşdırır |
| **4. Dekoder Qülləsi** | Masked Attention + FFNN | Konteksti dərindən emal edərək vahid çıxış vektoru hasil edir |
| **5. Logitlər (Logits)** | Çıxış Vektoru × Embedding Matrisi | Bütün lüğətdəki 50,000+ söz üçün xam ehtimal xalları |
| **6. Temperatur & Sampling**| Ehtimal Hamarlanması (Softmax/T) | Deterministik dəqiqlik və ya yaradıcı variativlik seçimi |

<div class="box-idea">
🏁 <strong>Yekun Qənaət:</strong> GPT sadəcə bir riyazi dövrədir: sözləri ədədlərə bölür, məna və mövqe vektorlarını toplayır, dekoderdən keçirir və temperatur filtri ilə ən uyğun növbəti sözü seçərək dövrü təkrarlayır.
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Beləliklə, Dərs 4-ü tam yekunlaşdırdıq. Xam insan sözlərinin tokenləşməsindən, vektorlara çevrilməsindən, sinus dalğaları ilə ardıcıllıq qazanmasından tutmuş, çıxışdakı temperaturla yeni sözün seçilməsinə qədər bütün riyazi boru kəmərini tam dərk etdik.
</div>

---

<!-- Slayd 37: Dərs 5 Titulu və İcmal -->
<!-- header: "Generative AI: Transformatorlar və LLM | Dərs 5: Fine Tuning / Transfer Learning with Transformers" -->

# 🎯 Dərs 5: Transfer Learning və Fine-Tuning
### Nəhəng Təməl Modelləri (Foundation Models) Xüsusi Tapşırıqlara Uyğunlaşdırmaq

<div class="grid-2">
<div>

* 💡 **Transfer Learning Nədir?**
  * Sıfırdan nəhəng dil modeli yaratmaq əvəzinə, artıq dili, qrammatikanı və dünyanı bilən hazır **Təməl Modelin (Foundation Model)** biliklərini götürüb dar sahəyə yönləndirmək.
* 💰 **Niyə Fine-Tuning İnqilabdır?**
  * Baza modelin ilkin təlimi (*Pre-training*) milyonlarla dollara və minlərlə GPU-ya başa gəlir.
  * Lakin **Fine-Tuning** cəmi bir neçə dəqiqə və ya saat ərzində, az sayda nümunə ilə istənilən kompüterdə həyata keçirilə bilər!
* 🚀 **Tətbiq Hədəfləri:**
  * Xüsusi sahə bilikləri (Tibb, Hüquq, Maliyyə).
  * Xüsusi üslub və persona (Sarkastik, Korporativ, Fərdi).
  * Yeni tapşırıqlar (Sentiment Analizi, Q&A, Müştəri Dəstəyi).

</div>
<div>

<div class="box-idea">
🎯 <strong>Təməl Fəlsəfə:</strong> Əlifbanı və dili bilən universitet məzununa (Base LLM) şirkətinizin daxili qaydalarını və ya xüsusi bir peşəni öyrətmək kimidir.
</div>

<div class="box-analogy">
🧩 <strong>Pre-Training vs Fine-Tuning:</strong> Pre-training aylar çəkir və bütün interneti oxuyur; Fine-tuning isə cəmi 20-50 nümunə ilə modeli istədiyiniz formaya salır.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Dərs 5-də ən maraqlı və praktik mövzulardan birinə gəlirik: Transfer Learning və Fine-Tuning. Heç bir şirkətin sıfırdan GPT-4 yaratmağa büdcəsi çatmır. Amma buna ehtiyac da yoxdur! Çünki biz hazır baza modelini götürüb, cəmi bir neçə nümunə ilə öz biznesimizə, üslubumuza və ya konkret tapşırığımıza uyğunlaşdıra bilərik.
</div>

---

<!-- Slayd 38: Fine-Tuning-in 3 Əsas Yanaşması -->

# 🛠️ Fine-Tuning-in 3 Əsas Yanaşması
### Tam Təlimdən Qatların Dondurulmasına Qədər

<div class="grid-2">
<div>

* 🔄 **1. Tam Modelin Əlavə Məlumatla Təlimi (Full Retraining):**
  * Baza modelinə (Wikipedia, Reddit və kitablara əlavə olaraq) şirkətin bütün daxili sənədləri verilir və bütün parametrlər cüzi yenilənir.
  * Dərin bilik verir, lakin hesablama baxımından daha bahalıdır.
* ❄️ **2. Qatların Dondurulması (Freezing Specific Layers):**
  * Şəbəkənin aşağı qatları dondurulur (*frozen* - çəkiləri dəyişmir), yalnız yuxarıdakı bir neçə qat yenidən öyrədilir.
  * Nümunə: Yeni dil öyrənmək üçün yalnız yeni Tokenizasiya qatını təlim etmək kifayətdir!
* 🔝 **3. Model Üzərinə Yeni Qat Əlavə Etmək (Task-Specific Head):**
  * Baza modeli 100% toxunulmaz saxlanılır; çıxışına kiçik bir neyron qatı əlavə olunur (*Fine-tuning Head*).
  * Cəmi **20-50 nümunə** ilə modeli tam fərqli tapşırığa uyğunlaşdırmaq mümkündür!

</div>
<div>

<div class="diagram-img">
  <img src="images/slide37_transfer_learning_diagram.svg" alt="Transfer Learning with Transformers Diagram">
</div>

<div class="box-idea">
⚡ <strong>Mühəndislik Üstünlüyü:</strong> Baza modelin trilyonluq parametrlərinə toxunmadan, üstünə cəmi 1 kiçik qat qoymaqla möcüzələr yaratmaq olar.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Fine-tuning üçün 3 əsas yol var: Bütün modeli əlavə data ilə təkrar təlim etmək, müəyyən qatları dondurub yalnız yuxarı qatları öyrətmək və ya ən populyar üsul - baza modelin üzərinə kiçik bir neyron qatı əlavə etmək. Sonuncu üsul cəmi 20-30 nümunə ilə işləyir və inanılmaz dərəcədə qənaətcildir.
</div>

---

<!-- Slayd 39: Praktiki Tətbiq: Persona və Üslub Tənzimlənməsi -->

# 🎭 Praktiki Tətbiq: Persona, Üslub və Ton Tənzimlənməsi
### Az Sayda Nümunə ilə Xarakter Yaratmaq (Few-Shot Fine-Tuning)

<div class="grid-2">
<div>

* 💬 **Ton və Səs Xarakteri (Tone of Voice):**
  * Baza modeli adətən neytral və ensiklopedik cavablar verir.
  * Ona bir neçə fərqli dialoq nümunəsi təqdim etməklə istənilən xarakteri aşılamaq olar.
* 😈 **Sarkastik Bot Nümunəsi (Mühazirədən):**
  * Modelə 20 ədəd acıdil cavab nümunəsi verilir:
    * **İstifadəçi:** *"Hava bu gün necədir?"*
    * **Model:** *"Sənə nə var, dostum?!"* (*"What's it to you, bucko?"*)
  * Model dərhal həmin sarkastik və zarafatcıl tona uyğunlaşır və bütün növbəti suallara bu üslubda cavab verir.
* ✉️ **Şəxsi E-mail Köməkçisi:**
  * Keçmiş illərdə yazdığınız minlərlə e-mail və cavablarınızı modelə ötürürsünüz.
  * Model sizin söz ehtiyatınızı, cümlə quruluşunuzu və nəzakət səviyyənizi öyrənir; nəticədə **tam sizin adınızdan və sizin üslubunuzda** yazışmalar aparır!

</div>
<div>

<div style="background:#0f172a; padding:18px; border-radius:12px; border:1px solid #334155;">
  <div style="background:#1e293b; padding:10px 12px; border-radius:8px; margin-bottom:10px; border-left:3px solid #f59e0b;">
    <div style="color:#fbbf24; font-weight:700;">🎭 Xarakter Tənzimlənməsi (Sarkastik Bot)</div>
    <div style="color:#f43f5e; font-size:0.9rem; margin-top:2px;">➔ 20 nümunədən sonra: "Pəncərədən baxmağa tənbəllik edirsən?!"</div>
  </div>
  <div style="background:#1e293b; padding:10px 12px; border-radius:8px; border-left:3px solid #38bdf8;">
    <div style="color:#38bdf8; font-weight:700;">✉️ Fərdi E-mail Köməkçisi</div>
    <div style="color:#34d399; font-size:0.9rem; margin-top:2px;">➔ AI Cavabı: "Salam Əli bəy, problem deyil, cümə saat 15:00 uyğundur."</div>
  </div>
</div>

<div class="box-analogy">
🎙️ <strong>Aktyorluq Sənəti:</strong> Fine-tuning modelə yeni bir rol verir; ona hansı ssenarini versəniz, həmin xarakteri mükəmməl canlandırır.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Mühazirədə çox maraqlı bir nümunə çəkilir: modelə cəmi 20 sarkastik cavab nümunəsi verirsən və o dərhal acıdil bir xarakter qazanır: 'Hava necədir?' sualına 'Sənə nə var, dostum?!' deyə cavab verir. Eyni məntiqlə öz keçmiş e-maillərinizi modelə verərək tam sizin üslubunuzda cavab yazan şəxsi katib yarada bilərsiniz.
</div>

---

<!-- Slayd 40: Mətn Hasilatından Təsnifata -->

# 📊 Mətn Hasilatından Təsnifata: Sentiment Analizi Keysi
### Söz Generasiyası Əvəzinə Dəqiq Sinifləndirmə

<div class="grid-2">
<div>

* 🔄 **Generasiyadan Təsnifata Keçid:**
  * Transformatorun yalnız yeni mətn yazmaq üçün olduğunu düşünmək səhvdir!
  * Modelin əsas gücü mətni **tam semantik dərinlikdə anlamasındadır**.
* 🧠 **Necə İşləyir?**
  * Baza model mətni oxuyur və cümlənin bütün mənasını cəmləyən yekun embedding vektoru çıxarır.
  * Modelin çıxışına söz hasil edən qat yerinə **Təsnifat Başlığı (Classification Head)** yerləşdiririk.
* 🏷️ **Sentiment Analizi Nümunəsi:**
  * Giriş: *"Bu kursu çox bəyəndim, izahlar möhtəşəmdir!"*
  * Model dərhal çıxış verir ➔ `Müsbət (Positive)`
  * Giriş: *"Çox qarışıqdır, heç nə başa düşmədim."*
  * Model dərhal çıxış verir ➔ `Mənfi (Negative)`
* ⚡ **Ənənəvi Metodlardan Fərqi:** Sadə açar söz axtarışı ironiyanı və jarqonları anlamır; Transformator isə cümlənin alt qatındakı həqiqi hissi dəqiq tutur.

</div>
<div>

<div style="background:#0f172a; padding:18px; border-radius:12px; border:1px solid #334155;">
  <div style="background:rgba(56,189,248,0.1); border:1px solid rgba(56,189,248,0.3); border-radius:6px; padding:8px; margin-bottom:10px;">
    <span style="color:#38bdf8; font-weight:700;">Giriş Rəyi:</span> "Xidmət çox ləng idi, amma yeməklər dadlı idi."
  </div>
  <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:8px;">
    <div style="background:#1e293b; padding:8px; border-radius:6px; text-align:center; border-top:3px solid #10b981;"><span style="color:#34d399;">Müsbət</span><br><strong>15%</strong></div>
    <div style="background:#1e293b; padding:8px; border-radius:6px; text-align:center; border-top:3px solid #fbbf24;"><span style="color:#fbbf24;">Neytral</span><br><strong>75% ⭐</strong></div>
    <div style="background:#1e293b; padding:8px; border-radius:6px; text-align:center; border-top:3px solid #ef4444;"><span style="color:#f87171;">Mənfi</span><br><strong>10%</strong></div>
  </div>
</div>

<div class="box-idea">
🎯 <strong>Universal Alət:</strong> Eyni baza modelindən həm şeir yazan şair, həm də müştəri rəylərini kateqoriyalara ayıran analitik yarada bilərsiniz.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Fine-tuning təkcə mətn generasiyası üçün deyil. Modelin üstünə sadə bir təsnifat qatı qoymaqla mükəmməl Sentiment Analizi sistemi qura bilərsiniz. Model cümlədəki emosiyanı, sarkazmı və gizli mənanı anlayır və mətni dəqiq şəkildə 'müsbət', 'mənfi' və ya 'neytral' sinfinə bölür.
</div>

---

<!-- Slayd 41: Korporativ Tətbiqlər və Etika -->

# ⚠️ Korporativ Tətbiqlər, Risk və Etika (Judicious Care)
### Müştəri Xidməti Botları, Aldadıcı Vədlər və Şirkət Məsuliyyəti

<div class="grid-2">
<div>

* 🎧 **Ən Çox Tətbiq Olunan Ssenari:**
  * Şirkətlər keçmiş zəng qeydləri və müştəri çatları əsasında virtual operator yaradır.
  * Bu çox asandır və şirkət xərclərini dərhal azaldır.
* 🚨 **Təhlükəli Tələ: İcazəsiz Vədlər (*Unfulfilled Commitments*):**
  * Müştəri qarşısındakının bot olduğunu bilmir və ya ona etibar edir.
  * Bot müştəriyə asanlıqla deyir: *"Narahat olmayın, sabah sizə pulsuz yeni telefon göndərəcəyik!"*
  * Amma arxa fonda heç bir sifariş yaranmır, şirkətdə heç kəsin bundan xəbəri olmur!
* 📉 **Fəlakətli Nəticə:**
  * Qəzəbli müştərilər, məhkəmə iddiaları və brendin illərlə qazandığı nüfuzun bir gündə məhv olması.
* 🛡️ **Qızıl Prinsip: "Judicious Care" (Ehtiyatlı İdarəetmə):**
  * Maliyyə, göndəriş və zəmanət vədlərində botun səlahiyyəti məhdudlaşdırılmalı və mütləq insan nəzarəti (*Human-in-the-loop*) olmalıdır.

</div>
<div>

<div style="background:#0f172a; padding:18px; border-radius:12px; border:1px solid #ef4444;">
  <div style="background:#1e293b; padding:10px; border-radius:6px; margin-bottom:8px; border-left:3px solid #38bdf8;"><strong>Müştəri Sorğusu:</strong> "Məhsulum xarab çıxdı, nə edim?"</div>
  <div style="background:#450a0a; padding:10px; border-radius:6px; margin-bottom:8px; border:1px solid #ef4444;"><strong style="color:#fca5a5;">🤖 Nəzarətsiz AI Bot:</strong> "Sabah sizə pulsuz yenisini göndəririk!"</div>
  <div style="background:#1e1b4b; padding:10px; border-radius:6px; border-left:3px solid #f43f5e;"><strong style="color:#f43f5e;">💥 Nəticə:</strong> Şirkətdə heç kəsin xəbəri yoxdur ➔ Aldadılmış müştəri & Nüfuz itkisi!</div>
</div>

<div class="box-warning">
⚠️ <strong>Xəbərdarlıq:</strong> AI çox güclü silahdır. Əsas sual "Biz bunu edə bilərikmi?" deyil, "Bu, müştərimiz üçün həqiqətən daha yaxşı təcrübə yaradırmı?" olmalıdır.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Bu, dərsin ən kritik xəbərdarlığıdır. Şirkətlər tələsik zəng qeydlərindən botlar düzəldirlər. Lakin əgər bot müştəriyə 'sabah sizə yeni məhsul göndərəcəyik' deyirsə və arxada icra mexanizmi yoxdursa, bu şirkət üçün böyük fəlakət olar. AI tətbiq edərkən son dərəcə ehtiyatlı və məsuliyyətli olmaq lazımdır.
</div>

---

<!-- Slayd 42: Dərs 5 Xülasəsi -->

# 📋 Dərs 5 Xülasəsi: Təməl Model vs Fine-Tuning

| Meyar | Təməl Model (Foundation / Pre-trained) | Fine-Tuned Model |
| :--- | :--- | :--- |
| **Məqsəd** | Dili, qrammatikanı və ümumi dünyanı öyrənmək | Konkret tapşırığı, üslubu və ya sahəni icra etmək |
| **Təlim Məlumatı** | Bütün internet (Vikipediya, Reddit, Kitablar) | Xüsusi data (20-1000 nümunə, şirkət sənədləri) |
| **Təlim Xərci** | Milyonlarla dollar, superkompüter klasterləri | Bir neçə dollar və ya cüzi GPU resursu |
| **Təlim Müddəti** | Aylar və ya həftələr | Dəqiqələr və ya saatlar |
| **Qatların Vəziyyəti** | Bütün qatlar sıfırdan öyrədilir | Əsas qatlar dondurulur, yalnız hədəf qatlar öyrədilir |
| **Tipik Nümunə** | GPT-4, LLaMA-3, Claude Baza | Müştəri xidməti botu, Sarkastik bot, Sentiment analiz |

<div class="box-idea">
🏁 <strong>Yekun Qənaət:</strong> Transformatorlar təkrar təkər icad etməyi aradan qaldırdı: bir dəfə öyrədilmiş nəhəng baza modelindən minlərlə ixtisaslaşmış intellektual alət törətmək mümkündür.
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Beləliklə, Transfer Learning transformatorların əsl gücünü ortaya çıxarır. Bir dəfə nəhəng baza modeli təlim olunur və ondan sonra hər kəs öz kiçik datasını əlavə edərək istənilən sahədə ixtisaslaşmış AI sistemləri qura bilir.
</div>

---

<!-- Slayd 43: Dərs 6 Titul Slaydı -->
<!-- header: "Generative AI: Transformatorlar və LLM | Dərs 6: From GPT to ChatGPT: Deep Reinforcement Learning, Proximal Policy Gradients" -->

# 🤖 Dərs 6: GPT-dən ChatGPT-yə: Deep RL və PPO
### Atari Oyunlarından və Robototexnikadan Müasir Dialoq İnqilabına Doğru

<div class="box-idea">
🎯 <strong>Modulun Məqsədi:</strong> GPT baza modelinin sadəcə nəhəng bir bünövrə olduğunu anlamaq və onun necə ChatGPT-yə çevrildiyini kəşf etmək: Video oyunlarında (Pong/Atari) Dərin Gücləndirilmiş Öyrənmə (Deep RL), Robotların yerimə alqoritmi (PPO) və İnsan Əks-əlaqəsi (RLHF).
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #334155;">

### 📋 Dərs 6 Mövzuları:
* GPT sadəcə bir bünövrə blokudur (*Building Block*)
* Atari 2600 və Pong: Xam piksellərlə **Deep RL** təlimi
* **Policy Network** və Gecikmiş Mükafat (*Delayed Reward*) problemi
* **Policy Gradients:** Ehtimal paylanması və parametr yenilənməsi
* **PPO (Proximal Policy Optimization / Yaxınlıq Siyasətinin Optimallaşdırılması):** Modelin siyasətini kəskin və qeyri-sabit sıçrayışlar etmədən, təhlükəsiz "yaxınlıq" hüdudunda (KL divergensiyası ilə) mərhələli optimallaşdıran gücləndirilmiş öyrənmə alqoritmi.
* ChatGPT-nin yaranması: **Deep RL + PPO + RLHF** vəhdəti

</div>
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #334155;">

### 💡 Əsas Tarixi və Elmi Kontekst:
* 🎮 **Video Oyunları:** Kompüterə heç bir oyun qaydası və fizika öyrətmədən təkcə ekran pikselləri ilə Pong oynamağı öyrətmək.
* 🦾 **Robototexnika və PPO:** Robotların yıxılmadan sabit addımlaması üçün yaradılan və ChatGPT-də dil modelinin kəskin pozulmasının qarşısını alan dayanıqlı alqoritm.
* 🤝 **İnsan Təcrübəsi:** Bütün bu texnologiyaların birləşməsi ilə GPT-nin insanla nəzakətli və dəqiq danışmağa öyrədilməsi.

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> GPT təkbaşına yalnız mətni tamamlamağı bacarır. Onu həqiqi ağıllı və faydalı çatbota çevirmək üçün video oyunları və robototexnika sahəsində inkişaf etdirilmiş Dərin Gücləndirilmiş Öyrənmə (Deep RL) və PPO kimi qabaqcıl metodlardan istifadə edilmişdir.
</div>

---

<!-- Slayd 44: Deep RL & Pong -->

# 🎮 GPT-dən ChatGPT-yə: Dərin Gücləndirilmiş Öyrənmə (Deep RL)
### Atari 2600 və Pong Nümunəsi: Xam Piksellərdən Siyasət Şəbəkəsinə (Policy Network)

<div class="grid-2">
<div>

* 🕹️ **Neyron Şəbəkə ilə Gücləndirilmiş Öyrənmə:**
  * Klassik RL neyron şəbəkə ilə birləşdirilərək Atari 2600 oyunlarına tətbiq edildi.
* 👁️ **Giriş Məlumatı — Xam Piksellər:**
  * Şəbəkəyə oyunun qaydaları, fizika qanunları və ya raketkanın nə olduğu öyrədilmir!
  * Yalnız ekran pikselləri (və kadr fərqləri — *difference frames*) daxil edilir.
* 🧠 **Siyasət Şəbəkəsi (Policy Network):**
  * Oyunun cari vəziyyətinə baxaraq hərəkət qərarı verir: *Raketkanı yuxarı, yoxsa aşağı çəkim?*
  * Çıxış: Yuxarı getmə ehtimalı — `P(up)`.
* ⏳ **Gecikmiş Mükafat (Delayed Reward) Çətinliyi:**
  * Topun rəqibdən keçib-keçməməsi yüzlərlə kadr sonra bəlli olur.

<div class="box-idea">
💡 <strong>Əsas Məntiq:</strong> Şəbəkə heç bir öncədən qayda bilmədən, sırf pikselləri və gecikmiş mükafatı təhlil edərək sıfırdan qalibiyyət strategiyasını öyrənir.
</div>

</div>
<div>

<div class="diagram-img"><img src="images/slide43_deep_rl_atari_pong.svg" alt="Deep RL Atari Pong Diagram"></div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Dərin gücləndirilmiş öyrənmədə neyron şəbəkə birbaşa ekran piksellərini (kadr fərqlərini) qəbul edir və hərəkət ehtimalını çıxarır. Ən böyük problem isə mükafatın dərhal deyil, çoxsaylı hərəkətlərdən sonra gəlməsidir.
</div>

---

<!-- Slayd 45: Policy Gradients -->

# 📈 Policy Gradients: Dərhal Etiket Olmayan Mühitdə Təlim
### Gecikmiş Nəticələr və Ehtimal Paylanmasının Hədəfə Doğru Yenilənməsi

<div class="grid-2">
<div>

* ❌ **Ənənəvi Nəzarətli Öyrənmə Niyə İşləmir?**
  * Raketkanı hərəkət etdirdikdə dərhal "düz etdin" və ya "səhv etdin" deyən bir etiket (*label*) yoxdur.
* 🎯 **Hər Hərəkətin Qradiyenti:**
  * Hər bir fərdi hərəkət üçün ehtimal qradiyenti (`∇_θ log p(x)`) yadda saxlanılır.
* ⚖️ **Geri Qayıdıb Qradiyentləri Yeniləmək:**
  * 🏆 **Qalibiyyət:** Oyundakı bütün hərəkətlər müsbət çəki ilə (`+1`) gücləndirilir.
  * ❌ **Məğlubiyyət:** Həmin oyundakı bütün hərəkətlər mənfi çəki ilə (`-1`) cəzalandırılır.
* 🔄 **Parametr Yenilənməsi:**
  * Qalibiyyət gətirən hərəkətlərin ehtimalı artırılır, paylanmanın mərkəzi müsbət hərəkətlərə doğru sıxılır.

<div class="box-analogy">
💡 <strong>Riyazi İntuisiya:</strong> Ehtimal paylanmasındakı nöqtələri təsəvvür edin: yaşıl nöqtələr (+1) paylanmanı özünə çəkir, qırmızı nöqtələr (-1) isə itələyir.
</div>

</div>
<div>

<div class="diagram-img"><img src="images/slide44_policy_gradients_distribution.svg" alt="Policy Gradients Distribution Diagram"></div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Policy Gradients yanaşmasında dərhal itki funksiyası hesablanmır. Hər bir hərəkətin qradiyenti saxlanılır və oyun bitdikdən sonra yekun nəticəyə uyğun olaraq müsbət (+1) və ya mənfi (-1) gücləndirmə ilə ehtimal paylanması yenilənir.
</div>

---

<!-- Slayd 46: Pong AI Behavior & Limitations -->

# 🏓 Policy Gradients Praktikada: Pong AI Nümunəsi
### Uğurlu Qalibiyyət, Qeyri-hamar Hərəkət və Əsas Çatışmazlıqlar

<div class="grid-2">
<div>

* 🏆 **Süni İntellekt Qalib Gəlir!**
  * Policy Gradients ilə təlim keçmiş süni intellekt rəqibinə 5:0 hesabı ilə qalib gəlməyi bacarır.
* ⚡ **Qəribə və Titrək Hərəkətlər (Jerky Motion):**
  * AI raketkanı davamlı olaraq aşağı-yuxarı sıçradır (*Helter-Skelter*).
  * Modeldə fizika qanunları və ya insan intuisiyası yoxdur.
  * Şəbəkəyə "hərəkəti səlis et" mükafatı verilməyib; onun yeganə hədəfi topu geri qaytarmaqdır!
* ⚠️ **Policy Gradients-in Kritik Problemləri:**
  * **1. Addım Ölçüsünə Həssaslıq:** Bir az böyük addım siyasətin tamamilə dağılmasına səbəb olur.
  * **2. Aşağı Səmərəlilik:** Sabit model üçün milyonlarla oyun kadrı tələb olunur.

<div class="box-warning">
⚠️ <strong>Nəticə:</strong> Pong AI qalib gəlsə də, bu metod robototexnika və böyük dil modelləri kimi mürəkkəb sistemlər üçün həddindən artıq qeyri-sabitdir.
</div>

</div>
<div>

<div class="diagram-img"><img src="images/slide45_pong_ai_behavior.svg" alt="Pong AI Behavior Diagram"></div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Pong AI fizika qanunlarını bilmədən qalib gəlsə də, hərəkətləri çox xaotikdir, çünki səlislik üçün mükafatlandırılmayıb. Üstəlik Policy Gradients addım ölçüsünə çox həssasdır və daha böyük problemlərdə qeyri-sabitləşir.
</div>

---

<!-- Slayd 47: Proximal Policy Optimization (PPO) -->

# 🦾 Proximal Policy Optimization (PPO)
### Robototexnikadan LLM-ə: Təhlükəsiz Qradiyent Addımları və KL Divergence

<div class="grid-2">
<div>

* 🤖 **Robototexnikadan Gələn Tələb:**
  * PPO ilk dəfə robotlara yıxılmadan və maneələri aşaraq yeriməyi öyrətmək üçün OpenAI tərəfindən yaradıldı.
* 📏 **"Proximal" Nə Deməkdir? (Yaxınlıq):**
  * Yeni siyasət ilə köhnə siyasət arasındakı ehtimal məsafəsi məhdudlaşdırılır. Siyasətin bir addımda kəskin dəyişməsinə icazə verilmir.
* 📊 **Kullback-Leibler (KL) Divergence:**
  * İki ehtimal paylanması arasındakı fərqi ölçən riyazi alqoritm. Yeni təlim siyasətinin köhnə uğurlu siyasətdən çox uzaqlaşmamasını təmin edən qoruyucu bufer rolunu oynayır.
* ⚙️ **Sadələşdirilmiş Riyaziyyat və SGD:**
  * PPO klipslənmiş obyektiv funksiya ilə KL cəzasını optimallaşdırır, Stokastik Qradiyent Enişi (SGD) ilə tam uyğunlaşır və rahat sazlanır.

<div class="box-idea">
💡 <strong>Əsas Yenilik:</strong> PPO həm robotların sabit yeriməsini təmin edir, həm də neyron şəbəkə kimi standart SGD ilə rahatlıqla öyrədilir.
</div>

</div>
<div>

<div class="diagram-img"><img src="images/slide46_ppo_robot_kl.svg" alt="PPO Robot KL Diagram"></div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> PPO robototexnikada robotların yeriməsini öyrədərkən siyasətin kəskin dağılmasının qarşısını almaq üçün yaradılmışdır. KL divergensiyası vasitəsilə yeni siyasətin köhnədən çox uzaqlaşmaması təmin edilir və sabit öyrənmə əldə olunur.
</div>

---

<!-- Slayd 48: Video Oyunları və Robotların ChatGPT ilə Əlaqəsi -->

# 🔗 Video Oyunları və Robotların ChatGPT ilə Nə Əlaqəsi Var?
### Böyük Konvergensiya: Deep RL + PPO + Foundation LLM ➔ ChatGPT

<div class="grid-2">
<div>

* 🧩 **GPT Təkbaşına Sadəcə Bünövrədir:**
  * Xam GPT yalnız növbəti sözü təxmin edən nəhəng statistik maşındır; o, istifadəçi ilə məntiqli və faydalı dialoq qura bilmir.
* 🤝 **RLHF — İnsan Əks-əlaqəsi ilə Gücləndirilmiş Öyrənmə:**
  * GPT-ni insan istəklərinə uyğunlaşdırmaq (*Alignment*) üçün RLHF tətbiq olunur.
* 🌐 **Bütün Tədqiqatların Birləşdiyi Nöqtə:**
  * 🎮 **Atari Video Oyunları:** Dərin Gücləndirilmiş Öyrənmə (Deep RL) konsepsiyasını verdi.
  * 🦾 **Robototexnika:** Dayanıqlı və effektiv Proximal Policy Optimization (PPO) alqoritmini bəxş etdi.
  * 📖 **LLM Transformatorları:** Nəhəng dil və bilik bünövrəsini təmin etdi.

<div class="box-analogy">
💡 <strong>Nəticə:</strong> GPT baza modeli məhz robotları yeriməyə öyrədən PPO alqoritmi və insan rəyləri (RLHF) ilə incə sazlanaraq ChatGPT-yə çevrilmişdir!
</div>

</div>
<div>

<div class="diagram-img"><img src="images/slide47_convergence_chatgpt.svg" alt="Convergence to ChatGPT Diagram"></div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> ChatGPT-nin arxasında video oyunlarından gələn Dərin RL, robotlardan gələn PPO optimizasiyası və GPT transformatorunun vəhdəti dayanır. Məhz insan rəyi ilə gücləndirilmiş bu sistem GPT-ni təhlükəsiz və faydalı köməkçiyə çevirmişdir.
</div>

---

<!-- Slayd 49: Dərs 7 Titul Slaydı -->
<!-- header: "Generative AI: Transformatorlar və LLM | Dərs 7: From GPT to ChatGPT: Reinforcement Learning from Human Feedback and Moderation" -->

# 🤖 Dərs 7: GPT-dən ChatGPT-yə: İnsan Əks-əlaqəsi (RLHF) və Moderasiya
### Supervised Fine-Tuning (SFT), Mükafat Modeli (Reward Model), PPO və Təhlükəsizlik

<div class="box-idea">
🎯 <strong>Modulun Məqsədi:</strong> Xam GPT modelinin 3 mərhələli <strong>RLHF (Reinforcement Learning from Human Feedback)</strong> prosesi və <strong>Moderasiya Qatı</strong> vasitəsilə necə təhlükəsiz, nəzakətli və insan dəyərlərinə uyğunlaşdırılmış (<em>Aligned</em>) ChatGPT-yə çevrildiyini öyrənmək.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #334155;">

### 📋 Dərs 7 Mövzuları:
* **Addım 1 (SFT):** İnsan annotatorlar tərəfindən dialoqların yazılması və Nəzarətli Siyasət (*Supervised Policy*).
* **Addım 2 (Reward Model):** Variantların sıralanması (*Ranking*) və Mükafat Modelinin təlimi.
* **Addım 3 (PPO):** Qapalı təlim dövrəsi ilə siyasətin avtomatik optimallaşdırılması.
* **ChatGPT Moderasiyası:** 5 qadağan kateqoriya və zərərli məzmun filtrləri.
* **İnsan Əməyi və Etika:** Minlərlə annotatorun görünməz zəhməti.

</div>
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #334155;">

### 💡 Əsas Nəzəri Kontekst:
* Xam GPT yalnız növbəti sözü təxmin edir; o, dialoq aparmağı və yalan danışmamağı bilmir.
* **RLHF Açarı:** İnsan zövqünü və reytinqini rəqəmsallaşdıran Mükafat Modeli qurmaq.
* **OpenAI Araşdırması:** *"A Holistic Approach to Undesired Content Detection"* elmi məqaləsi əsasında təhlükəsizlik baryerləri.

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Bu dərsdə xam GPT-dən ChatGPT-yə keçidin 3 təməl addımını — SFT, Mükafat Modeli və PPO dövrəsini, habelə sistemin təhlükəsizliyini təmin edən Moderasiya qatını ardıcıllıqla öyrənəcəyik.
</div>

---

<!-- Slayd 50: RLHF Step 1 - Supervised Fine-Tuning -->

# ✍️ Addım 1: Nəzarətli İncə Sazlama (Supervised Fine-Tuning — SFT)
### İnsan Annotatorlar, İdeal Dialoq Cütləri və Supervised Policy

<div class="grid-2">
<div>

* 👥 **İlkin Model İnsanlar Tərəfindən Öyrədilir:**
  * Annotatorlar dialoqun hər iki tərəfini canlandırır: həm istifadəçi sualını, həm də nümunəvi ideal cavabı əllə yazırlar.
* 📚 **İlkin Təlim Məlumatları:**
  * InstructGPT layihəsindən gələn böyük dialoq arxivindən və istifadəçi sorğularından istifadə olunur.
* 🎯 **Nəzarətli Siyasət Modeli (Supervised Policy):**
  * Baza GPT modeli bu sual-cavab cütləri ilə incə sazlanır. Model artıq suala 'necə cavab verməli' olduğunu ilkin olaraq öyrənir.
* 🎖️ **ChatGPT-nin Əsas Sirri:**
  * Nəhəng insan ordusunun nəzarətli təlimi sayəsində model dialoq standartlarına yiyələnir və PPO üçün hazır vəziyyətə gətirilir.

<div class="box-idea">
💡 <strong>Əsas Nəticə:</strong> SFT mərhələsi modelə 'dialoq formatını' öyrədir; bu model sonrakı addımlarda PPO alqoritmi ilə daha da təkmilləşdiriləcək.
</div>

</div>
<div>

<div class="diagram-img"><img src="images/slide49_rlhf_step1_sft.svg" alt="RLHF Step 1 SFT Diagram"></div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> İlk addımda böyük insan komandası tərəfindən yazılmış nümunəvi dialoqlarla model nəzarətli şəkildə incə sazlanır (SFT). Bu, modelə dialoq qurmağı öyrədir və Supervised Policy bazasını yaradır.
</div>

---

<!-- Slayd 51: RLHF Step 2 - Reward Model -->

# 🏆 Addım 2: Mükafat Modelinin (Reward Model) Təlimi
### Müqayisəli Reytinq Sıralaması (A > B > D > C) və Rəqəmsal Qiymətləndirici

<div class="grid-2">
<div>

* ⚖️ **Gücləndirilmiş Öyrənmə üçün Mükafat Modeli:**
  * Bu, Pong oyunu deyil ki, dərhal 'uddu/uduzdu' deyək. Minlərlə mətn cavabı arasından ən yaxşısını necə seçməli?
* 📝 **Sual və Çoxsaylı Variantlar:**
  * Tək bir prompt üçün (məsələn: *"Cavid bu papağın altında nə gizlədir?"*) model 4 fərqli cavab generasiya edir (A, B, C, D).
* 👥 **İnsan Sıralaması (Ranking):**
  * İnsan annotator bu 4 cavabı ən yaxşıdan ən pisə doğru sıralayır (məsələn: `A > B > D > C`).
* 🧠 **Mükafat Modelinin (RM) Yaradılması:**
  * Bu sıralama məlumatı ilə müstəqil neyron şəbəkə təlim keçir. Model istənilən cavaba insan zövqünə uyğun skalyar xal verməyi bacarır.
* 🛡️ **GPT-4 Cəzalandırması:**
  * GPT-4-də Mükafat Modeli zərərli, təhlükəli və yalan cavabları xüsusilə ağır mənfi xallarla cəzalandırır.

<div class="box-analogy">
💡 <strong>Məntiq:</strong> İnsanların hər cavabı tək-tək oxumasına ehtiyac qalmır; insan reytinqlərini təqlid edən avtomatik rəqəmsal hakim (Mükafat Modeli) yaradılır.
</div>

</div>
<div>

<div class="diagram-img"><img src="images/slide50_rlhf_step2_reward_model.svg" alt="RLHF Step 2 Reward Model Diagram"></div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> İkinci mərhələdə modelin çıxardığı fərqli cavablar insan annotatorlar tərəfindən ən yaxşıdan ən pisə sıralanır. Bu sıralama məlumatı əsasında cavablara avtomatik xal verən Mükafat Modeli (Reward Model) təlim olunur.
</div>

---

<!-- Slayd 52: RLHF Step 3 - PPO Reinforcement Learning -->

# 🔄 Addım 3: PPO ilə Siyasətin Gücləndirilməsi
### Qapalı Təlim Dövrəsi: Avtomatlaşdırılmış Minlərlə İterasiya və Əks-əlaqə

<div class="grid-2">
<div>

* ⚙️ **Siyasətin Optimallaşdırılması:**
  * Addım 1-də yaradılmış Nəzarətli Siyasət modeli (SFT), Addım 2-dəki Mükafat Modeli vasitəsilə optimallaşdırılır.
* 🦾 **Proximal Policy Optimization (PPO):**
  * Robotları gəzməyə öyrədən dayanıqlı PPO alqoritmi burada dil modelinin çəkilərini yeniləmək üçün tətbiq edilir.
* 🔄 **PPO Təlim Dövrəsi:**
  * 1. Verilənlər bazasından sual seçilir (*"Həyatın mənası nədir?"*).
  * 2. Siyasət modeli cavab çıxarır (*"42!"*).
  * 3. Mükafat modeli bu cavaba xal verir (məsələn: `0.1`).
  * 4. Bu xal əsasında PPO siyasət parametrlərini yeniləyir!
* 📈 **Minlərlə İterasiya:**
  * Model heç bir canlı insan olmadan günlərlə özünü təkmilləşdirir və yüksək ballı cavablara doğru irəliləyir.

<div class="box-idea">
💡 <strong>Əsas Nailiyyət:</strong> PPO KL divergensiyası ilə siyasətin iflasının qarşısını alır və modeli addım-addım insan məntiqinə uyğunlaşdırır.
</div>

</div>
<div>

<div class="diagram-img"><img src="images/slide51_rlhf_step3_ppo_loop.svg" alt="RLHF Step 3 PPO Loop Diagram"></div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Üçüncü addımda SFT modeli ilə Mükafat Modeli qapalı PPO dövrəsində birləşir. Model cavab generasiya edir, mükafat modeli xallayır və PPO alqoritmi vasitəsilə siyasət davamlı olaraq daha yüksək xallara doğru optimallaşdırılır.
</div>

---

<!-- Slayd 53: Moderation System -->

# 🛡️ ChatGPT Moderasiya Qatı (Moderation System)
### 5 Qadağan Kateqoriya, Təsnifatçı Model və İnsan Əməyinin Reallığı

<div class="grid-2">
<div>

* 🚫 **Qadağan Olunmuş 5 Əsas Məzmun:**
  * 🔞 **Cinsi məzmun (Sexual):** Qeyri-etik və yetkinlər üçün materiallar.
  * 🛑 **Nifrət nitqi (Hateful):** İrqi, dini və ya qrup nifrəti.
  * ⚔️ **Zorakılıq (Violent):** Xəsarət, terror və təhdid elementləri.
  * ⚠️ **Özünə qəsd (Self-harm):** İntihar və özünə xəsarət təbliği.
  * 🚫 **Təqib (Harassment):** Təhqir, şantaj və təqib.
* 📄 **OpenAI Tədqiqatı (Markov və b., 2023):**
  * *"A Holistic Approach to Undesired Content Detection in the Real World"* (OpenAI Təhlükəsizlik və Moderasiya Araşdırması) — Çoxmərhələli aktiv öyrənmə və qoruyucu filtrlər.
* 👤 **Ağır İnsan Zəhməti:**
  * Moderasiya modellərini təlim etmək üçün minlərlə insan annotator ən ağır və zərərli mətnləri oxuyub etiketləməyə məcbur olur.

<div class="box-warning">
⚠️ <strong>Reallıq:</strong> RLHF təkbaşına kifayət deyil; moderasiya qatı kənardan zərərli sorğuları və cavabları dərhal kəsən etibarlı təhlükəsizlik baryeridir.
</div>

</div>
<div>

<div class="diagram-img"><img src="images/slide52_chatgpt_moderation_architecture.svg" alt="ChatGPT Moderation Architecture Diagram"></div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> ChatGPT-nin təhlükəsizliyi üçün RLHF ilə yanaşı xüsusi Moderasiya qatı fəaliyyət göstərir. Bu sistem 5 əsas qadağan kateqoriyasını (nifrət, zorakılıq, cinsi məzmun, özünə qəsd, təqib) dərhal filtrdən keçirir və zərərli məzmunun qarşısını alır.
</div>

---

<!-- Slayd 54: Lesson 7 Full Architecture Summary -->

# 📋 Dərs 7 Xülasəsi: 3 Addımlı RLHF və Təhlükəsizlik
### Baza Modelindən Qlobal Asistentə Qədər Bütöv Arxitektura

<div class="grid-2">
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #334155;">

### 📋 3 Addımın Əsas Funksiyaları:
* **1. SFT (Addım 1):** Xam modelə dialoq formatını və nəzakətli cavab vermə qaydalarını aşılayır.
* **2. Reward Model (Addım 2):** İnsan annotatorların reytinqlərini təmsil edən avtomatik xallayıcı şəbəkə yaradır.
* **3. PPO (Addım 3):** Mükafat modelinin rəhbərliyi ilə milyonlarla iterasiyada siyasəti insan zövqünə uyğunlaşdırır.
* **4. Moderasiya Qatı:** Toksikliyi və qadağan kateqoriyaları dərhal bloklayan qoruyucu zirehdir.

<div class="box-idea" style="margin-top:12px;">
🏁 <strong>Yekun Qənaət:</strong> ChatGPT-nin intellekti təkcə Transformator arxitekturasından deyil, məhz bu 3 addımlı RLHF və Moderasiya mühəndisliyindən qaynaqlanır.
</div>

</div>
<div>

<div class="diagram-img"><img src="images/slide53_rlhf_complete_summary.svg" alt="RLHF Complete Summary Diagram"></div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Dərs 7-ni yekunlaşdırsaq: Baza GPT modeli SFT ilə dialoqu öyrənir, Mükafat Modeli ilə qiymətləndirilir, PPO ilə insan dəyərlərinə uyğunlaşdırılır və nəhayət Moderasiya filtrləri ilə təhlükəsizlik zəmanəti qazanır.
</div>

