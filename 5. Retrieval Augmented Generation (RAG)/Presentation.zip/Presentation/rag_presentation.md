---
marp: true
theme: default
paginate: true
backgroundColor: #090d16
color: #f1f5f9
style: |
  section {
    font-family: 'Segoe UI', system-ui, sans-serif;
    padding: 35px 50px;
    background-color: #090d16;
  }
  h1 {
    color: #38bdf8;
    font-size: 1.85rem;
    border-bottom: 2px solid #1e293b;
    padding-bottom: 8px;
  }
  h2 {
    color: #818cf8;
    font-size: 1.15rem;
  }
  h3 {
    color: #f472b6;
    font-size: 1.05rem;
  }
  .box-idea {
    background: rgba(56, 189, 248, 0.08);
    border-left: 4px solid #38bdf8;
    padding: 10px 14px;
    border-radius: 6px;
    margin: 10px 0;
    font-size: 0.92rem;
  }
  .box-analogy {
    background: rgba(52, 211, 153, 0.08);
    border-left: 4px solid #34d399;
    padding: 10px 14px;
    border-radius: 6px;
    margin: 10px 0;
    font-size: 0.92rem;
  }
  .box-warning {
    background: rgba(248, 113, 113, 0.08);
    border-left: 4px solid #f87171;
    padding: 10px 14px;
    border-radius: 6px;
    margin: 10px 0;
    font-size: 0.92rem;
  }
  .grid-2 {
    display: grid;
    grid-template-columns: 1fr 1.3fr;
    gap: 20px;
    align-items: center;
  }
  .speaker-notes {
    background: rgba(251, 191, 36, 0.08);
    border: 1px dashed #fbbf24;
    border-radius: 6px;
    padding: 8px 12px;
    font-size: 0.85rem;
    color: #fef08a;
    margin-top: 15px;
  }
---

<!-- Slayd 1: Module Title & Lesson 1 Intro -->

# 🚀 RAG: Retrieval-Augmented Generation
### Generativ Süni İntellektdə "Açıq Kitab İmtahanı" və "Cheat to Win" Fəlsəfəsi

<div class="box-idea">
🎯 <strong>Modulun Məqsədi:</strong> <strong>RAG (Retrieval-Augmented Generation / Axtarışla Genişləndirilmiş Generasiya)</strong> arxitekturasının nə üçün Generativ AI sahəsində ən zəruri və populyar texnika olduğunu addım-addım öyrənmək: xarici bilik bazalarından dəqiq faktların çıxarılması, sorğunun zənginləşdirilməsi və LLM ilə təbii dildə dəqiq cavab generasiyası.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### 📚 RAG Abreviaturasının Tam İzahı:
* **Retrieval (Axtarış / Məlumatın Tapılması):** İstifadəçinin sualına uyğun ən aktual faktların xarici verilənlər bazasından (vektor, qraf və ya mətn bazası) tapılması.
* **Augmented (Zənginləşdirilmiş / Genişləndirilmiş):** Əldə edilən xarici faktların istifadəçinin ilkin sualı ilə birləşdirilərək prompt şablonuna daxil edilməsi.
* **Generation (Generasiya):** Zənginləşdirilmiş kontekst əsasında LLM-in (GPT-4, Llama və s.) faktiki cəhətdən əsaslandırılmış təbii cavab tərtib etməsi.

<div class="box-analogy">
📖 <strong>"Açıq Kitab İmtahanı" (Open-Book Exam) Analoqiyası:</strong><br>
Model hər şeyi əzbərdən xatırlamağa məcbur deyil; qarşısındakı açıq ensiklopediyadan dəqiq faktı oxuyub səlis şəkildə izah edir.
</div>

</div>
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### 💡 Əsas Dərs Mövzuları və Fəlsəfəsi:
* **"Qalib Gəlmək Üçün Fəndgirlik" (Cheat to Win):** Dünyadakı bütün bilikləri modelin çəkilərinə doldurmaq əvəzinə, faktları bazada saxlayıb lazım olduqda dərhal modelə ötürürük.
* **Bilik Kəsimi (Knowledge Cutoff) Probleminin Həlli:** Model dünən və ya bu gün baş verən ən son hadisələri dərhal cavablandıra bilir.
* **Şirkət Məlumatları (Proprietary Data):** Daxili sənədləri modelə təlim etmədən, təhlükəsiz şəkildə istifadə edirik.
* **İqtisadi Səmərə:** Fine-tuning üçün saatlar və minlərlə dollar xərcləmək əvəzinə, RAG ilə eyni işi 1 sentdən də ucuz başa gətiririk.

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Bu dərsdə Generativ AI-ın ən populyar texnikalarından biri olan RAG (Retrieval-Augmented Generation) konsepsiyasını araşdırırıq. Bu yanaşma "Açıq kitab imtahanı" adlanır. Model bütün dünyadakı məlumatları əzbərləməyə borclu deyil; xarici bazadan dəqiq faktı tapıb prompta qoyuruq və model yalnız səlis dildə cavab formalaşdırır.
</div>

---

<!-- Slayd 2: Core Mechanism & President Speech Example -->

# 📰 RAG-ın İş Mexanizmi: Prezidentin Çıxışı Nümunəsi
### Bilik Kəsimi (Knowledge Cutoff) Məhdudiyyətinin Aradan Qaldırılması

<div class="box-idea">
🎯 <strong>Problem:</strong> İstifadəçi soruşur: <em>"Prezident dünənki çıxışında nə dedi?"</em> GPT modelləri keçmiş bir tarixə qədər təlim olunduğu üçün, model dünən baş vermiş hadisə haqqında məlumatsızdır və ya uyduracaq.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### 🔄 Addım-Addım RAG Prosesi:
1. **Xam İstifadəçi Sorğusu (Raw Query):** İstifadəçi təbii dildə aktual sual verir.
2. **Xarici Baza Sorğusu (Retriever):** Sistem dərhal hər gün yenilənən rəsmi xəbərlər bazasına sorğu göndərir və prezidentin dünənki çıxışına aid ən uyğun məqaləni tapır.
3. **Prompt Zənginləşdirilməsi (Prompt Augmentation):** Tapılan xəbər mətni şablon vasitəsilə sual ilə birləşdirilir:<br>
   <code>"Sual: Prezident dünənki çıxışında nə dedi? Cavab verərkən bu xəbər məqaləsini nəzərə al: [Məqalə mətni]"</code>
4. **LLM Generasiyası:** Model verilmiş mətni oxuyur və istifadəçiyə dəqiq, səlis xülasə təqdim edir.

</div>
<div style="text-align:center;">

![RAG İş Mexanizmi](images/slide02_rag_flow_president.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Prezidentin çıxışı nümunəsi RAG-ın mahiyyətini mükəmməl izah edir. LLM-lər keçmişdə donub qalmış modellərdir. Gündəlik yenilənən xəbərlər bazasından məqaləni tapıb promptun içinə qoyduqda, ChatGPT faktı oradan oxuyub cavablandırır. Bu, sanki axtarış sistemini süni intellekt örtüyünə bürüməkdir.
</div>

---

<!-- Slayd 3: Pros and Cons of RAG -->

# ⚖️ RAG-ın Üstünlükləri və Zəif Cəhətləri (Pros & Cons)
### Fine-Tuning ilə Müqayisə, İqtisadi Səmərə və Texniki Məhdudiyyətlər

<div class="grid-2" style="grid-template-columns: 1fr 1fr; gap:20px;">
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #059669;">

### ✅ Üstünlüklər (Pros):
* **Sürətli və Çox Ucuz:** Fine-tuning saatlarla qrafik prosessor (GPU) işi və yüksək xərc tələb etdiyi halda, RAG ilə sistemi qurmaq bir neçə sentdən (< USD 0.01) az xərclə başa gəlir.
* **Məlumatın Asan Yenilənməsi:** Modeli təkrar təlim etməyə ehtiyac yoxdur. Sadəcə xarici bazaya yeni sənədi və ya sətiri əlavə etmək kifayətdir.
* **Şirkət Məlumatlarının Məxfiliyi:** Məlumatlar modelin daxili çəkilərinə (weights) hopdurulmur; hüquqi baxımdan "biz AI modelini təlim etmirik, yalnız sənədlərdə axtarış edirik" bəyanatı verilir.
* **Hallüsinasiyanın Azaldılması:** Model fakt uydurmaq əvəzinə sənəddəki faktlara istinad edir.

</div>
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #dc2626;">

### ⚠️ Mənfi Cəhətlər və Risklər (Cons):
* **"Dünyanın Ən Mürəkkəb Axtarış Mühərriki":** Sadə bir məlumat bazası axtarışını generativ AI ilə qəlizləşdirmək lazımsız gecikmə və xərc yarada bilər; bəzən axtarış nəticəsini birbaşa göstərmək daha yaxşıdır.
* **Prompt Şablonuna Yüksək Həssaslıq:** Əgər promptun söz düzümü səhvdirsə, model mətni sözbəsöz tutuquşu kimi təkrar edə bilər və ya konteksti nəzərə almayacaq.
* **Qeyri-müəyyənlik (Non-deterministic):** Əsas LLM modeli versiya dəyişdikdə və ya yeniləndikdə, eyni prompt şablonuna gözlənilməz reaksiyalar verə bilər.
* **Hallüsinasiya 100% Yox Olmursa:** Əgər Retriever bazadan səhv, natamam və ya uyğunsuz sənəd gətiribsə, model yenə də yanlış cavab generasiya edəcəkdir.

</div>
</div>

<div class="box-warning" style="margin-top:14px;">
🔍 <strong>Mühəndis Yanaşması:</strong> Hər tapşırıq üçün dərhal RAG tətbiq etməyə tələsməyin. Əvvəlcə düşünün: <em>"Biz sadəcə axtarış nəticəsini təbii dilə çevirmək üçün sistemi həddən artıq qəlizləşdiririkmi?"</em>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> RAG-ın ən böyük üstünlüyü iqtisadi və sürətli olmasıdır. Lakin mənfi cəhətləri də unutmaq olmaz. RAG hallüsinasiya problemini tam aradan qaldırmır; əgər bazadan çıxarılan məlumat zəifdirsə, model yenə yalan danışacaq. Həmçinin hər şeyi RAG ilə qəlizləşdirmək əvəzinə, sadə axtarış sistemlərinin yetərli olub-olmadığını qiymətləndirmək lazımdır.
</div>

---

<!-- Slayd 4: Jeopardy Architecture -->

# 🏆 RAG Arxitekturası: "Jeopardy!" İntellektual Oyunu
### Retriever və Generator Tandeminin İşləmə Qaydası

<div class="box-idea">
🎯 <strong>Məsələ:</strong> "Jeopardy!" intellektual oyununda oyunçuya fakt (cavab) verilir, o isə düzgün sualı tapmalıdır. Məsələn: <em>"1986-cı ildə Meksika bu beynəlxalq idman yarışına ikinci dəfə ev sahibliyi edən ilk ölkə oldu."</em>
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### 🧩 Arxitektura Blokları:
* **Query Encoder (Sorğu Kodlaşdırıcı):** İstifadəçinin verdiyi xam sualı/ipucunu təhlil edir, əsas semantik açar sözləri və vektor təsvirini hazırlayır.
* **Database of Jeopardy! Questions:** Tarix boyunca bütün Jeopardy suallarının saxlandığı xarici arxiv bazası.
* **Sənədlərin Sıralanması (Top Documents):** Retriever uyğunluq ehtimalına görə ən yaxın sənədləri çıxarır (məsələn, 1986 Dünya Çempionatı faktı 98% uyğunluqla birinci çıxır).
* **Generator (LLM):** Sual və ən uyğun sənədi birləşdirərək dəqiq cavabı hasil edir: <code>"What is the World Cup?"</code>

<div class="box-analogy">
💡 <strong>Əsas Prinsip:</strong> Generator cavabı "havadan" götürmür; Retriever ona düzgün sənədi təqdim etdiyi üçün çıxış 100% dəqiq olur.
</div>

</div>
<div style="text-align:center;">

![Jeopardy RAG Arxitekturası](images/slide04_jeopardy_rag_architecture.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Jeopardy oyunu Retriever və Generator bölgüsünü anlamaq üçün klassik nümunədir. Sistem iki yerə bölünür: Retriever sualı kodlaşdırıb arxivdən ən uyğun fakt sənədlərini tapır, Generator isə həmin sənəddən istifadə edərək səlis cavab formalaşdırır.
</div>

---

<!-- Slayd 5: Choosing a Database & Tools API -->

# 🗄️ RAG üçün Baza Seçimi və OpenAI Tools API
### Qraf Bazaları, Mətn Axtarışı və Strukturlaşdırılmış JSON Sorğuları

<div class="box-idea">
🎯 <strong>Əsas Qayda:</strong> RAG üçün hər zaman eyni növ baza seçilmir; axtarılan məlumatın xarakterinə ən uyğun verilənlər bazası seçilməlidir.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### 🗃️ Baza Seçimləri və Təyinatı:
* **Qraf Bazaları (Graph DB - Neo4j):** Məhsul tövsiyələri, dostluq şəbəkələri və subyektlər arasındakı mürəkkəb əlaqələri axtarmaq üçün idealdır.
* **Mətn Axtarış Sistemləri (Elasticsearch):** Ənənəvi açar söz axtarışı, **TF-IDF** (Term Frequency - Inverse Document Frequency) və BM25 alqoritmləri ilə sürətli mətn axtarışı təmin edir.

### ⚙️ OpenAI Tools / Functions API:
Sadə prompt inyeksiyasından daha intizamlı üsul: GPT modelinə sualdan strukturlaşdırılmış JSON parametrləri çıxartdırırıq:
* *"Which pink items are suitable for children?"* ➔ `{"color": "pink", "age_group": "children"}`
* *"Gardening gear that is waterproof"* ➔ `{"category": "gardening", "characteristic": "waterproof"}`

</div>
<div style="text-align:center;">

![RAG Baza Seçimi və Tools API](images/slide05_choosing_database_tools_api.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> RAG yalnız vektor bazalarından ibarət deyil. Əgər məhsul tövsiyəsi edirsinizsə, Neo4j kimi qraf bazası daha uyğundur. Ənənəvi mətn axtarışı üçün isə Elasticsearch kifayətdir. Həmçinin OpenAI Tools API vasitəsilə təbii dildəki sualdan JSON parametrləri çıxararaq bazanı daha intizamlı sorğulamaq mümkündür.
</div>

---

<!-- Slayd 6: Embedding Vectors & Vector Databases -->

# 🌌 Embedding Vektorları və Vektor Bazaları
### Çoxölçülü Semantik Məkan, Klasterlər və K-Ən Yaxın Qonşu (KNN)

<div class="box-idea">
🎯 <strong>Vektor Nədir?</strong> Embedding mətni yüzlərlə və ya minlərlə ölçülü fəzada ədədi koordinata çevirir. Məna baxımından oxşar sözlər və cümlələr bu çoxölçülü məkanda bir-birinə çox yaxın yerləşir.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### 📐 Semantik Məkan və Vektor Axtarışı:
* **Klasterləşmə:** *"potato"* və *"carrot"* tərəvəz klasterində bir yerdədir; *"Starship Enterprise"*, *"Spaceballs"* və *"The Orville"* isə elmi-fantastika klasterində cəmlənir.
* **Vektor Axtarışı (Vector Search):** Axtarılan sual üçün embedding hesablanır və bazada **KNN (K-Nearest Neighbors)** alqoritmi və ya Kosinus Yaxınlığı ilə ən yaxın Top-N qonşu tapılır.

### 🗄️ Vektor Verilənlər Bazası Növləri:
* **Xüsusi Vektor Bazaları (Purpose-built):**
  * Kommersiya: *Pinecone, Weaviate*
  * Açıq Mənbəli: *Chroma, Qdrant, Milvus, vectordb* (sadə Python modulu)
* **Uyğunlaşdırılmış Sistemlər:**
  * *PostgreSQL (pgvector), Elasticsearch, Redis, MongoDB, Cassandra*

</div>
<div style="text-align:center;">

![Embedding Məkanı və Vektor Bazası](images/slide06_embedding_space_vector_db.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> İnternetdə RAG haqqında materialların çoxu vektor bazalarından bəhs edir. Səbəb sadədir: dərin təlimdə mətnlər onsuz da embedding vektorlarına çevrilir. Bu vektorları xüsusi bazada saxlayaraq KNN ilə ən yaxın sənədləri dərhal tapmaq çox asan və ucuzdur.
</div>

---

<!-- Slayd 7: Star Trek Data Case Study -->

# 🖖 Praktiki RAG: "Star Trek" Komandir Data Personajı
### 200 Seriyalıq Dialoq Arxivinin Vektorlaşdırılması və 1 Sentdən Az Xərclə Canlandırılması

<div class="box-idea">
🎯 <strong>Məqsəd:</strong> Fine-tuning ilə saatlarla model təlim etmək əvəzinə, RAG ilə "fənd işlədərək" Star Trek-in sevilən süni intellekt personajı Komandir Datanı canlandırmaq.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### ⚡ İcra Mərhələləri:
1. **Offline Vektorlaşdırma:** Data-nın 200 televiziya seriyasındakı bütün replikaları çıxarılır, OpenAI Embeddings ilə vektorlaşdırılıb `vectordb` bazasına yazılır. Bütün arxivin emalı **1 sentdən az (< USD 0.01)** xərc tələb edir!
2. **İstifadəçi Sualı:** *"Data, tell me about your daughter Lal."*
3. **Top Oxşar Replikalar:** Vektor bazasından Datanın qızı Lal haqqında dediyi ən uyğun sətirlər dərhal tapılır.
4. **Zənginləşdirilmiş Prompt:** Replikalar prompt şablonuna qoyulur və Chat Completions API-a ötürülür.
5. **Dəqiq Nəticə:** Model heç bir çəki təlimi olmadan, saniyələr içində Datanın xarakterik təmkinli səsi və dəqiq faktları ilə cavab verir!

<div class="box-analogy">
💰 <strong>İqtisadiyyat:</strong> Fine-tuning = saatlarla GPU təlimi və yüksək xərc; RAG = sıfır təlim vaxtı və < USD 0.01 xərc!
</div>

</div>
<div style="text-align:center;">

![Star Trek Data RAG Boru Kəməri](images/slide07_star_trek_data_pipeline.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Bu praktiki nümunə RAG-ın gücünü aşkar edir. Star Trek-in 200 seriyalıq arxivini vektor bazasına yığmaq və Lal haqqında sorğulamaq cəmi 1 sentdən az xərc tələb etdi. Əgər bunu fine-tuning ilə etsəydik, saatlarla təlim aparmalıydıq. RAG son dərəcə ucuz, sürətli və effektiv bir həlldir.
</div>

---

<!-- Slayd 8: Lesson 2 Intro & The RAG Triad -->

# 📊 RAG Metrikaları və RAG Triadası (The RAG Triad)
### Sistem Nəticələrinin Obyektiv Qiymətləndirilməsi və Əsas Komponentlər

<div class="box-idea">
🎯 <strong>Dərsin Məqsədi:</strong> RAG sistemlərini subyektiv baxışdan ("mənə elə gəlir ki, yaxşı işləyir") xilas edib, kəmiyyətcə ölçülə bilən obyektiv metrikalarla qiymətləndirmək. Sistemə etdiyimiz dəyişikliklərin keyfiyyəti artırdığını və ya korladığını rəqəmlərlə sübut etmək.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### 🔺 RAG Triadasının 3 Əsas Komponenti:
* **Query (İstifadəçi Sorğusu):** İstifadəçinin daxil etdiyi ilkin sual və ya təlimat.
* **Context (Çıxarılmış Kontekst):** Retriever vasitəsilə xarici bazadan tapılan sənədlər və mətn fraqmentləri.
* **Response (LLM Cavabı):** Modelin təqdim olunan kontekst əsasında hasil etdiyi yekun cavab.

### 📐 Triadanın 3 Qiymətləndirmə Oxu (Metrikalar):
* **1. Context Relevance (Query ➔ Context):** Axtarış sistemi suala həqiqətən aidiyyəti olan faktları tapıbmı, yoxsa lazımsız küy gətirib?
* **2. Groundedness / Faithfulness (Context ➔ Response):** Modelin cavabı çıxarılan kontekstə tam söykənirmi, yoxsa model fakt uydurub (hallüsinasiya edib)?
* **3. Answer Relevance (Response ➔ Query):** Modelin cavabı istifadəçinin ilkin sualına birbaşa cavab verirmi, yoxsa mövzudan yayınıb?

<div class="box-analogy">
⚡ <strong>Ragas Framework:</strong> Bu metrikaların əksəriyyətini avtomatik ölçən xüsusi Python alətlər paketi (<em>Retrieval Augmented Generation Assessment</em>).
</div>

</div>
<div style="text-align:center;">

![The RAG Triad](images/slide08_rag_triad.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> RAG sistemlərini mürəkkəbləşdirdikcə onların keyfiyyətini subyektiv hisslərlə deyil, rəqəmsal metrikalarla ölçmək vacibdir. "RAG Triadası" 3 əsas komponentdən (Query, Context, Response) və onların arasındakı 3 əsas əlaqədən (Context Relevance, Faithfulness, Answer Relevance) ibarətdir. Bu qiymətləndirmələri avtomatlaşdırmaq üçün Ragas kitabxanasından istifadə olunur.
</div>

---

<!-- Slayd 9: Context Relevance & LLM Chaining -->

# 🎯 Kontekst Uyğunluğu (Context Relevance) və LLM Chaining
### Retriever-in Gətirdiyi Məlumatdakı Səs-Küyün (Noise) Ölçülməsi

<div class="box-idea">
🎯 <strong>Problem:</strong> Retriever verilənlər bazasından sənədləri çıxararkən çox vaxt suala birbaşa aidiyyəti olmayan cümlələr də gətirir. Artıq səs-küy LLM-in diqqətini yayındırır və kontekst pəncərəsini dolduraraq xərci artırır.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### 🤖 LLM Hakim Kimi (LLM-as-a-Judge):
Kontekstin uyğunluğunu ölçmək üçün LLM-in özündən istifadə edirik:
* *"Zəhmət olmasa, təqdim edilmiş kontekstdən verilən sualı cavablandırmağa birbaşa kömək edəcək uyğun cümlələri çıxarın..."*

### 🔗 Sorğuların Zəncirlənməsi (LLM Chaining / LangChain):
Bir LLM sorğusunun nəticəsi (çıxarılan uyğun cümlələr) digər qiymətləndirmə moduluna ötürülür. LangChain bu zəncirləməni asanlaşdırır.

### 📐 Hesablama Düsturu:
`Context Relevance = Çıxarılan Uyğun Cümlələr / Kontekstdəki Ümumi Cümlələr`

* **Yüksək Uyğunluq (1.0):** 2 cümlənin 2-si də Fransanın paytaxtına aiddir (küy = 0).
* **Aşağı Uyğunluq (0.5):** 4 cümlədən 2-si şərab və mağara rəsmləridir (küy = 50%).

</div>
<div style="text-align:center;">

![Context Relevance Sxemi](images/slide09_context_relevance.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Context Relevance axtarış sistemimizin nə dərəcədə təmiz işlədiyini göstərir. Əgər bazadan çıxarılan 10 cümlədən yalnız 2-si suala aiddirsə, kontekst uyğunluğu 20% təşkil edir. Bu metrikanı ölçmək üçün LLM-ə kontekstdən sualla bağlı cümlələri çıxartdırırıq və ümumi cümlə sayına bölürük.
</div>

---

<!-- Slayd 10: Context Recall & Ground Truth -->

# 📋 Kontekst Tamlığı (Context Recall) və Etalon Cavab (Ground Truth)
### Retriever Əsas Faktları Tam Əhatə Edirmi?

<div class="box-idea">
🎯 <strong>Məqsəd:</strong> İstifadəçi sualına mükəmməl cavab vermək üçün lazım olan BÜTÜN faktların bazadan tapılıb-tapılmadığını yoxlamaq.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### 🎯 Etalon Cavab (Ground Truth) Anlayışı:
Context Recall-u ölçmək üçün əvvəlcədən hazırlanmış **etalon (doğru) cavab** tələb olunur:
* *Sual: "Fransa haradadır və paytaxtı haradır?"*
* *Etalon: "Fransa Qərbi Avropadadır (Fakt 1) və paytaxtı Parisdir (Fakt 2)."*

### 🧩 Bəyanatlara Bölünmə (Statement Splitting):
Etalon cavab LLM vasitəsilə atomik faktlara ayrılır və hər bir faktın axtarış kontekstində olub-olmaması yoxlanılır.

### 📐 Hesablama Düsturu:
`Context Recall = Kontekstdə Təsdiqlənən Etalon Faktlar / Etalondakı Ümumi Faktlar`

* **Yüksək Recall (1.0 / 100%):** Kontekstdə həm Qərbi Avropa, həm də Paris faktı var.
* **Aşağı Recall (0.5 / 50%):** Kontekst Qərbi Avropanı göstərir, lakin Paris qeyd olunmayıb.

</div>
<div style="text-align:center;">

![Context Recall və Precision](images/slide10_context_recall_precision.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Context Recall axtarışın nə dərəcədə əhatəli olduğunu göstərir. Bunun üçün bizə "Ground Truth" (etalon cavab) lazımdır. Məsələn, sual iki hissədən ibarətdirsə (haradadır və paytaxtı nədir), amma axtarış nəticəsi yalnız yerini deyib paytaxtı unudubsa, Context Recall cəmi 50% olacaq.
</div>

---

<!-- Slayd 11: Context Precision & Ranking-Awareness -->

# 🔍 Kontekst Dəqiqliyi (Context Precision) və Sıralama Həssaslığı
### Ən Vacib və Doğru Sənədlər Axtarışın Ən Başında Gəlirmi?

<div class="box-idea">
🎯 <strong>Əhəmiyyəti:</strong> Axtarış sistemlərində nəticələrin sırası (ranking) həlledicidir. Əgər doğru məlumat 10-cu sənəddə gizlənibsə, LLM onu nəzərə almaya bilər. Doğru faktlar mütləq Top-1 və Top-2 mövqelərində gəlməlidir.
</div>

<div class="grid-2" style="grid-template-columns: 1fr 1fr; gap:20px;">
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #38bdf8;">

### 📊 Sıralamaya Həssas Dəqiqlik (Rank-Aware):
Klassik maşın öyrənməsində dəqiqlik doğru müsbətlərin (True Positives) cəminə nisbətidir:
`Precision = TP / (TP + FP)`

RAG-da isə **Context Precision** hər bir pillədəki (Top-1, Top-2, ... Top-K) dəqiqliyi toplayıb ümumi uyğun elementlərin sayına bölür:
`Context Precision = ∑ Precision@k / (Top K-da uyğun elementlər)`

Əgər ən faydalı sənəd 1-ci yerdədirsə, skor maksimum olur; 5-ci yerə düşdükcə skor kəskin azalır.

</div>
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #f87171;">

### ⚠️ Spikerin Xəbərdarlığı: Metrikanın Aldadılması!
Context Precision çox faydalı olsa da, onu "aldatmaq" (game the metric) çox asandır:
* **Tələ:** Əgər Retriever cəmi 1 sənəd qaytararsa və həmin sənəd doğru olarsa, Precision **100%** çıxacaq!
* **Gizli Qüsur:** Halbuki istifadəçinin sualının digər vacib aspektləri tamamilə cavabsız qalıb (Recall çox aşağıdır).

<div class="box-warning">
💡 <strong>Qızıl Qayda:</strong> Precision heç vaxt təkbaşına qiymətləndirilməməlidir! Hər zaman Recall ilə birlikdə (balanslaşdırılmış şəkildə) təhlil edilməlidir.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Context Precision doğru sənədlərin axtarış siyahısında nə dərəcədə yuxarıda çıxdığını yoxlayır. Lakin spiker xüsusi qeyd edir ki, bu metrikaya ehtiyatla yanaşmaq lazımdır. Çünki sistem cəmi bir doğru sənəd gətirib digər hər şeyi unudarsa, Precision yüksək görünə bilər, amma Recall zəif qalar.
</div>

---

<!-- Slayd 12: Faithfulness (Hallucination Detector) -->

# 🛡️ Sədaqətlilik (Faithfulness): Hallüsinasiya Dedektoru
### Cavab Faktlara Söykənir, Yoxsa Model Yalan Deyir?

<div class="box-idea">
🎯 <strong>Əsas Sual:</strong> <em>"Modelin verdiyi cavab bizə yalan deyirmi?"</em> RAG-ın başlıca vədi hallüsinasiyanı yox etməkdir. <strong>Faithfulness</strong> metriki çıxışın təqdim olunan kontekstə nə dərəcədə sədaqətli qaldığını riyazi olaraq ölçür.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### ⚙️ İki Mərhələli Qiymətləndirmə Prosesi:
1. **Cavabdan Bəyanatların Çıxarılması (|S|):** LLM cavabı müstəqil faktiki fikirlərə bölür:
   `"Create one or more statements from each sentence in the answer..."`
2. **Kontekstdən Çıxarılışın Yoxlanılması (|V|):** LLM hər bir bəyanatın kontekstdə dəstəklənib-dəstəklənmədiyini yoxlayır:
   `"Determine if they are supported by the information in the context..."`

### 📐 Hesablama Düsturu:
`F = |V| / |S|`
*(|V| = kontekstdən təsdiqlənən faktlar, |S| = cavabdakı ümumi faktlar)*

<div class="box-analogy">
🧑‍🔬 <strong>Eynşteyn Nümunəsi:</strong><br>
• Kontekst: <em>"Albert Einstein (born 14 March 1879)..."</em><br>
• Doğru Cavab (14 Mart): Skor = 2/2 = 1.0 (100% Sədaqətli).<br>
• Yanlış Cavab (20 Mart): Skor = 1/2 = 0.5 (50% Hallüsinasiya!).
</div>

</div>
<div style="text-align:center;">

![Faithfulness Qiymətləndirməsi](images/slide12_faithfulness_formula.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Faithfulness RAG sistemlərində hallüsinasiya detektoru rolunu oynayır. Burada cavab xarici dünyaya deyil, yalnız və yalnız Retriever-in gətirdiyi kontekstə müqayisə olunur. Əgər model kontekstdə olmayan bir rəqəm və ya fakt əlavə edibsə (məsələn, 14 mart yerinə 20 mart), Faithfulness dərhal aşağı düşür.
</div>

---

<!-- Slayd 13: Answer Relevance & Inverted Question Approach -->

# 🧭 Cavab Uyğunluğu (Answer Relevance) və Tərs Sual Mexanizmi
### Sualdan Yayınmanın Ölçülməsi və Ragas Praktikasına Keçid

<div class="box-idea">
🎯 <strong>Problem:</strong> Model 100% doğru danışa bilər, lakin istifadəçinin verdiyi sualdan tamamilə kənara çıxa bilər (məsələn, paytaxtı soruşduqda ölkənin iqlimindən danışar). <strong>Answer Relevance</strong> cavabın suala hədəfli olub-olmadığını ölçür.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### 💡 Dahiyanə "Tərs Sual" Metodu (Inverted Approach):
Cavabla sualı sadəcə qarşılaşdırmaq əvəzinə, sistem məsələyə tərs tərəfdən yanaşır:
1. Modelə cavab verilir və soruşulur: *"Bu cavab hansı suala cavab verir? (q_i)"*
2. Hasil edilən sualın (q_i) embedding vektoru hesablanır.
3. İlkin sual (q) ilə generasiya edilmiş suallar arasında **Kosinus Yaxınlığı (Cosine Similarity)** hesablanır.

### 📐 Hesablama Düsturu:
`Answer Relevance = 1/n · ∑ cos(q, q_i)`

<div class="box-idea">
🚀 <strong>Növbəti Addım (Hands-on Laboratoriya):</strong><br>
Növbəti dərsdə Google Colab mühitində Star Trek "Komandir Data" RAG sistemini real verilənlər və <strong>Ragas</strong> kitabxanası ilə sınaqdan keçirəcəyik!
</div>

</div>
<div style="text-align:center;">

![Answer Relevance Sxemi](images/slide13_answer_relevance.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Answer Relevance metriki tərs sual generasiyası ilə işləyir. LLM-ə verilən cavabdan sual yaratması tapşırılır və yaranan sual ilə ilkin sualın embedding vektorları müqayisə edilir. Əgər cavab sualın mahiyyətini tam əks etdirirsə, kosinus yaxınlığı 1-ə yaxın olur. Dərs 2-ni yekunlaşdıraraq növbəti dərsdə Ragas ilə Google Colab laboratoriyasına keçirik.
</div>

---

<!-- Slayd 14: Lesson 3 Intro & Advanced RAG Pipeline -->

# 🚀 Advanced RAG: Naive RAG-dan İrəli Səviyyəli Arxitekturaya
### RAG-ın "R" (Retrieval) Hissəsinin Parçalanması: Pre-Retrieval, Retrieval və Post-Retrieval

<div class="box-idea">
🎯 <strong>Modulun Məqsədi:</strong> Sadə (Naive) RAG modelini inkişaf etdirərək, axtarış prosesini 3 ixtisaslaşmış mərhələyə bölmək: sorğunun optimallaşdırılması, sənədlərin ağıllı parçalanması (chunking), cədvəl/şəkillərdən məlumat çıxarışı və axtarışdan sonrakı çeşidləmə.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### 🔄 Naive RAG vs Advanced RAG:
* **Naive RAG:** İstifadəçi sorğusu ➔ birbaşa bazadan xam axtarış ➔ prompta əlavə et ➔ cavab al. Sadədir, lakin küyə və uyğunsuz nəticələrə çox həssasdır.
* **Advanced RAG:** Axtarışdan əvvəl və sonra xüsusi filtrləmə və təkmilləşdirmə mərhələləri əlavə edilir.

### 🧱 Advanced RAG-ın 3 Əsas Mərhələsi:
1. **Pre-Retrieval (Axtarışaqədər):**
   * • İndeksləmə və məlumatın detallıq səviyyəsi (Granularity)
   * • Sənədlərin parçalanması (Chunking & Semantic Chunking)
   * • Mürəkkəb məlumatların çıxarılması (PDF, cədvəl və şəkillər)
   * • Sorğunun yenidən yazılması (Query Rewriting & Expansion)
2. **Retrieval (Axtarış Mərhələsi):** Vektor, qraf və ya hibrid (BM25 + Vektor) axtarış.
3. **Post-Retrieval (Axtarışdan Sonra):** Nəticələrin yenidən sıralanması (Reranking), küyün təmizlənməsi və kontekstin sıxlaşdırılması.

</div>
<div style="text-align:center;">

![Advanced RAG Boru Kəməri](images/slide14_advanced_rag_pipeline.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Bu dərsdə Naive RAG-dan Advanced RAG-a keçidi araşdırırıq. Naive RAG mətni necə gəldi bazaya yığıb birbaşa axtarır. Advanced RAG isə axtarışın özünü (Retrieval) 3 yerə bölür: Pre-retrieval (indeksləmə, chunking, data extraction və query rewriting), Retrieval və Post-retrieval (reranking). Bu dərsdə əsas diqqətimiz Pre-retrieval mərhələsində olacaq.
</div>

---

<!-- Slayd 15: Data Granularity & Chunking -->

# 🧩 Məlumatın Detallıq Səviyyəsi (Data Granularity) və Chunking
### Verilənlər Bazasına Nəyi və Hansı Həcmdə Saxlamalıyıq?

<div class="box-idea">
🎯 <strong>Əsas Dilemma:</strong> Verilənlər bazasına sənədləri yazarkən hansı ölçüdə fraqmentlər saxlamalıyıq? Tək-tək cümlələr? Bütün səhnə? Yoxsa sabit ölçülü mətn blokları?
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### ⚖️ Detallıq Səviyyələri və Risklər:
* **Həddən Artıq Kiçik (Tək Cümlələr):** Kontekst itir. Cümlədəki əvəzliklərin ("o", "bunu") kimə və nəyə aid olduğu bilinmir.
* **Həddən Artıq Böyük (Bütöv Dialoq / Səhifə):** İçində bir neçə fərqli mövzu qarışır; axtarış zamanı küy artır və token limiti dolur.
* **Optimal Balans:** Məntiqi bütövlüyü olan fraqmentlər və ya ətraf replikaları ehtiva edən sürüşən pəncərələr (sliding window).

### 🧹 İlkin Emal və Xülasələşdirmə:
Məlumatı bazaya saxlamazdan əvvəl LLM vasitəsilə təmizləmək olar:
* Qaranlıq qalan əvəzlikləri (pronouns) açıq adlarla əvəz etmək.
* Geniş mətnləri sıxlaşdırıb qısa xülasə şəklində indeksləmək.

<div class="box-analogy">
✂️ <strong>Chunking Nədir?</strong> Xam mətnin axtarış və emal üçün optimal ölçülü müstəqil fraqmentlərə (parçalara) bölünməsi prosesi.
</div>

</div>
<div style="text-align:center;">

![Məlumatın Detallıq Səviyyəsi və Chunking](images/slide15_data_granularity_chunking.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Məlumatın detallıq səviyyəsi (Data Granularity) RAG sisteminin keyfiyyətini təyin edən təməl faktordur. Star Trek nümunəsində Datanın sözlərini bütöv blok kimi, yoxsa cümlə-cümlə saxlamaq müzakirə olunur. Əgər cümlə tək saxlanılarsa, kontekst itə bilər; çox böyük saxlanılarsa, lazımsız küy yaranar.
</div>

---

<!-- Slayd 16: Naive Chunking & Token Constraints -->

# 📏 Ənənəvi (Naive) Chunking: Sabit Uzunluq və Token Xərcləri
### Xarakter Limiti, Örtüşmə (Overlap) və Kontekst Pəncərəsinin İdarə Edilməsi

<div class="box-idea">
🎯 <strong>Məqsəd:</strong> Modelin kontekst pəncərəsini aşmamaq və generasiyaya yalnız idarəolunan həcmdə token ötürmək.
</div>

<div class="grid-2" style="grid-template-columns: 1fr 1fr; gap:20px;">
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #38bdf8;">

### ⚙️ Sabit Həcmli Parçalama (Fixed-size Chunking):
Əksər ilkin kitabxanaların (LangChain, LlamaIndex default) tətbiq etdiyi mexaniki üsul:
* Mətn sabit simvol və ya token sayına bölünür (məsələn, hər 1000 simvol).
* **Chunk Overlap (Örtüşmə):** Parçalar arasında 100-200 simvolluq kəsişmə saxlanılır.
* *Niyə örtüşmə lazımdır?* Əgər vacib cümlə parçanın tam kəsildiyi yerə düşərsə, məna iki yerə bölünməsin və itməsin!

```text
Chunk 1: [0 – 1000 simvol]
Chunk 2: [800 – 1800 simvol] (200 simvol örtüşmə)
```

</div>
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #fbbf24;">

### 💰 Token İqtisadiyyatı və Naive Chunking Qüsurları:
* **Kontekst Pəncərəsi Böyüyür:** Müasir modellər 128k və hətta 1M token dəstəkləyir, lakin:
  * • **Xərc (Cost):** Daha çox token = birbaşa daha yüksək API xərci!
  * • **Gecikmə (Latency):** Nəhəng kontekst generasiya sürətini ləngidir.
* **Mexaniki Kəsim Qüsuru:** Sabit həcm cümlənin və ya abzasın məntiqi məzmununu nəzərə almır; cümləni sözün ortasından kəsə bilər.

<div class="box-warning">
⚠️ <strong>Nəticə:</strong> Sabit uzunluqlu kəsim sadədir, lakin yüksək dəqiqlikli RAG üçün <strong>Semantik Parçalama</strong> tələb olunur!
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Ənənəvi chunking sadəcə mətni hər 1000 simvoldan bir kəsir və aralarında bir az örtüşmə (overlap) qoyur. Baxmayaraq ki, müasir LLM-lərin kontekst limiti böyüyüb, iqtisadi və sürət baxımından hələ də mətni yığcam saxlamaq məcburiyyətindəyik. Çünki artıq token əlavə xərc və gecikmə deməkdir.
</div>

---

<!-- Slayd 17: Semantic Chunking -->

# 🧠 Semantik Parçalama (Semantic Chunking) Nədir?
### Mətnin Xarakter Sayına Görə Deyil, Məna Bütövlüyünə Görə Bölünməsi

<div class="box-idea">
🎯 <strong>Semantik Müstəqillik:</strong> Hər bir parça mexaniki xarakter sayına görə deyil, daxilindəki fikrin tamlığına və müstəqilliyinə görə formalaşdırılmalıdır. Bir mövzudan digərinə keçid baş verdikdə yeni parça yaradılır.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### 🛠️ 3 Əsas İcra Yanaşması:
* **1. Embedding Əsaslı (LlamaIndex / LangChain):**
  Ardıcıl cümlələrin embedding vektorları hesablanır. İki qonşu cümlə arasındakı kosinus oxşarlığı müəyyən həddən (threshold) aşağı düşdükdə, bu mövzu dəyişikliyi sayılır və yeni parça başlanır.
* **2. Lokal Model Əsaslı (BERT / RoBERTa):**
  OpenAI API-a daimi pul ödəməmək üçün lokal kiçik neyron şəbəkə ilə mətndəki təbii məntiqi sərhədlər müəyyən edilir.
* **3. LLM Əsaslı (Prompt ilə Parçalama):**
  Mətn birbaşa böyük dil modelinə göndərilir və təbii dildə təlimatla məntiqi bloklara bölünür (ən dəqiq, lakin ən bahalı üsul).

<div class="box-analogy">
📈 <strong>Qrafik İzahı:</strong> Qonşu cümlələrin oxşarlığı yüksək olduğu müddətcə eyni parçada birləşdirilir; oxşarlıq kəskin düşdükdə kəsim icra olunur.
</div>

</div>
<div style="text-align:center;">

![Semantik Parçalama Mexanizmi](images/slide17_semantic_chunking_methods.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Semantik parçalama mətni simvol sayına görə deyil, məna fərqinə görə bölür. Məsələn, cümlələrin embedding-ləri hesablanır. Əgər bir cümlədən sonrakına keçəndə oxşarlıq dərəcəsi kəskin enirsə, deməli müəllif yeni mövzuya keçib və orada yeni chunk başlamalıdır.
</div>

---

<!-- Slayd 18: Propositional Chunking -->

# 📝 Təklif Əsaslı Parçalama (Propositional Chunking)
### Dense Retrieval Tədqiqatı: Mürəkkəb Cümlələrin Atomik Faktlara Parçalanması

<div class="box-idea">
🎯 <strong>Tədqiqat İşi:</strong> <em>"Dense Retrieval: What Retrieval Granularity Should We Use?"</em> (Chen et al. / LlamaIndex). Mürəkkəb mətnləri kontekstdən kənarda da anlaşılan təmiz, atomik təkliflərə (propositions) bölmək.
</div>

<div class="grid-2" style="grid-template-columns: 1fr 1.25fr; gap:20px;">
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #34d399;">

### 📋 LLM-ə Verilən 4 Qızıl Qayda:
1. **Sadə Təkliflərə Böl:** Mürəkkəb cümlələri sadə cümlələrə ayır, lakin ilkin ifadə tərzini mümkün qədər qoru.
2. **Adlandırılmış Varlıqlar (Entities):** Hər hansı varlığa aid əlavə təsviri məlumatı ayrıca müstəqil təklif kimi ayır.
3. **Dekontekstualizasiya (Decontextualize):** Əvəzlikləri (*"o", "onlar", "bu"*) aid olduqları şəxsin və ya varlığın tam adı ilə əvəz et ki, təkbaşına oxunduqda da tam aydın olsun!
4. **JSON Çıxışı:** Alınan bütün atomik fikirləri təmiz JSON sətirlər siyahısı kimi qaytar.

</div>
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #38bdf8;">

### 💬 Praktiki Prompt Şablonu:
```text
Decompose the 'Content' into clear and simple propositions:
1. Split compound sentence into simple sentences.
2. Separate descriptive info into its own proposition.
3. Decontextualize by replacing pronouns ('he', 'she', 'it') with full entity names.
4. Present results as a list of strings formatted in JSON.
```

<div class="box-analogy" style="margin-top:12px; font-size:0.88rem;">
💡 <strong>Niyə Bu Qədər Effektivdir?</strong> Çünki axtarış zamanı istifadəçinin sualı tam olaraq həmin atomik fakta uyğun gəlir və heç bir küy generasiyaya daxil olmur!
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Tədqiqatlar göstərir ki, ən yüksək axtarış keyfiyyəti mətni atomik "təkliflərə" (propositions) böldükdə əldə edilir. Xüsusilə əvəzliklərin (he, she, it) əsl adlarla əvəz edilməsi (decontextualization) çox vacibdir, çünki bazadan çıxarılan tək bir cümlənin kimə aid olduğunu bilmək lazımdır.
</div>

---

<!-- Slayd 19: Data Extraction (PDFs, Tables, Multimodal) -->

# 📊 Pre-Retrieval: Mürəkkəb Məlumatların Çıxarılması (Data Extraction)
### PDF Sənədlərindən Cədvəllərin, Qrafiklərin və Təsvirlərin İnkişaf Etmiş Ekstraksiyası

<div class="box-idea">
🎯 <strong>Əsas Sual:</strong> <em>"Gözdən nəyisə qaçırmışıqmı?" (Are we missing data?)</em> Korporativ sənədlər təkcə düz mətndən ibarət deyil; ən kritik məlumatlar məhz cədvəllərdə, qrafiklərdə və diaqramlarda yerləşir.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### 🛠️ Məlumat Çıxarış Alətləri Ekosistemi:
* **Strukturlu Mətn və Sadə PDF:** `PyPDF`, LangChain və LlamaIndex sənəd yükləyiciləri. Düz mətni və meta-məlumatları tez emal edir.
* **Qeyri-strukturlu və Cədvəlli PDF-lər:** `unstructured.partition.pdf.partition_pdf` — səhifədəki cədvəlləri, başlıqları və mətni avtomatik tanıyır və strukturlu Markdown/HTML formatına salır.
* **İxtisaslaşmış Cədvəl Alətləri:** `ChatDOC` — maliyyə hesabatlarındakı mürəkkəb xanaları və qrafikləri itkisiz çıxarır.
* **Multimodal LLM-lər (GPT-4 Vision):** Diaqram və şəkilləri birbaşa təsvir kimi qəbul edib, dəqiq faktları və rəqəmləri çıxarır.

<div class="box-warning" style="margin-top:12px; font-size:0.88rem;">
⚠️ <strong>Xəbərdarlıq:</strong> Şəkilləri və cədvəlləri Vision modelləri ilə emal etmək daha çox resurs tələb edir, lakin maliyyə və hüquq sənədlərində dəqiqliyi təmin etmək üçün əvəzolunmazdır.
</div>

</div>
<div style="text-align:center;">

![Pre-Retrieval Data Extraction](images/slide19_data_extraction_multimodal.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Real həyatda sənədlər sadəcə txt faylları deyil. PDF-lərin içində cədvəllər, qrafiklər və şəkillər var. Əgər sadəcə mətni çıxarsaq, ən vacib rəqəmləri itirəcəyik. Buna görə unstructured və ya multimodal LLM kimi alətlərlə cədvəlləri və qrafikləri də RAG bazasına əlavə etmək lazımdır.
</div>



---

<!-- Slayd 20: Pre-Retrieval: Query Rewriting -->

# ✏️ Query Rewriting: Pre-Retrieval Sorğu Optimizasiyası
### İstifadəçi Sualının Qüsurları və Semantik Axtarışın Uyğunsuzluğu Problemi

<div class="box-idea">
🎯 <strong>Əsas Problem:</strong> Pre-retrieval mərhələsində təkcə məlumatların necə saxlandığı deyil, <em>istifadəçinin daxil etdiyi sualın keyfiyyəti</em> də həlledicidir. İstifadəçilər çox vaxt qarışıq, çoxməqsədli və lazımsız sözlərlə dolu suallar verirlər ki, bu da vektor axtarışını çaşdırır.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### ⚠️ Vektor Axtarışının Tələsi:
Əgər bir sualda iki tamamilə fərqli semantik məna qarışıbsa, tək bir embedding vektoru hər iki mövzunun ortasında "boşluğa" düşür:

> *"Data, tell me about your daughter Lal. Also, isn't Star Wars cool?"*

### 🛠️ Query Rewriter Nə Edir?
* **Mövzuları Ayırır:** İki fərqli niyyəti (Lal vs Star Wars) müstəqil sorğulara bölür.
* **Distillə Edir (Sıxlaşdırır):** Sualı minimum zəruri semantik nüvəyə endirir (`"Lal information"` və ya sadəcə `"Lal"`).
* **Dəqiq Vektor Axtarışı:** Yalnız "Lal" mövzusu üçün təmiz embedding hesablanır və bazadan 100% uyğun sətirlər çıxarılır.

<div class="box-analogy" style="margin-top:10px; font-size:0.88rem;">
💡 <strong>Prinsip:</strong> İstifadəçinin dediyi xam cümlə ilə deyil, axtarış sisteminin ən yaxşı başa düşəcəyi <strong>təmizlənmiş forma</strong> ilə bazaya müraciət edirik!
</div>

</div>
<div style="text-align:center;">

![Query Rewriting İş Mexanizmi](images/slide20_query_rewriter_flow.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Pre-retrieval mərhələsində təkcə bazadakı sənədləri deyil, istifadəçidən gələn promptu da optimallaşdırmaq lazımdır. İstifadəçi iki fərqli şeyi eyni cümlədə soruşduqda (Star Trek Datanın qızı Lal və Star Wars filmi), vektor axtarışı iflas edir. Query Rewriter bu sualı təmizləyib 'Lal information' şəklinə salır və yalnız bundan sonra axtarışa ötürür.
</div>

---

<!-- Slayd 21: Sorğunun Distillasiyası və Doldurucu Sözlərin Təmizlənməsi -->

# 🎯 Sorğunun Distillasiyası və Doldurucu Sözlərin Təmizlənməsi
### Mürəkkəb Cümlələrdən Açar Semantik Nüvənin Çıxarılması

<div class="box-idea">
🎯 <strong>Məqsəd:</strong> İstifadəçi sualındakı danışıq küyünü (filler words, stopwords, nəzakət ifadələri) ataraq sorğunu ən təmiz məna konsentratına (distillə formaya) çevirmək.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #38bdf8;">

### 🧹 Doldurucu Sözlər və Leksik Küy:
İstifadəçilər çox vaxt belə yazırlar:

> *"Salam bot, görəsən mənə zəhmət olmasa kömək edə bilərsənmi, Data-nın qızı Lal haqqında bilmək istəyirdim..."*

* Bu ifadədə 15 söz var, lakin semantik yük daşıyan tək söz **"Lal"** və **"Data"**dır.
* Artıq sözlər vektorun istiqamətini dəyişir və əlaqəsiz sənədlərə tərəf çəkir.
* **Distillə Nəticəsi:** `"Lal information"` və ya `"Commander Data daughter Lal"`.

</div>
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #34d399;">

### 🔀 Çoxlu Niyyətlərin Ayrılması (Query Splitting):
Bir cümlədə bir neçə sual birləşdikdə:

* Model cümləni müstəqil alt-sorğulara bölür (Sub-queries).
* Hər bir alt-sorğu üçün ayrı-ayrı vektor axtarışı aparılır.
* Əldə edilən sənədlər birləşdirilərək LLM-ə ötürülür.

<div class="box-analogy" style="margin-top:14px; font-size:0.88rem;">
⚡ <strong>İqtisadi Balans:</strong> Sadə filtrasiya üçün kiçik qaydalar və ya regex kifayətdir; mürəkkəb semantik bölgülər üçün isə yüngül LLM çağırışı tətbiq olunur.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Sorğu distillasiyası ən çox yayılmış query rewriting formasıdır. İstifadəçinin uzun və nəzakətli cümlələrindən bütün doldurucu sözlər atılır, yalnız axtarış üçün vacib olan nüvə terminlər saxlanılır. Bu, həm axtarış dəqiqliyini artırır, həm də hesablama xərclərini azaldır.
</div>

---

<!-- Slayd 22: "Geri Adım" Sualları (Step-Back Questions) -->

# 🔙 "Geri Adım" Sualları (Step-Back Questions)
### Konkret Məsələdən Daha Geniş və Abstrakt Əsas Faktlara Keçid

<div class="box-idea">
🎯 <strong>Fəlsəfə:</strong> Çox spesifik və mürəkkəb müqayisə suallarını birbaşa axtarmaq əvəzinə, LLM-dən bir addım geri çəkilib daha geniş, abstrakt təməl suallar formalaşdırmasını istəyirik.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### 🧑‍🏫 Frank Kane Nümunəsi:
> *"Frank Kane dərs deməyə başlayanda RAG mövcud idimi?"*

Bu sual iki fərqli tarixi faktın kəsişməsidir:

1. **Step-Back Sual 1:** *"Frank Kane nə vaxt dərs deməyə başlayıb?"* (Məsələn, 2015)
2. **Step-Back Sual 2:** *"Retrieval-Augmented Generation (RAG) texnologiyası nə vaxt yaradılıb?"* (Məsələn, 2020)

* Hər iki sual üzrə müstəqil kontekst tapılır və LLM cavabları müqayisə edərək yekun nəticə çıxarır: *"Xeyr, mövcud deyildi"*.

<div class="box-analogy" style="margin-top:10px; font-size:0.88rem;">
💡 <strong>Üstünlüyü:</strong> Verilənlər bazasında Frank Kane ilə RAG-ı birbaşa müqayisə edən tək bir sənəd olmaya bilər, lakin hər iki fərdin faktı bazada mütləq var!
</div>

</div>
<div style="text-align:center;">

![Step-Back Prompting Sxemi](images/slide22_step_back_prompting.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Step-Back Prompting mürəkkəb sualları daha fundamental və abstrakt iki suala bölür. Məsələn, 'Frank Kane dərs deyəndə RAG var idi?' sualını birbaşa axtarsaq, bəlkə heç bir məqalə tapmarıq. Amma 'Frank Kane nə vaxt başlayıb' və 'RAG nə vaxt yaranıb' suallarını ayrı axtarıb faktları birləşdirsək, model 100% dəqiq nəticə çıxarır.
</div>

---

<!-- Slayd 23: HyDE (Hypothetical Document Embeddings) -->

# 🔮 Fərziyyəvi Sənəd Embeddingləri (HyDE)
### Sual Vektoru Əvəzinə Fərziyyəvi Cavab Vektoru ilə Axtarış

<div class="box-idea">
🎯 <strong>Asimmetriya Problemi:</strong> İstifadəçi sualı 5-10 sözlük qısa cümlədir, verilənlər bazasındakı sənəd isə 200 sözlük zəngin abzasdır. Sual vektoru ilə sənəd vektoru çoxölçülü məkanda fərqli topoqrafiyaya malikdir.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### ⚡ HyDE-ın Dahiyanə İcra Mərhələləri:
1. **Fərziyyəvi Mətn Yazdırılır:** LLM-dən xahiş edirik: *"Zəhmət olmasa, bu suala cavab verən bir abzaslıq sənəd tərtib et..."*
2. **Məzmunun Əhəmiyyəti Yoxdur:** Model faktiki hallüsinasiya etsə belə, mövzunun leksik və terminoloji tonunu mükəmməl tutur!
3. **Sənədin Vektoru Hesablanır:** Həmin fərziyyəvi abzasın embedding vektoru çıxarılır: `Embed(D_hyp)`.
4. **Simmetrik Axtarış:** Sənəd vektoru ilə bazadakı real sənədlər axtarılır. Nəticədə **sənəd-sənəd oxşarlığı** sual-sənəd oxşarlığından qat-qat güclü çıxır!

<div class="box-analogy" style="margin-top:12px; font-size:0.88rem;">
🛡️ <strong>Təhlükəsizlik:</strong> Fərziyyəvi sənəd heç vaxt istifadəçiyə göstərilmir; o yalnız bazadan 100% rəsmi və dəqiq sənədləri cəlb etmək üçün "maqnit" rolunu oynayır!
</div>

</div>
<div style="text-align:center;">

![HyDE Arxitekturası](images/slide23_hyde_architecture.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> HyDE (Hypothetical Document Embeddings) qısa sualla axtarış etmək əvəzinə, əvvəlcə LLM-ə fərziyyəvi bir cavab sənədi yazdırır və həmin sənədin vektoru ilə real bazanı axtarır. Çünki sənəd ilə sənəd arasındakı vektor yaxınlığı sual ilə sənəd arasındakından qat-qat yüksəkdir. LangChain və LlamaIndex-də tam dəstəklənir.
</div>

---

<!-- Slayd 24: Advanced Query Rewriting Ecosystem -->

# ⚡ Qabaqcıl Sorğu Yenidən Yazma Metodları
### Query2Doc, ITER-RETGEN və Rewrite-Retrieve-Read (RRR) Paradiqmaları

<div class="box-idea">
🎯 <strong>Xülasə:</strong> Sorğunun yenidən yazılması statik bir proses deyil; müasir sistemlər axtarış və generasiyanı çoxdövrlü iterativ zəncirlərlə birləşdirir.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #38bdf8;">

### 📚 Əsas Qabaqcıl Metodlar:
* **Query2Doc:** Sualı LLM tərəfindən generasiya edilmiş bir neçə sintetik cümlə ilə genişləndirərək axtarışa göndərmək.
* **Rewrite-Retrieve-Read (RRR):** Əvvəlcə sualı yenidən yaz ➔ bazadan sənəd çıxar ➔ oxu və qiymətləndir; əgər cavab natamamdırsa, dövrü yenidən başlat.
* **ITER-RETGEN:** İterativ Axtarış və Generasiya. Model hər generasiya addımında yeni ehtiyac duyulan faktları növbəti axtarış sorğusu kimi bazaya yönləndirir.

</div>
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #fbbf24;">

### ⚖️ İqtisadi və Praktiki Mühəndis Qaydaları:
* **Hər Şeyə LLM Qoşmayın:** Hər bir sorğunu yenidən yazmaq üçün GPT-4 çağırmaq həm gecikməni (latency), həm də API xərclərini ikiqat artırır.
* **Hibrid Strategiya:** Əvvəlcə sadə qaydalarla (stopword və regex) sorğunu təmizləyin; yalnız mürəkkəb və ya çoxhissəli suallarda Step-Back və ya HyDE kimi bahalı texnikalara keçin.
* **Keyfiyyət Artımı:** Doğru tətbiq olunduqda Query Rewriting axtarış dəqiqliyini 20–40% artırır!

<div class="box-warning" style="margin-top:10px; font-size:0.86rem;">
🚀 <strong>Növbəti Addım:</strong> Pre-retrieval mərhələsini tamamlayaraq, növbəti dərslərdə <strong>Retrieval (Axtarış)</strong> və <strong>Post-Retrieval (Reranking)</strong> mexanizmlərinə keçirik!
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Dərs 4-ü yekunlaşdırsaq: Query Rewriting pre-retrieval mərhələsinin ən güclü alətidir. Sadə təmizləmədən tutmuş Step-Back Prompting, HyDE, Query2Doc və iterativ dövrlərə (ITER-RETGEN) qədər müxtəlif üsullar var. Əsas mühəndislik prinsipi isə hər sorğu üçün bahalı LLM işlətməyib, ehtiyaca uyğun optimal metod seçməkdir.
</div>


---

<!-- Slayd 25: Post-Retrieval: Prompt Compression -->

# 📦 Post-Retrieval: Prompt Compression (Kontekstin Sıxlaşdırılması)
### Token Büdcəsinə Qənaət, Relevantlıq və "Lost in the Middle" Probleminin Həlli

<div class="box-idea">
🎯 <strong>Əsas Məqsəd:</strong> Vektor bazasından gələn xam kontekst çox vaxt küy və lazımsız detallarla dolu olur. Post-retrieval mərhələsində bu konteksti minimum zəruri həcmə qədər sıxlaşdıraraq həm xərcləri azaldır, həm də LLM-in ən vacib fakta fokuslanmasını təmin edirik.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### 🎯 Niyə Konteksti Sıxlaşdırmalıyıq?
* **Kontekst Pəncərəsi Limitləri:** Yüzlərlə səhifəlik sənədləri birbaşa LLM-ə yükləmək texniki və maliyyə baxımından səmərəsizdir.
* **Xərclərə Nəzarət (Token Qənaəti):** Kontekstdən küyü və təkrar sözləri silməklə token sayını 60–80% azaltmaq mümkündür.
* **Modelin Diqqət Dağınıqlığı:** "Lost in the Middle" effekti — LLM uzun kontekstin ortasındakı faktları tez-tez unudur və ya hallüsinasiya edir.

### ⚖️ Mühəndislik Balansı və Risk:
* **İqtisadi Tələ:** Əgər sıxlaşdırma üçün GPT-4 kimi bahalı LLM çağırsanız, qənaət etdiyinizdən daha çox pul xərcləyə bilərsiniz!
* **İnformasiya İtkisi (Over-compression):** Həddən artıq aqressiv sıxlaşdırma vacib faktları və şərtləri itirə bilər.

<div class="box-analogy" style="margin-top:10px; font-size:0.88rem;">
💡 <strong>Qayda:</strong> Sıxlaşdırma üçün böyük modellər deyil, yüngül kiçik dil modelləri (SLM) və ya embedding filtrləri ən ideal seçimdir!
</div>

</div>
<div style="text-align:center;">

![Prompt Compression Boru Kəməri](images/slide25_prompt_compression_flow.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Post-retrieval mərhələsində bazadan tapdığımız sənədləri birbaşa LLM-ə göndərmirik. Çünki bazadan çıxan hər sətir suala aid olmaya bilər. Prompt compression ilə küyü atıb token xərclərini 70%-ə qədər azaldırıq. Lakin diqqətli olmaq lazımdır: sıxlaşdırma üçün yenə bahalı GPT-4 işlətsək, əldən çıxan xərc qənaət ediləndən çox olar. Buna görə kiçik modellər (SLM) və ya embedding filtrləri daha sərfəlidir.
</div>

---

<!-- Slayd 26: LLMLingua & Perplexity Techniques -->

# 🔬 LLMLingua və Perplexity Əsaslı Sıxlaşdırma Texnikaları
### Sözlərin Məlumat Yükü, Perplexity Filtrləməsi və LLMLingua-2 Şərtləri

<div class="box-idea">
🎯 <strong>Məntiq:</strong> Hər bir söz eyni informasiya dəyərinə malik deyil. Əgər bir söz dildə asanlıqla təxmin ediləndirsə (aşağı perplexity), onu mətndən çıxarmaq cümlənin ümumi mənasını dəyişmir.
</div>

<div class="grid-2" style="grid-template-columns: 1.05fr 0.95fr; gap:20px;">
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #38bdf8;">

### 🛠️ Sıxlaşdırma Üsulları və Alətlər:
* **Kiçik Dil Modelləri (SLM) və Perplexity:** Lokal, kiçik bir model (məsələn, LLaMA-7B, GPT-2 və ya DistilBERT) ilə hər tokenin ehtimalı (perplexity) ölçülür. Dildə zəruri olmayan sözlər atılır.
* **Embedding Filtrləməsi:** Ən sürətli və hesablama xərci ən az metod. Kontekst cümlələrinin istifadəçi sualı ilə kosinus oxşarlığı yoxlanılır, aşağı ballı abzaslar dərhal silinir.
* **LLMLingua Paketi (Microsoft Research):** LangChain və LlamaIndex ilə dərhal inteqrasiya olunan, task-agnostic prompt sıxlaşdırma kitabxanası.

<div class="box-analogy" style="margin-top:14px; font-size:0.88rem;">
⚡ <strong>Nəticə:</strong> Mətn 3–4 dəfə qısalır, lakin GPT-4 həmin sıxlaşmış mətni oxuduqda ilkin sualı 95%+ dəqiqliklə bərpa edib cavablandırır!
</div>

</div>
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #fb923c;">

### 📜 LLMLingua-2 Təlimat Şərtləri:
Microsoft-un elmi məqaləsində istifadə olunan qızıl prompt şərtləri:

1. **Yalnız lazımsız sözləri sil:** Əsas informasiya qorunmalıdır.
2. **Sözlərin sırasını dəyişmə:** Orijinal ardıcıllıq qalsın.
3. **Orijinal sözləri dəyişmə:** Sinonimlərlə əvəz etmə və ya parafraz etmə.
4. **Abbreviatura və ya emoji işlətmə.**
5. **Yeni heç bir söz və ya simvol əlavə etmə!**

> *"Compress the origin aggressively by removing words only. Compress as short as you can while retaining information..."*

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> LLMLingua Microsoft-un hazırladığı və LangChain/LlamaIndex tərəfindən dəstəklənən çox güclü paketedir. O, perplexity əsasında işləyir — yəni cümlədə təxmin edilməsi çox asan olan doldurucu sözləri silir, faktoloji sözləri saxlayır. Slayddakı 5 şərt LLMLingua-2 məqaləsinin təməl promptudur və modelə sözləri dəyişmədən, heç bir saxta termin əlavə etmədən aqressiv sıxlaşdırma aparmağı əmr edir.
</div>

---

<!-- Slayd 27: Post-Retrieval Reranking -->

# 🥇 Post-Retrieval Reranking: Nəticələrin Yenidən Sıralanması
### Vektor Axtarışının Səthi Bənzərliyi və Cross-Encoder ilə Dərin Dərəcələndirmə

<div class="box-idea">
🎯 <strong>Əsas Məqsəd:</strong> Vektor bazası nə qədər güclü olsa da, ən doğru sənədi həmişə birinci yerə (Rank 1) gətirə bilmir. Reranker axtarışdan çıxan ilk 20–30 sənədi dərin semantik yoxlamadan keçirərək ən mükəmməl faktı zirvəyə qaldırır.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### ⚠️ Niyə Təkcə Vektor Axtarışı Bəs Etmir?
* **Bi-Encoder Məhdudiyyəti:** Vektor bazasında sual və sənədlər ayrı-ayrı vektorlaşdırılır. Tez və geniş miqyaslıdır, lakin sual sözləri ilə sənəd sözləri arasındakı dərin qarşılıqlı diqqəti (cross-attention) hesablaya bilmir.
* **"Missed Top Ranked" Riski:** Datanın Lal haqqında ən həlledici cümləsi 1-ci deyil, bəlkə 7-ci və ya 14-cü sırada qayıda bilər.

### 🏆 Cross-Encoder və Reranker Həlli:
* **Birgə Analiz:** Sual və sənəd cütü birgə tək bir transformer modelinə daxil edilir: `[CLS] Sual [SEP] Sənəd`.
  * `[CLS]` (Classification token) — Bütün cümlə cütünün ümumi mənasını və yekun uyğunluq balını (0.0–1.0) təmsil edən xüsusi başlanğıc tokeni.
  * `[SEP]` (Separator token) — İstifadəçi sualı ilə sənəd fraqmentini bir-birindən ayıran sərhəd tokeni.
* **Tam Diqqət (Full Attention):** Hər bir sual sözü sənəddəki hər bir sözlə birbaşa çarpaz əlaqələndirilir.
* **Məşhur Alətlər:** `bge-reranker-large`, `Cohere Rerank 3` və ya LLM reytinq promptu.

<div class="box-warning" style="margin-top:10px; font-size:0.86rem;">
🚀 <strong>İki Pilləli Strategiya:</strong> Milyonlarla sənədi Bi-Encoder ilə süzüb Top-25 seçirik ➔ Həmin 25-i Reranker ilə dərəcələndirib Top-3-ü LLM-ə ötürürük!
</div>

</div>
<div style="text-align:center;">

![Bi-Encoder və Cross-Encoder Reranking Sxemi](images/slide27_reranking_architecture.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Təcrübədə vektor axtarışından dərhal sonra ən yaxşı nəticənin 1-ci sırada gələcəyinə zəmanət yoxdur. Çünki vektor embeddingləri (Bi-encoder) sürətli olsa da səthidir. Buna görə bazadan 20 sənəd çəkirik, sonra Cross-Encoder və ya LLM ilə həmin 20 sənədi yenidən sıralayırıq (reranking). Ən yüksək bal toplayan ilk 3 sənədi modelə ötürürük. Bu, dəqiqliyi dramatik şəkildə artırır.
</div>

---

<!-- Slayd 28: Seven Failure Points -->

# ⚠️ RAG Mühəndisliyində 7 Uğursuzluq Nöqtəsi (Seven Failure Points)
### Barnett et al. Tədqiqatı: İndeksləmədən Generasiyaya Qədər Bütün Zəif Həlqələr

<div class="box-idea">
🎯 <strong>Elmi Xülasə:</strong> Barnett və komandasının <em>"Seven Failure Points When Engineering a RAG System"</em> araşdırmasına əsasən, RAG sistemlərinin uğursuzluğu yalnız modelin hallüsinasiyasından qaynaqlanmır; bütöv boru kəmərində 7 ayrı kritik xəta nöqtəsi mövcuddur.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #f87171;">

### 🚨 7 Xəta Nöqtəsinin Təsnifatı:
1. <strong style="color:#fca5a5;">Missing Content:</strong> Fakt bazada ümumiyyətlə yoxdur (məlumat çıxarılmayıb və ya unudulub).
2. <strong style="color:#fca5a5;">Missed Top Ranked:</strong> Sənəd bazadadır, lakin K-NN axtarışı onu ilk sıralara çıxarmayıb.
3. <strong style="color:#fca5a5;">Not in Context:</strong> Sənəd tapılıb, amma konsolidasiya və ya limit zamanı kənarda qalıb.
4. <strong style="color:#fca5a5;">Not Extracted:</strong> Fakt kontekstdə var idi, lakin Reader/LLM onu fərq edib cavaba daxil edə bilmədi.
5. <strong style="color:#fca5a5;">Wrong Format:</strong> Cavab istifadəçinin gözlədiyi formatda (JSON, cədvəl) verilmədi.
6. <strong style="color:#fca5a5;">Incorrect Specificity:</strong> Cavab həddən artıq ümumi və ya həddən artıq xırdalıqlıdır.
7. <strong style="color:#fca5a5;">Incomplete:</strong> Çoxhissəli sualın yalnız bir hissəsinə cavab verildi.

<div class="box-analogy" style="margin-top:10px; font-size:0.86rem;">
🔍 <strong>Diaqnostika:</strong> Əgər bot səhv cavab verirsə, dərhal promptu dəyişməyə tələsməyin! Xətanın bu 7 nöqtədən hansında baş verdiyini təyin edin.
</div>

</div>
<div style="text-align:center;">

![Seven Failure Points RAG Sxemi](images/slide28_seven_failure_points.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Bu slayd RAG mühəndisliyinin ən məşhur elmi məqalələrindən biri olan "Seven Failure Points" tədqiqatına əsaslanır. Bir çoxları elə bilir ki, RAG xəta edəndə günah yalnız LLM-dədir. Əslində isə xəta 7 fərqli yerdə baş verə bilər: bazada məlumatın olmaması, axtarışın onu tapmaması, konsolidasiyada itirilməsi və ya modelin oxuyarkən diqqətdən qaçırması. Hər nöqtə üçün ayrı sazlama strategiyası lazımdır.
</div>

---

<!-- Slayd 29: Simplicity Paradox & Dogfooding -->

# 🐕 Sadəlik Paradoksu və "Dogfooding": İstifadəçi Rəyi Ən Ali Metrikadır
### K-Parametr Balansı, Həddən Artıq Mürəkkəblik Tələsi və Praktiki Yoxlanış

<div class="box-idea">
🎯 <strong>Qızıl Qayda:</strong> <em>"Daha mürəkkəb sistem həmişə daha yaxşı sistem demək deyil."</em> Əgər sadə bir RAG arxitekturası biznes tələblərinizi ödəyirsə, ona əlavə mürəkkəb modullar qoşmayın — hər yeni modul yeni potensial xəta nöqtəsidir.
</div>

<div class="grid-2" style="grid-template-columns: 1fr 1fr; gap:20px;">
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #38bdf8;">

### ⚙️ RAG Tənzimləməsində Kritik Parametrlər:
* **K Parametri (K-NN):** Bazadan neçə sənəd gətirilsin? K çox böyük olsa ➔ küy və xərc artır; K çox kiçik olsa ➔ doğru fakt kənarda qalır.
* **Augmentation Prompt Engineering:** Kontekst ilə sualı birləşdirən yekun sistem təlimatının sözləri generasiya keyfiyyətinə həlledici təsir göstərir.
* **Mürəkkəblik vs Stabillik:** Hər dövrə LLM, HyDE, Reranker qoşmaq həm sistemin gecikməsini (latency), həm də nasazlıq riskini eksponensial artırır.

<div class="box-analogy" style="margin-top:12px; font-size:0.86rem;">
💡 <strong>Prinsip:</strong> Ən yaxşı mühəndislik sadə başlayan və yalnız ölçülə bilən ehtiyac olduqda mürəkkəbləşən sistemdir!
</div>

</div>
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #34d399;">

### 🐶 "Dogfooding" və Ən Ali Metrika:
* **"Eating Your Own Dog Food" (Dogfooding):** Sistemi özünüz gündəlik rejimdə sınaqdan keçirin; subyektiv hissiyat riyazi metrikalar qədər vacibdir.
* **Metrikaların Zəifliyi:** Precision, recall və ya RAG triad skoru bəzən yanlış hədəfi ölçə bilər.
* **Ən Ali Qiymətləndirmə:** Son istifadəçinin sistemdən razı qalması! İstifadəçi dəqiq, aydın və köməkçi cavab alırsa, RAG uğurludur.

<div class="box-warning" style="margin-top:12px; font-size:0.86rem;">
🚀 <strong>Praktikaya Keçid:</strong> Növbəti addım — Komandir Data personajını qabaqcıl metodlarla (semantic chunking, compression, rewriting) praktik kod üzərində qururuq!
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Dərs 5-in ən vacib fəlsəfəsi sadəlikdir: ehtiyac yoxdursa RAG-a həddindən artıq mürəkkəblik qatmaq sistemi kövrək edir. İkincisi, K parametrinin seçimi kritikdir. Və nəhayət, "dogfooding" — sistemi mütləq özünüz dəfələrlə yoxlayın. Çünki heç bir riyazi RAG triadası və ya Ragas skoru real istifadəçinin məmnuniyyətini və təcrübəsini əvəz edə bilməz.
</div>


---

<!-- Slayd 30: LLM Agents Intro & Nvidia Architecture -->

# 🤖 LLM Agentləri: "Qapalı Qabıqdan" Xarici Dünyaya Çıxış
### Statik Modeldən Dinamik Qərarvericiyə: Alətlər və İntellektual Avtonomiya

<div class="box-idea">
🎯 <strong>Konsept:</strong> Standart LLM yalnız daxilində öyrəndiyi statik çəkilərlə məhdudlaşır — canlı xəbərləri bilmir, dəqiq riyaziyyat hesablayanda səhv edir və əməliyyat apara bilmir. LLM Agent isə xarici alətlərlə təchiz olunmuş, müstəqil qərar verən və alətləri hədəfə görə dinamik seçən avtonom sistemdir.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### 🌟 Agent Nədir və Necə Fərqlənir?
* **Qapalı Qabıqdan Azadlıq:** LLM artıq yalnız passiv mətn generasiya etmir; xarici proqramları icra edir, verilənlər bazalarını sorğulayır və nəticələri təhlil edir.
* **RAG da Bir Agent Alətidir:** RAG əslində agent üçün "axtarış aləti" (retriever tool) və "uzunmüddətli yaddaş"dır!
* **Nvidia Konseptual Arxitekturası (4 Əsas Komponent):**
  1. `Agent Core:` LLM-in özü (mühakimə və qərarvermə mərkəzi)
  2. `Memory:` Qısamüddətli (chat tarixçəsi) və uzunmüddətli (RAG / DB)
  3. `Planning Module:` Məsələni addımlara bölmək və **ReAct** (*Reason + Act* — Mühakimə yürüt və Fəaliyyət göstər: əvvəl daxilən düşünmək, sonra aləti çağırmaq paradiqması)
  4. `Tools Core:` Xarici alətlər, API-lər və kod icraçıları

<div class="box-analogy" style="margin-top:10px; font-size:0.88rem;">
💡 <strong>Prinsip:</strong> Agentə seçim sərbəstliyi verilir: o, suala cavab vermək üçün hansı alətin nə vaxt lazım olduğunu müstəqil təyin edir!
</div>

</div>
<div style="text-align:center;">

![Nvidia Konseptual LLM Agent Arxitekturası](images/slide30_agent_core_nvidia.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Agentlər haqqında danışarkən əslində yeni bir şey kəşf etmirik — kursun əvvəlində OpenAI API-nin Tools və Functions imkanlarından bəhs etmişdik. Agent məhz bu alətlər üzərində qurulur. LLM öz "qapalı qabığından" çıxır və ona verilən alətlər arasından ən uyğun olanını seçir. Nvidia-nın arxitekturasında gördüyümüz kimi, RAG sistemi agentin uzunmüddətli yaddaşını təşkil edir.
</div>

---

<!-- Slayd 31: Memory & Planning -->

# 🧠 Agent Yaddaşı və Planlaşdırma Modulu (Memory & Planning)
### Qısa vs Uzunmüddətli Yaddaş, ReAct Metodologiyası və Alt-Suallara Bölmə

<div class="box-idea">
🎯 <strong>Fəlsəfə:</strong> İnsan kimi, intellektual agent də mürəkkəb bir məqsədə çatmaq üçün nə etdiyini xatırlamalı (Memory) və addım-addım hərəkət planı qurmalıdır (Planning).
</div>

<div class="grid-2" style="grid-template-columns: 1fr 1fr; gap:20px;">
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #a78bfa;">

### 💾 Yaddaş Növləri (Memory Core):
* **Qısamüddətli Yaddaş (Short-term):** Cari söhbət sessiyasının kontekst pəncərəsi (Chat History). İstifadəçinin əvvəlki cümlələri daxildə saxlanılır.
* **Uzunmüddətli Yaddaş (Long-term / RAG):** Vektor verilənlər bazası. Məsələn, Komandir Datanın bütün illər ərzində dediyi hər kəlmə burada saxlanılır və lazım olanda axtarılır.
* **Sensor / Mühit Yaddaşı:** Agentin alətlərdən aldığı aralıq nəticələrin keşlənməsi və yadda saxlanması.

<div class="box-analogy" style="margin-top:14px; font-size:0.88rem;">
💡 <strong>RAG Əlaqəsi:</strong> Vektor bazaları agent üçün sonsuz həcmli xarici yaddaş diskidir!
</div>

</div>
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #fbbf24;">

### 📋 Planlaşdırma və ReAct (Planning):
* **Tapşırığın Dekompozisiyası:** Mürəkkəb sualı təkbaşına həll etmək əvəzinə, model onu addım-addım icra oluna bilən alt-suallara bölür.
* **ReAct (Reason + Act) Paradigması:**
  1. *Thought (Mühakimə):* "Mənə hansı məlumat çatmır?"
  2. *Action (Alət Çağırışı):* "Kalkulyatoru işə salıram."
  3. *Observation (Müşahidə):* "Nəticə 4,410 oldu."
* **Self-Reflection (Özünü Tənqid):** Alət səhv qaytardıqda planı dəyişir və başqa aləti sınaqdan keçirir.

<div class="box-warning" style="margin-top:10px; font-size:0.86rem;">
⚡ <strong>System Prompt:</strong> Planlaşdırma davranışı xüsusi sistem təlimatları ilə idarə olunur.
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Agentin yaddaşı iki yerə bölünür: qısamüddətli (chat tarixçəsi) və uzunmüddətli (Vektor DB / RAG). Planlaşdırma modulu isə sistem promptu və ReAct yanaşması ilə idarə olunur. Məsələn, "ReAct" çərçivəsində model hər addımda: "Mən indi nəyi bilmirəm? Bunu bilmək üçün hansı alət lazımdır? Alətin cavabı nə oldu?" deyə düşünərək irəliləyir.
</div>

---

<!-- Slayd 32: Practical Agent Architecture & Tools -->

# 🛠️ Praktiki Agent Arxitekturası: OpenAI Tools & Funksiyalar
### JSON Schema Təsvirləri, Dinamik Funksiya Seçimi və Xarici Mühit

<div class="box-idea">
🎯 <strong>Mühəndislik Realizmi:</strong> Nəzəriyyədə Nvidia-nın çəkdiyi sxem mürəkkəb görünsə də, praktikada bütün bunlar OpenAI Tools API və ya LangChain agentləri ilə sadə funksiya çağırışları (Function Calling) vasitəsilə həyata keçirilir.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### ⚙️ Alət Necə Təyin Edilir və İdarə Olunur?
* **Alət Təsviri (Tool Description):** Hər funksiyaya qısa təsvir verilir: `"Riyazi məsələlər üçün kalkulyatordan istifadə et"`. Model semantik olaraq bu təsvirə əsasən qərar verir.
* **Strukturlu Çağırış:** LLM kodu özü icra etmir; icra etmək üçün JSON arqumentlərini (məsələn, `{"expr": "245 * 18"}`) qaytarır.
* **Alətlərin İmkanları Limitsizdir:**
  * Canlı İnternet Axtarışı (Google / Bing)
  * Python Kod İcraçısı (Hesablamalar və qrafiklər)
  * Vektor və SQL Verilənlər Bazaları (RAG)
  * Kənar API-lər (Hava, email, CRM və s.)

<div class="box-analogy" style="margin-top:10px; font-size:0.88rem;">
🌐 <strong>Nəticə:</strong> LLM artıq təkcə keçmiş təlim məlumatlarına deyil, cari saniyədə baş verən real dünya məlumatlarına çıxış əldə edir!
</div>

</div>
<div style="text-align:center;">

![Praktiki Agent Arxitekturası](images/slide32_practical_agent_tools.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Praktikada agent dediyimiz şey Tools API-dir. Siz Python-da sadə bir kalkulyator və ya axtarış funksiyası yazırsınız, onun təsvirini OpenAI-a göndərirsiniz. İstifadəçi sual verəndə model təsviri oxuyur və "mən bu funksiyanı çağırmalıyam" deyərək JSON formatında arqumentləri qaytarır. Kod icra olunur və nəticə yenidən modelə ötürülür.
</div>

---

<!-- Slayd 33: Swarms of Agents / Multi-Agent Systems -->

# 🐝 Agent Sürüləri (Swarms of Agents / Multi-Agent Systems)
### İxtisaslaşmış Agentlərin Əməkdaşlığı: Virtual Proqram Təminatı Şirkəti

<div class="box-idea">
🎯 <strong>Təkamül:</strong> Tək bir agent nə qədər güclü olsa da, bütün fəaliyyət sahələrində eyni anda mükəmməl ola bilməz. Çoxagentli sistemlərdə (Multi-Agent Swarms) müxtəlif peşə rollarını (CEO, Designer, Coder, Tester) təmsil edən agentlər insan komandası kimi birlikdə çalışır.
</div>

<div class="grid-2">
<div style="background:#0f172a; padding:16px; border-radius:10px; border:1px solid #334155;">

### 👥 Rolların İxtisaslaşması (Virtual Komanda):
* **CEO Agent (Baş İcraçı):** İstifadəçi tələbini qəbul edir, strategiyanı və vizyonu formalaşdırır.
* **CTO & CPO Agentləri:** Texnoloji arxitekturanı və məhsul spesifikasiyalarını müəyyənləşdirir.
* **Game Design & Art Agentləri:** Mexanika, səviyyələr və vizual təsvirləri (DALL-E) yaradır.
* **Coding Agent:** Təmiz proqram kodu (Python, JS) yazır.
* **Testing / QA Agent:** Kodu icra edir, xəta tapdıqda Coder-ə geri qaytarır!
* **Documentation Agent:** Texniki sənədləşmə və README tərtib edir.

<div class="box-warning" style="margin-top:10px; font-size:0.86rem;">
🔄 <strong>Avtonom Dialoq:</strong> Agentlər insan müdaxiləsi olmadan bir-biri ilə müzakirə edir, kodu təftiş edir və nəticəni təsdiqləyir!
</div>

</div>
<div style="text-align:center;">

![Çoxagentli Əməkdaşlıq İyerarxiyası](images/slide33_swarm_agents_hierarchy.svg)

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> "Swarms of Agents" ideyası ilk dəfə Çində məşhur "ChatDev" elmi araşdırması ilə praktik olaraq nümayiş etdirildi. Bir neçə agent birləşərək bütöv bir video oyunu və ya proqram təminatını insan müdaxiləsi olmadan hazırlayır: biri kod yazır, digəri test edir, xəta çıxanda geri qaytarır, rəhbər agent isə bütün prosesə nəzarət edir.
</div>

---

<!-- Slayd 34: Devin AI, ChatDev & RAG Module Wrap-Up -->

# 🚀 Devin AI, ChatDev və RAG Modulunun Böyük Yekunu
### Multi-Agent Ekosistemi, RAG-ın Gələcəyi və Praktiki Laboratoriyaya Keçid

<div class="box-idea">
🎯 <strong>Nəticə:</strong> RAG statik sorğu-cavab sistemindən avtonom çoxagentli ekosistemlərin təməl uzunmüddətli yaddaşına çevrildi. Gələcəyin süni intellekti təkcə oxumur, həm də alətlərdən istifadə edərək real işləri görür!
</div>

<div class="grid-2" style="grid-template-columns: 1fr 1fr; gap:20px;">
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #38bdf8;">

### 🌐 Çoxagentli Platformalar:
* **ChatDev:** Çində tədqiqatçılar tərəfindən yaradılmış ilk virtual proqram təminatı şirkəti simulyatoru.
* **Devin AI & OpenDevin:** Müstəqil şəkildə tapşırığı oxuyan, repozitorini klonlayan, kod yazan və test edən avtonom proqramçılar.
* **CrewAI & AutoGen:** Korporativ mühitdə çoxagentli komandaları idarə edən ən populyar açıq mənbəli kitabxanalar.

<div class="box-analogy" style="margin-top:12px; font-size:0.86rem;">
💡 <strong>RAG + Agent Simbiozu:</strong> Hər bir mütəxəssis agent öz sahəsi üzrə ixtisaslaşmış RAG bazasından qidalanır.
</div>

</div>
<div style="background:#0f172a; padding:18px; border-radius:10px; border:1px solid #34d399;">

### 🎓 RAG Modulu Üzrə Böyük Xülasə:
* **Dərs 1–2:** Naive RAG boru kəməri və RAG Triadası metrikaları (Relevance, Groundedness).
* **Dərs 3–4:** Pre-Retrieval (Semantic Chunking, Data Extraction və Step-Back/HyDE sorğu təmizlənməsi).
* **Dərs 5:** Post-Retrieval (Prompt Compression, LLMLingua, Reranking və 7 Failure Points).
* **Dərs 6:** LLM Agentləri və Çoxagentli Sürülər (Swarms).

<div class="box-warning" style="margin-top:12px; font-size:0.86rem;">
🚀 <strong>Praktiki Laboratoriya:</strong> Komandir Data personajına riyazi kalkulyator və canlı internet axtarışı qoşaraq tam agent qururuq!
</div>

</div>
</div>

<div class="speaker-notes">
📌 <strong>Qeyd:</strong> Bununla RAG modulunun nəzəri hissəsini tam yekunlaşdırırıq! Biz Naive RAG-dan başladıq, RAG Triadası ilə ölçdük, Pre-retrieval (chunking, rewriting) və Post-retrieval (compression, reranking) texnikalarını öyrəndik, və nəhayət LLM Agentləri ilə RAG-ı birləşdirdik. Növbəti addım kod laboratoriyasıdır: Komandir Data personajını real alətlərlə zənginləşdirəcəyik.
</div>
