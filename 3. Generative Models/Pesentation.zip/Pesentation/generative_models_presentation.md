# Generativ Dərin Öyrənmə: VAE və GAN
## Sadə, Əyani və Ətraflı 2 Hissəli Master Dərs və Təqdimat Vəsaiti

> **Mövzu:** Generativ Dərin Öyrənmə (Generative Deep Learning)  
> **Struktur:** 2 Müstəqil Ardıcıl Dərs + 1 Yekun Birgə Təhlil Bölməsi (Cəmi 25 Slayd)  
> - **Dərs 1 (Slaydlar 1 – 11):** Avtoenkoderlər (AE) və Variational Autoencoders (VAE)  
> - **Dərs 2 (Slaydlar 12 – 21):** Generative Adversarial Networks (GAN)  
> - **Yekun Hissə (Slaydlar 22 – 25):** VAE vs GAN: Birgə Müqayisə, Təhlil və Generativ AI-ın Gələcəyi  
> **İnteraktiv Veb Slaydlar:** [generative_models_slides.html](file:///c:/Users/tarlan.cabiyev/Desktop/AI/DeepLearning/Pesentation/generative_models_slides.html)

---

## 📋 Tam Mündəricat Xəritəsi (25 Slayd)

### 📘 Hissə 1: DƏRS 1 — Avtoenkoderlər və Variational Autoencoders (VAE)
1. **Slayd 1:** Dərs 1 Qapaq: Avtoenkoderlər və VAE (Giriş və Hədəflər)
2. **Slayd 2:** Generativ və Diskriminativ Modellərin Fərqi (P(Y|X) vs P(X))
3. **Slayd 3:** Klassik Avtoenkoderlərin (AE) Fundamental Arxitekturası (X ≈ X')
4. **Slayd 4:** Ayaqqabı Nümunəsi və Latent Vektorun (z) Mahiyyəti (Sandal, Krossovka, Bot)
5. **Slayd 5:** "Enkoderi Zibil Qutusuna Atırıq!" Fəlsəfəsi (Dekoderlə Yeni Şəkil Hasilatı)
6. **Slayd 6:** Avtoenkoderlərin 4 Əsas Praktiki Tətbiqi (Sıxılma, Denoising, Rəngləmə, Vektor Oxşarlığı ilə Axtarış)
7. **Slayd 7:** Dekoderin Arxitekturası: Transposed Convolution və Stride = 2 Mexanizmi
8. **Slayd 8:** Klassik Avtoenkoderin Böyük Qüsuru: Boşluqlar Problemi (Gaps / Holes)
9. **Slayd 9:** Variational Autoencoder (VAE) İnqilabı: Ehtimal Paylanması (Gaussian Distribution, μ və σ)
10. **Slayd 10:** Dahiyanə Kəşf: Reparameterization Trick (z = μ + σ ⊙ ε)
11. **Slayd 11:** VAE İtki Funksiyası və "Torpaqdaşıma" Məsafəsi (Reconstruction + KL Divergence)

### ⚔️ Hissə 2: DƏRS 2 — Generative Adversarial Networks (GAN)
12. **Slayd 12:** Dərs 2 Qapaq: Generative Adversarial Networks (GAN - Ian Goodfellow, 2014)
13. **Slayd 13:** Viral Tətbiqlər, DeepFake və "This Person Does Not Exist" Fenomeni
14. **Slayd 14:** Tədqiqatçıların Əsl Nəcib Niyyətləri: Tibbi Məxfilik (HIPAA), Anomaliya və Musiqi
15. **Slayd 15:** GAN Memarlığı: Təsadüfi Səs-küydən Reallığa (G və D)
16. **Slayd 16:** Saxtakar Pul Basan və Mərkəzi Bankın Detektivi Analogiyası
17. **Slayd 17:** GAN-ın Riyazi Məntiqi: Minimax Oyunu (min G max D V(D, G))
18. **Slayd 18:** GAN Təliminin Dinamikası və Neş Tarazlığı (Nash Equilibrium, D = 0.5)
19. **Slayd 19:** GAN Təlimində Praktiki Çətinliklər və Xəbərdarlıqlar (Fragility & Trial-and-Error)
20. **Slayd 20:** Tələ 1: Rejim Çöküşü (Mode Collapse) — Yalnız Sandal İstehsalı
21. **Slayd 21:** Tələ 2: İtən Qradientlər (Vanishing Gradient) və Sabitləşdirmə Metodları

### ⚖️ Hissə 3: YEKUN DƏRS — VAE və GAN: Birgə Müqayisə və Gələcək
22. **Slayd 22:** Yekun Hissə Qapaq: İki Nəhəng Paradigmanın Qarşılaşdırılması
23. **Slayd 23:** VAE vs GAN: Dərindən Müqayisəli Cədvəl və Səbəblər (Dumanlılıq vs İtilik)
24. **Slayd 24:** Hansını və Nə Vaxt Seçməli? (Mühəndislik Qərar Ağacı)
25. **Slayd 25:** Generativ AI-ın Təkamülü: Diffusion Modelləri (Stable Diffusion, Midjourney, DALL-E)

---

# 📘 DƏRS 1: Avtoenkoderlər və Variational Autoencoders (VAE)

---

## SLAYD 1: Dərs 1 Qapaq: Avtoenkoderlər və VAE
### Məzmun və Giriş:
- **Başlıq:** Dərs 1: Avtoenkoderlər və Variational Autoencoders (VAE)
- **Alt Başlıq:** Təsvirlərin Sıxılması, Gizli Fəza (Latent Space) və Ehtimal Əsaslı Məzmun Yaradılması
- **Dərsin Əsas Məqsədləri:**
  1. Generativ modellərin məntiqi və təsnifat modellərindən köklü fərqi.
  2. Klassik Avtoenkoderlərin sıxılma və bərpa qanunları.
  3. Dekoderin "tərsinə işləyən CNN" mexanizmi və Stride = 2 rolu.
  4. Niyə klassik avtoenkoder yeni şəkil yarada bilmir (boşluqlar problemi)?
  5. VAE-nin ehtimal paylanması (*Gaussian Normal Distribution*), Reparameterization Trick, *Smooth Morphing (Interpolation)* və KL Divergence ilə bu problemi necə həll etməsi.

### 💡 Dərsin Əsas Qeydi:
> Generativ Modellər dərin öyrənmənin ən yaradıcı sahəsidir. İndiyə qədər gördüyümüz modellər verilənləri təsnif edirdi ("bu nədir?"). İndi isə şəbəkə dünyada heç vaxt mövcud olmamış yeni nümunələr yaradacaq. VAE-ni öyrənmədən GAN-ları anlamaq mümkün deyil!

---

## SLAYD 2: Generativ və Diskriminativ Modellərin Fərqi
### 🖼️ Sxem:
![Discriminative vs Generative](images/gen01_generative_vs_discriminative.svg)

### 📌 Ətraflı İzah:
- **Diskriminativ Modellər: P(Y | X)**
  - **Giriş:** Şəkil (X). **Çıxış:** Həmin şəklin sinfi (Y) — məsələn: "Ayaqqabı" (98%).
  - Model sadəcə çoxölçülü fəzada siniflər arasına ayıran bir **qərar sərhədi (decision boundary)** çəkir.
  - *Analoq:* Çoxvariantlı test imtahanında hazır variantlardan birini seçmək.
- **Generativ Modellər: P(X)**
  - **Giriş:** Təsadüfi kod (z). **Çıxış:** Dünyada heç vaxt mövcud olmamış bütöv bir görüntü (X).
  - Niyə çətindir? Çünki 28x28 = 784 pikselin (və ya 1 milyon pikselin) hər birinin bir-biri ilə olan həndəsi, rəng və tekstura əlaqəsini bilməlidir. Tək bir yanlış piksel görüntünü süni göstərə bilər.
  - *Analoq:* Ağ vərəqdə sıfırdan bütöv bir inşa yazmaq.

---

## SLAYD 3: Klassik Avtoenkoderlərin (AE) Fundamental Arxitekturası
### 🖼️ Sxem:
![Autoencoder Architecture](images/gen02_autoencoder_architecture.svg)

### 📌 Memarlıq Pillələri:
1. **Giriş (X):** Orijinal yüksək ölçülü verilən (məsələn, 28x28 piksel = 784 ölçü).
2. **Enkoder:** Konvolyusiya və pooling vasitəsilə şəklin ölçüsünü addım-addım azaldaraq onu boğaza doğru sıxır.
3. **Gizli Vektor (z - Latent Bottleneck):** Cəmi bir neçə rəqəmdən (məsələn, 16 ölçülü vektor) ibarət yığcam kod.
4. **Dekoder:** Həmin kiçik koddan istifadə edərək şəkli piksel-piksel yenidən bərpa edir (X').
5. **Nəzarətsiz Öyrənmə:** Heç bir insan etiketinə ehtiyac yoxdur.
   - **Bərpa İtkisi:** Loss = || X − X' ||² (MSE və ya Binary Cross-Entropy). Məqsəd X ≈ X' bərabərliyinə nail olmaqdır.

---

## SLAYD 4: Ayaqqabı Nümunəsi və Latent Vektorun (z) Mahiyyəti
### 📌 Mühazirədəki Canlı Misal:
- Tutaq ki, avtoenkoderi minlərlə ayaqqabı şəkli üzərində öyrədirik.
- **Sandal:** Dabanı yoxdur, üstü açıq qayışlıdır.
- **Krossovka:** Qalın rezin altlığı, bağcıqları və idman kəsimi var.
- **Çəkmə:** Dik dabanı və hündür boğazı var.
- **Dərin Fəlsəfə:** Neyron şəbəkə "sandal", "krossovka" sözlərini bilmir. Amma o, latent vektorun (z) oxlarında ayaqqabının daban hündürlüyünü, rəngini, burnunun formasını kəsilməz rəqəmlər şəklində kodlaşdırmağı öyrənir. Bu, sadə etiketləmədən qat-qat elastik və zəngin informasiyadır!

---

## SLAYD 5: "Enkoderi Zibil Qutusuna Atırıq!" Fəlsəfəsi
### 📌 Generativ Süni İntellektin Ən Böyük Sırrı:
- **Enkoderin Əsl Rolu:** Enkoder sadəcə Dekoderi təlim etmək üçün istifadə olunan köməkçi vasitə idi!
- **Təlimdən Sonra:** Enkoderi zibil qutusuna atırıq! Çünki bizə yalnız **Dekoder** lazımdır.
- **Yeni Məzmun Hasilatı:** İndi biz Dekoderə istədiyimiz və ya təsadüfi bir z gizli vektoru veririk. Dekoder həmin rəqəmləri emal edərək bazada heç vaxt mövcud olmamış yeni, sintetik ayaqqabı təsvirləri hasil edir!
- Bu prinsip bütün müasir vizual generasiya texnologiyalarının təməlidir.

---

## SLAYD 6: Avtoenkoderlərin 4 Əsas Praktiki Tətbiqi
### 🖼️ Sxem:
![Autoencoder Applications](images/gen03_autoencoder_applications.svg)

1. **Məlumatın Sıxılması (Compression / Dimensionality Reduction):** Yüksək ölçülü şəkilləri keyfiyyəti itirmədən cəmi bir neçə baytlıq latent vektora çevirmək.
2. **Küyün Təmizlənməsi (Denoising):** Girişə süni küy əlavə olunmuş şəkil verilir, çıxışda təmiz görüntü tələb olunur (Photoshop-un küy filtrləri).
3. **Şəkil Rənglənməsi (Colorization):** Ağ-qara şəkildən obyektin cins şalvar olduğunu anlayıb formasına görə onu mavi rənglə boyamaq (1 kanaldan 3 kanallı RGB-yə keçid).
4. **Məzmun Axtarışı: Vektor Oxşarlığı (Cosine Similarity):**
   - **Sadə İzah:** Şəkillər və ya mətnlər latent vektorlara çevrilir. Əgər iki sənəd oxşar mövzulardadırsa, onların gizli vektorları fəzada eyni istiqamətə yönəlir (aralarındakı bucaq sıfra, kosinus oxşarlığı isə 1-ə yaxınlaşır). Açar sözlər olmadan məna oxşarlığı tapılır!

---

## SLAYD 7: Dekoderin Arxitekturası: Transposed Convolution və Stride = 2
### 📌 "Tərsinə İşləyən CNN" Mexanizmi:
- **Enkoder (Standart CNN):** `Conv2D` və `MaxPooling2D` ölçünü addım-addım kiçildir (28x28 ➔ 14x14 ➔ 7x7 ➔ z).
- **Dekoder (Transposed CNN):** `Conv2DTranspose` və `UpSampling2D` ölçünü addım-addım böyüdür (z ➔ 7x7 ➔ 14x14 ➔ 28x28).
- **Stride = 2 Mexanizminin Sadə İzahı:**
  - *Stride (Addım):* Filtrin hərəkət addımının ölçüsüdür.
  - *Adi Conv2D-də:* Stride = 2 olduqda filtr 2 piksel atlayır və şəkil **2 dəfə kiçilir** (28x28 ➔ 14x14).
  - *Transposed Conv-da:* Stride = 2 tərsinə işləyir — piksellərin arasına yeni yerlər açaraq təsviri hər tərəfə **2 dəfə böyüdür (UpSampling)**: 7x7 ➔ 14x14 ➔ 28x28!
  - *Ən Mühüm Fərq:* Bu, sadəcə pikselləri kopyalamaq (zoom) deyil! Şəbəkə yeni piksellərin rəngini təlim prosesində öyrəndiyi çəkilər (weights) vasitəsilə sıfırdan "çəkir".

---

## SLAYD 8: Klassik Avtoenkoderin Böyük Qüsuru: Boşluqlar Problemi
### 🖼️ Sxem:
![AE vs VAE Latent Space](images/gen04_vae_probabilistic_latent.svg) *(Sol Tərəf)*

### ⚠️ Niyə Klassik AE Yeni Şəkil Çəkə Bilmir?
- Standart Avtoenkoder hər şəkli gizli fəzada **tək bir deterministik nöqtəyə** çevirir.
- Sandal nöqtələri bir küncdə, krossovkalar başqa küncdə toplanır.
- Bu iki ada arasındakı nəhəng məkanda **heç bir təlim getməyib (boşluqdur / gaps)!**
- Əgər siz həmin boşluqdan təsadüfi nöqtə seçib dekoderə versəniz:
  $$	ext{Dekoder}(	ext{təsadüfi nöqtə}) \implies 	ext{Mənasız dumanlı ləkələr və zibil (Garbage)!}$$
- **Nəticə:** Standart AE verilənləri sıxır və bərpa edir, lakin yeni, keyfiyyətli şəkil hasil edə bilmir. Bizə kəsilməz fəza lazımdır!

---

## SLAYD 9: Variational Autoencoder (VAE) İnqilabı: Ehtimal Paylanması
### 🖼️ Sxem:
![AE vs VAE Latent Space](images/gen04_vae_probabilistic_latent.svg) *(Sağ Tərəf)*

### 🧬 Deterministik Nöqtədən Ehtimal Paylanmasına Keçid:
- VAE-də enkoder şəkli tək bir z nöqtəsinə çevirmir! O iki statistik parametr çıxarır:
  1. **μ (Mean / Orta Qiymət):** Obyektin fəzadakı mərkəz koordinatları.
  2. **σ (Variance / Dispersiya):** Obyektin qeyri-müəyyənlik buludunun radiusu.
- Giriş şəkli bir *Gaussian Normal Distribution* kimi kodlaşdırılır: q(z | X) = N(μ, σ²).
- **Smooth Morphing (Interpolation):** Artıq hər ayaqqabı bir nöqtə deyil, kəsilməz bir ehtimal dumanıdır. Fəzada heç bir boşluq qalmır!
  $$	ext{Sandal } (\mu_1) \longrightarrow 	ext{Hibrid Ayaqqabı } (	ext{Orta}) \longrightarrow 	ext{Krossovka } (\mu_2)$$

---

## SLAYD 10: Dahiyanə Kəşf: Reparameterization Trick
### 🖼️ Sxem:
![Reparameterization Trick](images/gen05_reparameterization_trick.svg)

### ❌ Çıxılmaz Vəziyyət: Qradient Qırılır!
- Əgər z şəbəkə daxilində təsadüfi zər atılaraq seçilərsə, **törəmə almaq olmur!**
- Təsadüfi seçmə əməliyyatının riyazi törəməsi yoxdur. Backpropagation Enkoderə çata bilmir və model öyrənmir.

### ✅ Kingma & Welling (2013) Həlli:
Təsadüfilik şəbəkədən kənar sərbəst girişə çıxarılır: ε ~ N(0, I).
$$z = \mu + \sigma \odot \epsilon$$
- İndi z vektoru μ və σ-ya nəzərən tam diferensiallanandır: ∂z/∂μ = 1, ∂z/∂σ = ε.
- Qradientlər Dekoderdən Enkoderə maneəsiz axır!

---

## SLAYD 11: VAE İtki Funksiyası və "Torpaqdaşıma" Məsafəsi
### 🖼️ Sxem:
![KL Divergence Earth Mover](images/gen06_kl_divergence_earth_mover.svg)

### 📐 VAE-nin İki Qüvvəsinin Tarazlığı:
$$	ext{Ümumi İtki} = 	ext{Bərpa İtkisi} + 	ext{KL Divergence}$$
1. **Bərpa İtkisi:** Dekoderin çıxardığı görüntü ilə orijinal arasındakı piksel fərqini cəzalandırır. Əgər təkcə bu itki olsaydı, model fırıldaq edərək **σ → 0 (yayılma radiusunu sıfıra endirər)** və hər şəkli tək quru nöqtəyə çevirib adi qüsurlu avtoenkoderə qayıdardı!
2. **KL Divergence (Earth Mover / Torpaqdaşıma Analogiyası):**
   - Mühazirədəki analogiya: ABŞ xəritəsini İngiltərə formasına salmaq üçün nə qədər torpaq daşınmalıdır? Və ya 3x3 blokları 1x9 sıraya düzmək üçün görülən iş.
   - VAE-də KL itkisi bütün sinifləri standart mərkəzə N(0, I) doğru sıxır və fəzada bütövlük yaradır.
- **Dərs 1 Yekunu:** VAE stabil və kəsilməzdir, lakin bərpa itkisi pikselləri ortaladığı üçün hasil olunan şəkillər bir qədər *dumanlı (blurry)* olur.

---

# ⚔️ DƏRS 2: Generative Adversarial Networks (GAN)

---

## SLAYD 12: Dərs 2 Qapaq: Generative Adversarial Networks (GAN)
### Məzmun və Giriş:
- **Başlıq:** Dərs 2: Generative Adversarial Networks (GAN)
- **Alt Başlıq:** İki Rəqib Şəbəkənin Döyüşü və Fotorealizmin Doğuluşu (Ian Goodfellow, 2014)
- **Dərsin Əsas Məqsədləri:**
  1. VAE-dən fərqli olaraq heç bir *Gaussian* paylanması məcburiyyətinin olmaması.
  2. Generator və Discriminator qarşıdurması.
  3. Minimax itki tənliyi və *Nash Equilibrium (Neş Tarazlığı)* (D = 0.5).
  4. Təlimin kövrəkliyi, Rejim Çöküşü (Mode Collapse) və İtən Qradientlər.
  5. Tibbi məxfilik (HIPAA) və DeepFake etikası.

---

## SLAYD 13: Viral Tətbiqlər, DeepFake və "This Person Does Not Exist"
### 📌 Real Dünyada GAN Təsiri:
- **Viral Mobil Tətbiqlər:** Üz dəyişdirmə (Face swap), qocalma filtrləri, cizgi film personajına çevrilmə.
- **"This Person Does Not Exist":** GAN-ın yaratdığı elə insan portretləri var ki, saç telindən göz parıltısına qədər 100% fotorealistikdir, lakin o insanlar **dünyada heç vaxt yaşamayıb!**
- **Etika və Xəbərdarlıq:** Deepfake texnologiyası həm də saxta xəbərlər və dezinformasiya üçün istifadə oluna bilər. Mühəndis olaraq bu gücün etik məsuliyyətini dərk etməliyik.

---

## SLAYD 14: Tədqiqatçıların Əsl Nəcib Niyyətləri: Real Dünya Tətbiqləri
### 📌 Təkcə Əyləncə Deyil!
1. **Məxfi Tibbi Məlumatların Sintezi (HIPAA / GDPR):** Xərçəng xəstələrinin rentgen və MRT şəkilləri məxfidir. GAN real pasiyentlərin kimliyini açmadan tibbi baxımdan 100% dəqiq sintetik xəstəlik bazaları yaradır!
2. **Anomaliya Aşkarlanması:** Normal istehsalat detallarını öyrənərək qüsurları dərhal tapır.
3. **Sürücüsüz Nəqliyyat:** Qarlı hava, qəza şəraiti kimi nadir hadisələri virtual simulyatorda hasil edir.
4. **İncəsənət və Musiqi:** Pikasso üslubunda rəsm və Bethoven/Motsart üslubunda yeni simfoniyalar bəstələyir.

---

## SLAYD 15: GAN Memarlığı: Təsadüfi Səs-küydən Reallığa
### 🖼️ Sxem:
![GAN Minimax Architecture](images/gen07_gan_minimax_game.svg)

### 📌 İki Rəqib Oyunçu:
1. **Generator (G):** Təsadüfi səs-küy vektorunu (z) qəbul edir və Transposed Convolution ilə saxta şəkillər hasil edir. Məqsədi: Detektivi aldatmaq.
2. **Discriminator (D):** Həm real şəkilləri (x), həm də saxta şəkilləri (G(z)) qəbul edir. Çıxışı: D(x) ∈ [0, 1] (1 = Real, 0 = Saxta). Məqsədi: Saxtanı ifşa etmək.

---

## SLAYD 16: Saxtakar Pul Basan və Mərkəzi Bankın Detektivi
### 🕵️ Ən Aydın Analoq:
- **Generator = Saxta Pul Basan:** O heç vaxt əsl pulun necə olduğunu görmür! Sadəcə səs-küydən kağız basır.
- **Discriminator = Polis Detektivi:** Əsl pulları da görür, saxtanı da.
- **Təkamül Rəqabəti:** Detektiv saxtanı tutanda səbəbini deyir ➔ Saxtakar düzəldir ➔ Detektiv daha ayıq-sayıq olur ➔ Hər ikisi birlikdə ustalaşır!
- **Təlim Bitdikdə:** Detektivi kənara atırıq, əlimizdə dünyanın ən mahir rəssamı (Generator) qalır!

---

## SLAYD 17: GAN-ın Riyazi Məntiqi: Minimax Oyunu
### 📐 Oyunlar Nəzəriyyəsinin Tənliyi:
$$\min_{G} \max_{D} V(D, G) = \mathbb{E}_{x}[\log D(x)] + \mathbb{E}_{z}[\log(1 - D(G(z)))]$$
- **max D (Detektiv):** Real şəkildə D(x) → 1 ⟹ log(1) = 0. Saxtada D(G(z)) → 0 ⟹ log(1) = 0. Hər iki halda itkini maksimallaşdırmaq istəyir.
- **min G (Saxtakar):** Detektivi aldadaraq D(G(z)) → 1 etmək istəyir. Bu halda log(1 − 1) = log(0) → −∞, yəni itkini minimallaşdırır.

---

## SLAYD 18: GAN Təliminin Dinamikası və Neş Tarazlığı
### 🖼️ Sxem:
![GAN Training Dynamics Nash](images/gen08_gan_training_dynamics_nash.svg)

1. **Epox 1:** Generator təmiz küy çıxarır. Detektiv asanlıqla tutur: D(G(z)) ≈ 0.0.
2. **Epox 15:** Dumanlı konturlar və formalar yaranır. Detektiv çətinləşir: D(G(z)) ≈ 0.35.
3. **Epox 30 (Nash Equilibrium):** Generator o qədər mükəmməl saxta yaradır ki, Detektiv çarəsiz qalır:
   $$D(G(z)) = 0.5 \quad (50\% 	ext{ Ehtimal!})$$
   Detektiv artıq ayırd edə bilmir, sadəcə qəpik ataraq təxmin edir!

---

## SLAYD 19: GAN Təlimində Praktiki Çətinliklər və Xəbərdarlıqlar
### ⚠️ Əsas Maneələr:
- "Təcrübədə bu çox kövrək (fragile) və qeyri-sabit bir sistemdir!".
- Adi şəbəkələrdə tək bir itkini aşağı salırıq. GAN-da isə **hərəkət edən hədəfə atəş açırıq!**
- Tərəflərdən biri digərini tez üstələyən kimi bütün sistem tarazlıqdan çıxır və dağılır.
- Tonlarla hiperparametr tənzimləməsi, sınaq-yanılma (trial and error) və nəhəng GPU gücü tələb edir.

---

## SLAYD 20: Tələ 1: Rejim Çöküşü (Mode Collapse)
### 🖼️ Sxem:
![GAN Mode Collapse](images/gen09_gan_mode_collapse.svg)

### 🛑 Rejim Çöküşü Nədir?
- Verilənlər bazasında krossovka, çəkmə, sandal kimi 10 növ ayaqqabı var.
- Təlim zamanı Generator təsadüfən aşkar edir ki, bir xüsusi sandal şəkli Detektivi çox rahatlıqla aldadır.
- Və o, başqa heç bir ayaqqabını öyrənmir, **YALNIZ həmin sandalı istehsal etməyə başlayır!**
- Ümumi xəta az olsa da, sistemin çeşidliliyi məhv olur.

---

## SLAYD 21: Tələ 2: İtən Qradientlər və Sabitləşdirmə Metodları
### 📉 İtən Qradient (Vanishing Gradient):
- Əgər Detektiv çox tez güclənərsə (D ≈ 100%), Generatora ötürülən qradient sıfıra enir və öyrənmə donur.
- **Praktiki Həllər (DCGAN Prinsipləri):**
  - `LeakyReLU(0.2)` aktivasiyası (ölü neyronların qarşısını alır).
  - Detektivdə `Dropout(0.3)` istifadəsi (onun həddən artıq tez güclənməsini cilovlayır).
  - Wasserstein GAN (WGAN-GP) kimi inkişaf etmiş itki funksiyaları.

---

# ⚖️ HİSSƏ 3: YEKUN DƏRS — VAE və GAN: Birgə Müqayisə və Gələcək

---

## SLAYD 22: Yekun Hissə Qapaq: İki Nəhəng Paradigmanın Qarşılaşdırılması
### Məzmun:
- **Başlıq:** Yekun Hissə: VAE və GAN-ın Birgə Müqayisəsi və Sintezi
- **Alt Başlıq:** İki Nəhəng Paradigmanın Qarşılaşdırılması və Generativ AI-ın Müasir Mənzərəsi
- **Məqsəd:** Hər iki modeli eyni müstəvidə müqayisə etmək və real layihələrdə hansını seçməli olduğumuzu aydınlaşdırmaq.
- **Mode Collapse Xatırlatması:** Generatorun bütün digər çeşidləri unudaraq yalnız tək bir növü təkrar istehsal etməsi riski.

---

## SLAYD 23: VAE vs GAN: Dərindən Müqayisəli Cədvəl
### 🖼️ Sxem:
![VAE vs GAN Comparison](images/gen10_vae_vs_gan_comparison.svg)

| Meyar / Xüsusiyyət | 🎨 VAE (Variational Autoencoder) | ⚡ GAN (Generative Adversarial Network) |
| :--- | :--- | :--- |
| **Görüntü Keyfiyyəti** | Bir qədər dumanlı / hamar (Blurry) | Ultra-kəskin və fotorealistik (Sharp) |
| **Təlim Sabitliyi** | Çox sabit və proqnozlaşdırılan | Çox kövrək, Mode Collapse riski yüksək |
| **Gizli Fəza (Latent Space)** | Kəsilməz, hamar Gaussian paylanması | İxtiyari səs-küy, idarə çətindir |
| **Riyazi Əsas** | Bayes Ehtimalı, Variasiyalı ELBO | Oyunlar Nəzəriyyəsi (Minimax / Neş) |
| **İnterpolasiya / Morfinq** | Mükəmməl və səlis keçidlər | Bəzən qeyri-təbii sıçrayışlar |
| **Hesablama Tələbi** | Orta dərəcəli GPU kifayətdir | Çox güclü GPU və uzun saatlar tələb edir |

---

## SLAYD 24: Hansını və Nə Vaxt Seçməli? (Mühəndislik Qərar Ağacı)
### 🎨 Aşağıdakı Hallarda VAE Seçin:
1. **Verilənləri Sıxmaq və Gizli Vektor Almaq İstədikdə.**
2. **Anomaliyaları Aşkar Etmək:** Normal paylanmadan kənara çıxan xəstəlik və qüsurları tapmaq üçün.
3. **Smooth Morphing (Interpolation):** İki obyekt arasında kəsilməz, riyazi olaraq idarə olunan keçidlər üçün.
4. **Təlim Sabitliyi:** Baş ağrısız, stabil işləyən model istədikdə.

### ⚡ Aşağıdakı Hallarda GAN Seçin:
1. **Maksimum Fotorealizm Vacib Olduqda:** İnsan simaları, oyun teksturaları və incəsənət.
2. **Super-Resolution (ESRGAN):** Şəkillərin keyfiyyətini artırıb 4K etmək üçün.
3. **Üz Dəyişdirmə (FaceSwap):** Dəqiq və kəskin üz transformasiyaları.
4. **GPU Resursunuz Çox Olduqda:** Təlimin kövrəkliyini tənzimləməyə vaxt və gücünüz çatdıqda.

---

## SLAYD 25: Generativ AI-ın Təkamülü: Diffusion Modelləri
### 🚀 Təkamül Pilləkəni:
$$	ext{Autoencoder (1980)} \longrightarrow 	ext{VAE (2013)} \longrightarrow 	ext{GAN (2014)} \longrightarrow 	ext{Diffusion Modelləri (2020+)}$$

### 💡 Diffusion Modelləri (Stable Diffusion, Midjourney, DALL-E) Necə Doğuldu?
- Mühəndislər düşündü: *GAN kimi ultra-kəskin şəkil çəkən, amma VAE kimi stabil təlim olunan bir model mümkündürmü?*
- **Bəli — Diffusion Modelləri!**
- Şəkilə addım-addım səs-küy əlavə olunur (Forward Process). Şəbəkə həmin səs-küyü addım-addım təmizləyərək fotorealistik şəkil bərpa edir (Reverse Denoising).
- **Yekun Qeyd:** Generativ AI-ın iki təməl sütununu — VAE və GAN-ı dərindən bildiyiniz üçün gələcəkdə ən müasir Diffüziya arxitekturalarını asanlıqla mənimsəyə biləcəksiniz. Notebooklardakı parametrlərlə təcrübə aparın və AI-ın necə yaratdığını canlı görün!

---
*Dərs vəsaiti tələbələrə təlim zamanı bələdçi kimi hazırlanmışdır.*
